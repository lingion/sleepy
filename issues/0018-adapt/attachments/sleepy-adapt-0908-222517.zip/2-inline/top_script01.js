
(function(){
  if(typeof jQuery==='undefined')return;
  $(window).on('load',function(){
    var $btn=$('.b-select-system .bss-btn');
    var btnEl=$btn[0];
    if(btnEl){
      $btn.off('click');
      var evts=jQuery._data(btnEl,'events');
      if(evts&&evts.click)evts.click=[];
    }
    var isMobile=('ontouchstart' in window)||(navigator.maxTouchPoints>0);
    var isSystemMenu=false;
    $btn.on('click',function(){
      var bssmenu=$(this).next();
      var bss=$(this).parent();
      if(bssmenu.is(':visible')){
        bss.removeClass('open');
        if(isMobile){bssmenu.hide();}else{bssmenu.slideUp(200);}
        isSystemMenu=false;
      }else{
        bss.addClass('open');
        if(isMobile){bssmenu.css('height','').show();}else{bssmenu.slideDown(200);}
        $('.b-top-nav .dropdown').removeClass('open');
        $('.b-top-nav .dropdown-menu').hide();
        isSystemMenu=true;
      }
      return false;
    });
    $(document).on('click',function(){
      if(isSystemMenu){
        $('.b-select-system').removeClass('open');
        if(isMobile){$('.b-select-system .bss-menu').hide();}else{$('.b-select-system .bss-menu').slideUp(100);}
        isSystemMenu=false;
      }
    });
  });
})();
