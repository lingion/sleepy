
    $(document).ready(function() {
        $(".b-sidebar-scroll, .b-select-system .bss-menu").niceScroll({styler:"fb",cursorcolor:"#0066cc", cursorwidth: '0', background: '#f0f0f0', cursorborderradius: '5', cursorborder: ''});
    });
