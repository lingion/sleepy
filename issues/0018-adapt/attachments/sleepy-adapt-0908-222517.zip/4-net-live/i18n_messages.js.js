METHOD: GET
URL: https://xkgo.ucas.ac.cn:3000/static/i18n/messages.js
STATUS: 200
CONTENT-TYPE: text/javascript
FRAME: 7593FE80225F491E7C24B5D9C202B895

-------- 响应体 (484 字符) --------
var js = {};
js.lang = new function(){
    this.idcard_tip1 = "请正确输入您的身份证号码";
    this.mobile_tip1 = "请正确填写您的手机号码";
    this.telephone_tip1 = "请正确填写您的固定电话,如xxx-xxxxxxxx或xxxxxxxxxxx";
    this.postcode_tip1 = "请正确填写您的邮政编码";
    this.submit_loading = "正在提交，请稍等...";
    this.loading = "加载中...";
    this.tip = "提示";
    this.system_tip = "系统提示";
};