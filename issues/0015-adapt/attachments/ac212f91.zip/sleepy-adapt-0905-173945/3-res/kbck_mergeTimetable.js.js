define(function () {
    var cache = {};

    var mergeTimetableDefineInstance = {
        clearCache: function () {
            cache = {};
        },
        cacheKbData: function (data) {
            if (!data || data.length < 1) {
                return;
            }
            cache.kbData = $.extend(true, [], data);
        },

        cacheTkData: function (data) {
            if (!data || data.length < 1) {
                return;
            }
            cache.tkData = $.extend(true, [], data);
        },

        getKbData: function () {
            return cache.kbData || [];
        },

        getTkData: function () {
            return cache.tkData || [];
        },

        mergeBefore: function (result) {
            return result;
        },
        merge: function (timeTableData) {
            if (!timeTableData || timeTableData.length < 1) {
                return [];
            }

            timeTableData = mergeTimetableDefineInstance.mergeBefore(timeTableData);

            function isNumber(num) {
                return (!isNaN(parseFloat(num)) && isFinite(num));
            }

            function isEmpty(obj) {
                return typeof obj === 'undefined' || obj == null || obj === '';
            }

            //合并周次
            var xqArr = new Array(8);
            var result = [];
            timeTableData.forEach(function (item) {
                var week = item.week;
                if (!week) {
                    result.push(item);
                    return;
                }
                if ((!isNumber(week)) || (!isNumber(item.beginUnit)) || (!isNumber(item.endUnit))) {
                    result.push(item);
                    return;
                }
                week = Number(week);
                var dayList = xqArr[week];
                !dayList && (dayList = []) && (xqArr[week] = dayList);
                dayList.push(item);
            });

            function checkPropsIsEmpty(item) {
                var notEmptyProps = ['classroomName', 'JXBID', 'teacherName', 'beginUnit', 'endUnit', 'JASDM'];
                var hasEmpty = false;
                notEmptyProps.some(function (key) {
                    if (isEmpty(item[key])) {
                        hasEmpty = true;
                       // console.warn(key + ' is empty',  _.cloneDeep(item));
                    }

                    return hasEmpty;
                });
                return hasEmpty;
            }

            function getZcEndIndex(str) {
                var lastIndex = -1;
                if (isEmpty(str)) {
                    return lastIndex;
                }

                var subStr = '';
                for (; ;) {
                    var index = str.indexOf('周');
                    if (index < 0) {
                       break;
                    }
                    subStr += str.substring(0,index);
                    str = str.substring(index + 1);
                }
                return subStr.length === 0 ? -1 : subStr.length;
            }

            var newXqArr = new Array(8);
            xqArr.forEach(function (xqDayList, zc) {
                if (!xqDayList || xqDayList.length < 1) {
                    return;
                }

                xqDayList.forEach(function (item) {
                    var week = Number(item.week);
                    var dayList = newXqArr[week];
                    if (!dayList) {
                        dayList = [item];
                        newXqArr[week] = dayList;
                        return;
                    }
                    var isMerged = false;

                    if (!checkPropsIsEmpty(item)) {
                        dayList.some(function (tmpItem) {
                            if (checkPropsIsEmpty(tmpItem)) {
                                return isMerged;
                            }
                            //只有周次不一致,则进行合并
                            if (tmpItem.classroomName && item.classroomName
                                && tmpItem.JXBID === item.JXBID && tmpItem.teacherName === item.teacherName
                                && Number(tmpItem.beginUnit) === Number(item.beginUnit)
                                && Number(tmpItem.endUnit) === Number(item.endUnit)
                                && tmpItem.JASDM === item.JASDM
                            ) {
                                if(tmpItem.kcdm === '120001mj'){
                                    debugger
                                }
                                var tmpZcEndIndex = getZcEndIndex(tmpItem.classroomName);
                                if (tmpZcEndIndex < 1) {
                                    return isMerged;
                                }
                                var currZcEndIndex = getZcEndIndex(item.classroomName);
                                if (currZcEndIndex < 1) {
                                    return isMerged;
                                }

                                var tmpZcStr = tmpItem.classroomName.substring(0, tmpZcEndIndex);
                                var zcStr = item.classroomName.substring(0, currZcEndIndex);
                                tmpItem.classroomName = tmpZcStr + ',' + zcStr + tmpItem.classroomName.substring(tmpZcEndIndex);
                                isMerged = true;
                            }
                            return isMerged;
                        });
                    }

                    if (!isMerged) {
                        dayList.push(item);
                    }
                });
            });
            newXqArr.forEach(function (xqDayList) {
                if (!xqDayList || xqDayList.length < 1) {
                    return;
                }
                xqDayList.forEach(function (item) {
                    result.push(item);
                });
            });

            return result;
        }
    };
    return mergeTimetableDefineInstance;
});