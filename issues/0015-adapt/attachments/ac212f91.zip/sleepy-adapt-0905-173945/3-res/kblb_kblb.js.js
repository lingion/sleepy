define(function(require) {

  var utils = require('utils');
  var bs = require('./kblbBS');
  var dclb = require('../../../../../jwpubapp/public/commonpage_dclb/dclb');
  var self = '';
  var parentParam = {};
  var flag = true;
  var viewConfig = {
	  initialize: function(param) {
		  self = this;
		  parentParam = param;
		  var indexView = utils.loadCompiledPage('kblbIndexPage', require);
		  $.bhPaperPileDialog.show({
			  content: indexView.render({XNXQMC: param.xnxqmc}),
			  ready: function(){
				  self.initAdvancedQueryAndTable();  
			  }
	      });
		  
		  this.eventMap = {
				  '[data-action="kblb导出"]': this.actionExport,
				  '[data-action="kblb导出文件列表"]': this.actionExportFile
		  };
		  self.queryQrxxLB();
		  
	  },
	  
	  initAdvancedQueryAndTable: function(){
		  parentParam.action = parentParam.lbaction?parentParam.lbaction:parentParam.action;
		  var self = this;
		  $.publicDatatableWithExport({
			 	pagePath:  parentParam.pageModel, //必传
			 	action: parentParam.action, //必传
		 	    params: {
		 	    	XNXQDM: parentParam.xnxqdm
		 	    },
		 	    customColumns: this.getCustomColumns(),
		 	    extraParam: {
		 	    	queryDom: '.kblb-index-search',
		 	    	tableDom: '.kblb-index-table', //必传
		 	    	getSearchCallBackParam: function(){ //搜索回调所需的额外参数
		 	    		return self.getSearchParam();
		 	    	},
		 	    	getJsonData: function(){ //导出所需的jsonData
		 	 	  		return [{
		 	 	  			XNXQDM: parentParam.xnxqdm
		 	 	  		}];
		 	 	  	},
		 	    	orderColumn: "+KCH,+KXH,+SKXQ,+KSJC",  //排序字段
		 	    	fileName: '课表', //导出文件名
		 	    	appName: 'wdkb', //app名
		 	    	hasZdyl: false, //是否需要自定义列功能,默认true
		 	    	hasExport: false, //是否需要导出功能, 默认true
		 	    	searchType: 'emapFilterQuery' //搜索类型，默认高级搜索
		 	    }
			});	
	  },
		getSearchParam: function(){
			if(!parentParam.lbaction)return{XNXQDM: parentParam.xnxqdm};
			var queryDom = '.kblb-index-search';
			var params = {};
			var querySetting = $(queryDom).emapFilterQuery('getValue');
			var skzc = $(queryDom +' [data-name="SKZC"]').attr("data");
			var skxq = $(queryDom +' [data-name="SKXQ"]').val();
			var settingArray = JSON.parse(querySetting);
			var ksjc = null;
			var jsjc = null;
			var jxldm = null;
			var settingArrayTemp = [];
			$.each(settingArray, function(i, item){
			  if(item.name == "KSJC"){
				ksjc = item.value;
				settingArrayTemp.push(item);
				params["KSJC"]=ksjc;
			  }else if(item.name == "JSJC"){
				jsjc = item.value; 
				settingArrayTemp.push(item);
				params["JSJC"]=jsjc;
			  }else if(item.name == "SKZC"){
				  item.value = skzc; 
				  settingArrayTemp.push(item);
				  params["SKZC"]=skzc;
			  }else if(item.name == "SKXQ"){
				  item.value = skxq;
				  settingArrayTemp.push(item);
				  settingArrayTemp.push(item);
				  params["SKXQ"]=skxq;
			  }else if(item.name == "JXLDM"){
					jxldm = item.value; 
					params["JXLDM"]=jxldm;
			  }else {
				settingArrayTemp.push(item);
			  }
			});
			params["querySetting"] = JSON.stringify(settingArrayTemp);
			return params;
		},
	  getCustomColumns : function() {
		  var customColumns = [{
			  colIndex: '0',
			  type: 'checkbox',
   			  pinned:true
	      }, {
              colField: 'KCM',
              type: 'tpl',
              column: {
                  width: 130,
                  align: 'center',
                  pinned: true,
                  cellsalign: 'center',
                  cellsRenderer: function(row, column, value, rowData) {
                      if (rowData.TYXMDM == null || rowData.TYXMDM == "null" || rowData.TYXMDM.length == 0) {
                          return "<span  title=" + rowData.KCM + ">" + rowData.KCM + "</span>";
                      } else {
                          var str = rowData.KCM + "(" + rowData.TYXMDM_DISPLAY + ")";
                          return "<span  title=" + str + ">" + str + "</span>";
                      }
                  }
              }
          }];
		  return customColumns;
	  },
      actionExport: function(e) {
          var setting = $('.kblb-index-search').emapFilterQuery('getValue');
          $.publicExportForBigData({
        	  appname: 'wdkbby', //应用英文名
        	  appcname: '我的课表本研', //应用中文名
	  		  menu: 'wdkbby-kblb', //菜单名   不一定是真实的菜单英文名，只要能精确定位到位置
	  	  	  menuName: '我的课表', //菜单中文名
	  	  	  action: parentParam.action, //查询动作
	  		  tableSelector: '.kblb-index-table', //table选择器
	  		  querySelector: '.kblb-index-search', //query选择器
	  		  searchType: 'emapFilterQuery',
	  		  filename: '我的课表', //文件名
	  		  actionType: '1', //动作类型     1sql动作    其他  数据模型
	  		  param: {
	  			  exportType: parentParam.action,
	  			  XNXQDM: parentParam.xnxqdm,
	  			  querySetting: setting
	  		  }, //导出参数
	  		  orderColumn: '+KCH,+KXH,+SKXQ,+KSJC', //导出排序
	  		  tn: 'studentCentre', //数据权限中的tablename 
	  		  dealBeanId: 'WdkbbyExportService',//实现干预类
	  		  type: 'xlsx',//导出文件格式，默认xlsx    可以dbf
	  		  op: 'view' //数据权限中的operation
          });
      },

      /**
       * 查看当前教师课表确认信息
       */
      queryQrxxLB : function(){
      	if(!parentParam.isStudent){
      		var qrxxParam = {
      			XNXQDM : parentParam.xnxqdm
  	    	};
      		var qrxxData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/ckjskbqrxx.do"),qrxxParam);
      		if(qrxxData.code == 0  && qrxxData.datas.ckjskbqrxx.extParams.code==1){
      			CNT = qrxxData.datas.ckjskbqrxx.rows[0].CNT;
      			if(CNT>0){
      				var qrsjParam=qrxxParam;
      				var qrsjData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/ckkbqrsj.do"),qrsjParam);
      				if(qrsjData.code == 0  && qrsjData.datas.ckkbqrsj.extParams.code==1){
      					$("#kblb_qrsj").text("确认时间："+qrsjData.datas.ckkbqrsj.rows[0].CZSJ);
      					$("#kblb_qrsj").show();
      					$("#kblb_kbyqr").show();
      				}
      			}else{
      				var fbxxParam=qrxxParam;
      				var fbxxData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/ckjskbfbxx.do"),fbxxParam);
      				if(fbxxData.code == 0  && fbxxData.datas.ckjskbfbxx.extParams.code==1){
      	    			isFb = fbxxData.datas.ckjskbfbxx.rows[0].ISFB;
      	    			if(isFb>0){
      	    				isSjn= fbxxData.datas.ckjskbfbxx.rows[0].ISSJN;
      	    				if(isSjn>0){
      	        				$("#kblb_kbyqr").hide();
      	        				$("#kblb_qrsj").hide();
      	    				}else{
      	    					$("#kblb_kbyqr").hide();
      	        				$("#kblb_qrsj").hide();
      	    				}
      	    			}else{
      	    				$("#kblb_kbyqr").hide();
  	        				$("#kblb_qrsj").hide();
      	    			}
      	    		}else{
      	    			$("#kblb_kbyqr").hide();
        				$("#kblb_qrsj").hide();
      	    		}
      			}
      		}
      	}
      },
      
      actionExportFile: function(){
    	  dclb.initialize();
      }
      
    
  };

  return viewConfig;
});