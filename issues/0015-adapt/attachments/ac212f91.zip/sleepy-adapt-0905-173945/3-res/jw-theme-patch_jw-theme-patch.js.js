/**
 * Created by jwu on 2024/2/29
 * E-mail:01313101@wisedu.com
 *
 * Description:教务主题补丁，用于覆盖现有样式
 */

;(function () {
    if (!_JW_INIT_CONFIG.enableVis5) {
        // 未开启5.0视觉规范
        return;
    }

    window._JW_THEME_PATCH_ENABLE = true;// 全局挂载主题补丁是否启用标志位

    var absPageBase = WIS_CONFIG.PATH + '/sys/jwcommon';
    var buildInThemes = ['indigo', 'teal', 'golden', 'cherry', 'magenta'];// 内置主题
    var buildInRadius = ['5', '10', '20'];// 内置圆角

    // 从 url 中获取参数
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }

    // 写 cookie
    function setCookie(name, value) {
        var path = '/' + window.location.pathname.split('/')[1] + '/';
        document.cookie = name + '=' + value + '; expires=Session; path=' + path;
    }

    // 获取 cookie
    function getCookie(name) {
        var parts = document.cookie.split('; ' + name + '=');
        if (parts.length === 2) {
            return parts.pop().split(';').shift();
        }
        return null;
    }

    // 加载 css 文件
    function loadThemePatchCss(url, onload) {
        var link = document.createElement('link');
        link.setAttribute('theme-patch', 'true');// 加上自定义属性，表明该 css 用于主题补丁
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = url;
        link.onload = onload;
        document.head.appendChild(link);
    }

    // 进行 css 变量兼容性转换
    function doCssVarPolyfill() {
        require([absPageBase + '/public/script/common/jw-theme-patch/css-vars-ponyfill.js'], function (cssVars) {
            cssVars({
                include: 'style[theme-patch],link[theme-patch]', // 只针对有 theme-patch 属性的样式做兼容转换
                onlyLegacy: true// 只针对不支持 css 变量的浏览器做兼容转换
            });
        });
    }

    // 在 emap 框架初始化完毕后执行
    _JW_BOOT_HELPER.addFrameworkInitCallback(function () {
        // 解析 url，获取当前主题与圆角配置
        var themeKey = getQueryString('THEME');
        if (!themeKey) {
            // 尝试从 cookie 中取得当前主题
            themeKey = getCookie('THEME');
        }

        if (!themeKey || buildInThemes.indexOf(themeKey) < 0) {
            // 没有取得主题或主题不在内置的几套范围内，兜底为蓝色主题
            console.warn('教务主题补丁 - 未找到主题：', themeKey, '，使用兜底主题补丁文件：' + buildInThemes[0]);
            themeKey = buildInThemes[0];
        }

        var needLoadThemePatch = true;// 是否需要加载主题补丁文件

        // 尝试读取 url 中的 css 变量参数，生成相应 style。如果可以生成 style 标签，则无需再加载主题补丁文件
        try {
            var themeVariablesStr = getQueryString('THEME_VARIABLES');
            if (themeVariablesStr) {
                var themeVariables = {};
                decodeURIComponent(atob(themeVariablesStr)).split('&').forEach(function (pair) {
                    var pairParts = pair.split('=');
                    themeVariables[pairParts[0]] = pairParts[1];
                });

                // 生成 css
                var cssTemplate = Hogan.compile(':root {\n' +
                    '    --jw-primary-color-1: {{primaryColor1}};\n' +
                    '    --jw-primary-color-2: {{primaryColor2}};\n' +
                    '    --jw-primary-color-3: {{primaryColor3}};\n' +
                    '    --jw-primary-color-4: {{primaryColor4}};\n' +
                    '    --jw-primary-color-5: {{primaryColor5}};\n' +
                    '    --jw-bg-color-1: {{bgColor}};\n' +
                    '    --jw-primary-btn-bg-color: var(--jw-primary-color-4);\n' +
                    '    --jw-primary-btn-bg-color-lighter: var(--jw-primary-color-3);\n' +
                    '    --jw-primary-btn-bg-color-darker: var(--jw-primary-color-5);\n' +
                    '    --jw-primary-btn-text-color: {{primaryBtnTextColor}};\n' +
                    '}');
                var compileResult = cssTemplate.render(themeVariables);

                // 将 css 添加至 html
                var themeStyle = document.createElement('style');
                themeStyle.setAttribute('id', 'jw-theme-patch');
                themeStyle.setAttribute('theme-patch', 'true');// 加上自定义属性，表明该 css 用于主题补丁
                if (themeStyle.styleSheet) {
                    themeStyle.styleSheet.cssText = compileResult;
                } else {
                    themeStyle.appendChild(document.createTextNode(compileResult));
                }

                document.head.appendChild(themeStyle);

                needLoadThemePatch = false;// 已经生成了补丁 style 标签，无需再加载主题补丁文件
            }
        } catch (e) {
            console.warn('主题 CSS 变量解析失败', e);
        }

        // 获取圆角信息
        var radiusFileName = getQueryString('RADIUS');
        if (!radiusFileName || buildInRadius.indexOf(radiusFileName) < 0) {
            // 尝试从 cookie 中获取
            radiusFileName = getCookie('RADIUS');

            if (!radiusFileName || buildInRadius.indexOf(radiusFileName) < 0) {
                console.warn('教务主题补丁 - 未找到圆角：', radiusFileName, '，使用兜底圆角补丁文件：' + buildInRadius[0]);
                radiusFileName = buildInRadius[0];// 默认取 5 px 圆角的 css 文件
            }
        } else {
            // 写 cookie
            setCookie('RADIUS', radiusFileName);
        }

        var themePatchLoaded = !needLoadThemePatch; // 主题样式补丁是否已加载
        var radiusPatchLoaded = false; // 圆角样式补丁是否已加载
        var commonPatchLoaded = false; // 通用样式补丁是否已加载

        if (needLoadThemePatch) {
            // 加载特定主题补丁 css
            loadThemePatchCss(absPageBase + '/public/script/common/jw-theme-patch/themes/' + themeKey + '.css', function () {
                themePatchLoaded = true;
                // 各 css 加载完毕后，进行兼容性转换
                if (themePatchLoaded && radiusPatchLoaded && commonPatchLoaded) {
                    doCssVarPolyfill();
                }
            });
        }
        // 加载圆角配置 css
        loadThemePatchCss(absPageBase + '/public/script/common/jw-theme-patch/common/radius/' + radiusFileName + '.css', function () {
            radiusPatchLoaded = true;
            // 各 css 加载完毕后，进行兼容性转换
            if (themePatchLoaded && radiusPatchLoaded && commonPatchLoaded) {
                doCssVarPolyfill();
            }
        });
        // 加载通用样式 css
        loadThemePatchCss(absPageBase + '/public/script/common/jw-theme-patch/common/patch.css', function () {
            commonPatchLoaded = true;
            // 各 css 加载完毕后，进行兼容性转换
            if (themePatchLoaded && radiusPatchLoaded && commonPatchLoaded) {
                doCssVarPolyfill();
            }
        });
    });
})();