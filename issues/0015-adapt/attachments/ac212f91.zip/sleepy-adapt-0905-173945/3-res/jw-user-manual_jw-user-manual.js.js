(function (window, $) {
    var BASE_PATH = contextPath + "/sys/jwcommon/public/script/common/components/jw-user-manual/";

    _JW_BOOT_HELPER.addFrameworkInitCallback(function () {
        var utils = require("utils");
        var up = utils.getUserParams();

        var MANUAL_POSITION = "MANUAL_POSITION";
        require(["text!" + BASE_PATH + "jw-user-manual.html"], function (tpl) {
            var pageName = location.hash.replace(/\/|#/g, "");
            var match = window.location.href.match(/\/sys\/([^\/?]+)/);
            var appName = "";
            // 检查是否成功匹配
            if (match) {
                appName = match[1];
            }
            var iconList = [
                { name: "#icon-caozuozhinan" },
                { name: "#icon-quxianzhinan" },
                { name: "#icon-shanghuzhinan" },
                { name: "#icon-yonghushouce" },
                { name: "#icon-D_yonghushoucexiazai_yhscxz" },
                { name: "#icon-yonghuzhinan" },
                { name: "#icon-yonghushouce1" },
                { name: "#icon-zhongzhengzhinan" },
                { name: "#icon-zhinan" },
                { name: "#icon-banshizhinan" }
            ];
            var defaultIcon = undefined

            

            var _fileConfig = JSON.parse(window.localStorage.getItem("__JWCOMMON_FILECONFIG"));

            var isAdmin = _fileConfig.isAdmin || false
            if (_fileConfig.SCPZ && _fileConfig.SCPZ.appName && _fileConfig.SCPZ.iconFileId) { 
                var findIcon = iconList.find(function (item) { 
                    return item.name === _fileConfig.SCPZ.iconFileId
                })
                if (findIcon) { 
                    defaultIcon =  _fileConfig.SCPZ.iconFileId
                }
            }
            
            var pagefiles = JW_UTILS.getUploadFinger(pageName);

            if (pagefiles.length) {
                var layoutView = Hogan.compile(tpl);
                $("body").append(layoutView.render({ files: pagefiles, icon: defaultIcon, title: isAdmin ? '点击上传用户手册' : '用户手册' }));

                $(".jw-user-manual-file-wrapper").off("click", "#jw-user-manual-file");
                $(".jw-user-manual-file-wrapper").on("click", "#jw-user-manual-file", function (event) {
                    var token = $(event.currentTarget).attr("file-token");

                    var fileName = $(event.currentTarget).attr("title");

                    var id = $(event.currentTarget).attr("file-id");
                    if (!token) {
                        console.error("token不存在");
                        return;
                    }
                    if (!fileName) {
                        console.error("fileName不存在");
                        return;
                    }

                    if (!id) {
                        console.error("id不存在");
                        return;
                    }

                    if (/\.(jpg$|jpeg$|png$|gif$|bmp$)/.test(fileName.toLowerCase())) {
                        var url = window.contextPath + "/sys/emapcomponent/file/getAttachmentFile/" + id + ".do";
                        $.bhGallery({
                            dataSource: [
                                {
                                    image: url
                                }
                            ],
                            show: 0,
                            // 隐藏缩略图
                            thumbnails: false,
                            // 隐藏数量显示
                            showCounter: false,
                            extend: function () {
                                this.bind("image", function (e) {
                                    // 在图片加载完成后执行的代码
                                    var $img = $(e.imageTarget);
                                    var $gallery = $img.closest(".bh-gallery");
                                    // 隐藏左右切换图片按钮
                                    $gallery.find(".galleria-image-nav").hide();
                                    // 背景图设置为白色
                                    $img.css({
                                        background: "#fff"
                                    });
                                });
                            }
                        });
                    } else if (/\.pdf$/.test(fileName.toLowerCase())) {
                        $.emapPDFViewer({
                            id: token,
                            url: window.contextPath + "/sys/emapcomponent/file/getAttachmentFile/" + id + ".do"
                        });
                    } else {
                        window.location.href = _JW_INIT_CONFIG.contextPath + "/sys/emapcomponent/file/getFileByToken/" + token + ".do";
                    }
                });
                $(".jw-user-manual-icon")
                    .off("click")
                    .on("click", function () {
                        if (!isAdmin) { 
                            return
                        }
                        var $dialog = utils.window({
                            content: '<div id="jw-user-manual-file-choose-icon"></div>',
                            title: "图标",
                            height: "350px",
                            width: "400px",
                            buttons: [
                                {
                                    text: "确认",
                                    className: "bh-btn-primary",
                                    callback: function () {
                                        var icon = $('#jw-user-manual-file-choose-icon').find(':checked').val()
                                       
                                        $.jwAjax({
                                            url: '/sys/jwcommon/api/appOperatingManual/saveOperatingManualPz.do',
                                            data: {
                                                appName: appName,
                                                iconFileId: icon
                                            },
                                            successMsg: "",
                                            success: function () {
                                                var $use = $('#jw-user-manual-icon use')
                                                if ($use && $use.length) { 
                                                    $use.attr('xlink:href', icon)
                                                }
                                                defaultIcon = icon
                                            },
                                        });
                                    }
                                },
                                {
                                    text: "取消",
                                    className: "bh-btn-default",
                                    callback: function () {}
                                }
                            ]
                        });
                        require(["text!" + BASE_PATH + "menuIconTpl.html"], function (tpl) {
                            var iconTep = Hogan.compile(tpl);
                           
                            // $dom.find('[data-name="TB"]').append(
                            //     indexView.render({
                            //         datas: iconList
                            //     })
                            // );

                            $("#jw-user-manual-file-choose-icon").html(iconTep.render({ datas: iconList }));
                            if (defaultIcon) { 
                                $("#jw-user-manual-file-choose-icon").find('[value="'+defaultIcon+'"]').prop("checked", true);
                            }
                           
                        });
                    });
                var dropArea = document.querySelector("body");
                var draggableDiv = document.querySelector(".jw-user-manual-wrapper");

                var POSITION = JSON.parse(window.localStorage.getItem(MANUAL_POSITION));

                if (POSITION) {
                    $(draggableDiv).css({
                        top: POSITION.top,
                        left: POSITION.left
                    });
                } else {
                    $(draggableDiv).css({
                        top: 0,
                        left: 0
                    });
                }
                // 记录被拖动的元素
                var draggedElement = null;

                function dragstart(event) {
                    draggedElement = event.target; // 记录被拖动的元素
                    event.dataTransfer.setData("text/plain", ""); // 必须设置数据，否则拖放不生效

                    draggedElement.classList.remove("jw-user-manual-wrapper-hover");
                }

                function dragend() {
                    draggedElement.classList.add("jw-user-manual-wrapper-hover");
                }

                function dragover(event) {
                    event.preventDefault(); // 阻止默认行为，允许放置
                }

                function drop(event) {
                    event.preventDefault(); // 阻止默认行为

                    if (draggedElement) {
                        // 获取鼠标位置
                        var x = event.clientX - dropArea.getBoundingClientRect().left;
                        var y = event.clientY - dropArea.getBoundingClientRect().top;

                        if (!up.min || up.min !== "1") {
                            y = y + 44;
                        }

                        var left = x - draggedElement.offsetWidth / 2;
                        var top = y - draggedElement.offsetHeight / 2;

                        window.localStorage.setItem(MANUAL_POSITION, JSON.stringify({ left: left, top: top }));
                        // 更新被拖动元素的位置
                        draggedElement.style.left = left + "px";
                        draggedElement.style.top = top + "px";
                    }
                }

                // 拖动开始事件
                draggableDiv.removeEventListener("dragstart", dragstart);
                draggableDiv.addEventListener("dragstart", dragstart);

                draggableDiv.removeEventListener("dragend", dragend);
                draggableDiv.addEventListener("dragend", dragend);

                // 拖动经过事件
                dropArea.removeEventListener("dragover", dragover);
                dropArea.addEventListener("dragover", dragover);

                // 放置事件
                dropArea.removeEventListener("drop", drop);
                dropArea.addEventListener("drop", drop);

                $(".jw-user-manual-file-close")
                    .off("click")
                    .on("click", function (e) {
                        $(".jw-user-manual-wrapper").css("display", "none");
                    });
            }
        });

        (function () {
            var cnzz_s_tag = document.createElement("link");
            cnzz_s_tag.rel = "stylesheet";
            cnzz_s_tag.type = "text/css";
            var av = window._JW_INIT_CONFIG ? window._JW_INIT_CONFIG.APP_VERSION : "30001";
            cnzz_s_tag.href = BASE_PATH + "jw-user-manual.css?v=" + av;
            document.getElementsByTagName("head")[0].appendChild(cnzz_s_tag);
        })();
    });
})(window, jQuery);
