define(function(require) {

  var kbck = require('../../public/commonpage/kbck/kbck');
  var viewConfig = {
    initialize: function() {
    	this.pushSubView([kbck]);
    	var dqxnxq=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/dqxnxq.do"), {});
    	kbck.$rootElement=this.$rootElement;
    	var param={};
		param.zc=1;
		param.xnxqdm = dqxnxq.datas.dqxnxq.rows[0].DM;
		param.xnxqmc = dqxnxq.datas.dqxnxq.rows[0].MC;
		param.url = "/modules/xskcb/cxxszhxqkb.do";
		param.tkurl="/modules/xskcb/xsdkkc.do";
		param.wpkurl="/modules/xskcb/xswpkc.do";
		param.tk_ation="xsdkkc";
		param.wpk_action="xswpkc";
		param.flag=true;
		param.action="cxxszhxqkb";
		param.isStudent = true;
		param.pageModel="/modules/xskcb.do";
		param.lbaction = "cxbyxskc";
		var data = BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/xskcb/cxxsjbxx.do"), {"XH":userId});
		var row = data.datas.cxxsjbxx.rows[0];
		param.info = row.YXDM_DISPLAY + "  " + row.XM;
		kbck.initialize(param);
    } 
  
  };

  return viewConfig;
});