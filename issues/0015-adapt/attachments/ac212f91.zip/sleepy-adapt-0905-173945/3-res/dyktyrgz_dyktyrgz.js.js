define(function (require) {

    var utils = require('utils');
    var bs = require('./dyktyrgzBS');
    var dclb = require('../../../../../jwpubapp/public/commonpage_dclb/dclb');
    var self = '';
    var parentParam = {};
    var flag = true;
    var jwlcgl = require('./jwlcgl');
    var RZLBDM = jwlcgl.getRZLB(pageMeta.params.ROLEID); //RZLBDM:
    var viewConfig = {
        initialize: function (param) {
            self = this;
            parentParam = param;
            var indexView = utils.loadCompiledPage('dyktyrgzIndexPage', require);
            $.bhPaperPileDialog.show({
                content: indexView.render({XNXQMC: param.xnxqmc}),
                ready: function () {
                    self.initAdvancedQueryAndTable();
                }
            });

            this.eventMap = {
                '[data-action="dyktyrgz导出"]': this.actionExport,
                '[data-action="dyktyrgz导出文件列表"]': this.actionExportFile,
                '[data-action="报名"]': this.actionSignUp,
                '[data-action="评价"]': this.actionEvaluate,
                '[data-action="编辑评价表单"]': this.editEvaluateForm,
            };

        },

        initAdvancedQueryAndTable: function () {
            parentParam.action = parentParam.lbaction ? parentParam.lbaction : parentParam.action;
            var self = this;
            $.publicDatatableWithExport({
                pagePath: parentParam.pageModel, //必传
                action: 'cxdyktyrgz', //必传
                params: {
                    XNXQDM: parentParam.xnxqdm
                },
                customColumns: this.getCustomColumns(),
                extraParam: {
                    queryDom: '.dyktyrgz-index-search',
                    tableDom: '.dyktyrgz-index-table', //必传
                    getSearchCallBackParam: function () { //搜索回调所需的额外参数
                        return self.getSearchParam();
                    },
                    getJsonData: function () { //导出所需的jsonData
                        return [{
                            XNXQDM: parentParam.xnxqdm
                        }];
                    },
                    orderColumn: "+KCH,+ZC,+JC",  //排序字段
                    fileName: '课表', //导出文件名
                    appName: 'wdkb', //app名
                    hasZdyl: true, //是否需要自定义列功能,默认true
                    hasExport: false, //是否需要导出功能, 默认true
                    searchType: 'emapFilterQuery' //搜索类型，默认高级搜索
                }
            });
        },
        getSearchParam: function () {
            if (!parentParam.lbaction) return {XNXQDM: parentParam.xnxqdm};
            var queryDom = '.dyktyrgz-index-search';
            var params = {};
            var querySetting = $(queryDom).emapFilterQuery('getValue');

            var settingArray = JSON.parse(querySetting);
            var ksjc = null;
            var jsjc = null;
            var settingArrayTemp = [];
            $.each(settingArray, function (i, item) {
                if (item.name == "KSJC") {
                    ksjc = item.value;
                    settingArrayTemp.push(item);
                    params["KSJC"] = ksjc;
                } else if (item.name == "BY2") {
                    jsjc = item.value;
                    settingArrayTemp.push(item);
                    params["BY2"] = jsjc;
                } else {
                    settingArrayTemp.push(item);
                }
            });
            params["querySetting"] = JSON.stringify(settingArrayTemp);
            return params;
        },
        getCustomColumns: function () {
            var customColumns = [{
                colIndex: '0',
                type: 'checkbox',
                pinned: true
            }, {
                colIndex: '1',
                type: 'tpl',
                column: {
                    pinned: true,
                    text: '操作',
                    align: 'center',
                    cellsalign: 'center',
                    cellsRenderer: function (row, column, value,
                                             rowData) {
                        let html = '';

                        // 根据 BMZT 判断是否显示“报名”按钮
                        if (rowData.BMZT === '0') {
                            html += '<a href="javascript:void(0);" class="j-row-edit" data-x-wid="'
                                + rowData.WID + '" data-action="报名">报名</a>&nbsp;&nbsp;';
                        }

                        // 根据 PJZT 判断是否显示“评价”按钮或“已评价”按钮
                        if (rowData.PJZT === '1') {
                            html += '<a href="javascript:void(0);" class="j-row-edit" data-x-xspj="'
                                + rowData.XSPJ + '" data-x-wid="'
                                + rowData.WID + '" data-x-zhpf="'
                                + rowData.ZHPF + '"  data-action="编辑评价表单">已评价</a>';
                        } else if (rowData.PJZT === '0') {
                            html += '<a href="javascript:void(0);" class="j-row-edit" data-x-wid="'
                                + rowData.WID + '" data-x-bmzt="'
                                + rowData.BMZT + '" data-action="评价">评价</a>';
                        }

                        return html;
                    }
                }
            },
                {
                    colField: 'KCM',
                    type: 'tpl',
                    column: {
                        width: 130,
                        align: 'center',
                        pinned: true,
                        cellsalign: 'center',
                        cellsRenderer: function (row, column, value, rowData) {
                            if (rowData.TYXMDM == null || rowData.TYXMDM == "null" || rowData.TYXMDM.length == 0) {
                                return "<span  title=" + rowData.KCM + ">" + rowData.KCM + "</span>";
                            } else {
                                var str = rowData.KCM + "(" + rowData.TYXMDM_DISPLAY + ")";
                                return "<span  title=" + str + ">" + str + "</span>";
                            }
                        }
                    }
                }];
            return customColumns;
        },
        actionExport: function (e) {
            var setting = $('.dyktyrgz-index-search').emapFilterQuery('getValue');
            // let settingTemp = JSON.parse(setting)
            // settingTemp.push({
            //   name : 'XNXQDM',
            //   linkOpt : 'AND',
            //   value : parentParam.xnxqdm,
            //   builder : 'equal'
            // });
            // setting= JSON.stringify(settingTemp)
            var exportTypeStr = RZLBDM == "90001" ? 'cxdyktyrgz' : 'cxdyktyrhd'
            var action = RZLBDM == "90001" ? 'cxdyktyrgz' : 'cxdyktyrhd'
            $.publicExportForBigData({
                appname: 'wdkbby', //应用英文名
                appcname: '我的课表本研', //应用中文名
                menu: 'wdkbby-kblb', //菜单名   不一定是真实的菜单英文名，只要能精确定位到位置
                menuName: '我的课表', //菜单中文名
                action: action, //查询动作
                tableSelector: '.dyktyrgz-index-table', //table选择器
                querySelector: '.dyktyrgz-index-search', //query选择器
                searchType: 'emapFilterQuery',
                filename: '第一课堂育人活动', //文件名
                actionType: '1', //动作类型     1sql动作    其他  数据模型
                param: {
                    exportType: exportTypeStr,
                    XNXQDM: parentParam.xnxqdm,
                    querySetting: setting
                }, //导出参数
                orderColumn: '+KCH,+ZC,+JC', //导出排序
                tn: 'studentCentre', //数据权限中的tablename
                dealBeanId: 'WdkbbyExportService',//实现干预类
                type: 'xlsx',//导出文件格式，默认xlsx    可以dbf
                op: 'view' //数据权限中的operation
            });
        },

        actionExportFile: function () {
            dclb.initialize();
        },

        actionSignUp: function (event) {
            // var wid =  $(event.currentTarget).attr('data-x-wid');
            var wid = $(event.target).attr('data-x-wid');

            BH_UTILS.bhDialogWarning({
                title: '提示',
                content: '您确认报名吗?',
                buttons: [{
                    text: '确认',
                    callback: function () {
                        var res = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath('wdkbByController/signUp.do'), {
                            WID: wid,
                        });
                        if (res.code == '0' && res.data.code == '0') {
                            $.bhTip({content: '报名成功！', state: 'success'});
                            self.reloadTable();
                        } else {
                            $.bhTip({content: res.data ? res.data.msg : res.msg, state: 'danger'});
                        }
                    }
                }, {
                    text: '取消',
                    className: 'bh-btn-default',
                    callback: function () {
                        console.log('取消');
                    }
                }]
            });
        },

        actionEvaluate: function (event,sfzcbj) {
            var wid = $(event.target).attr('data-x-wid');
            var bmzt = $(event.target).attr('data-x-bmzt');
            //没有报名
            if (bmzt == '0') {
                $.bhTip({content: '请先报名！', state: 'danger'});
                return false;
            }

            BH_UTILS.bhWindow('<form id="pjForm"></form>', "评价当前育人活动",
                [{
                    text: '保存',
                    className: 'bh-btn-primary',
                    callback: function () {
                        var validate = $('#pjForm').emapValidate('validate');
                        if (!validate) {
                            return false;
                        }
                        var data = $('#pjForm').emapForm('getValue')
                        self.actionSaveEvaluate(wid, data);
                    }
                },
                    {
                        text: '取消',
                        className: 'bh-btn-default',
                        callback: function () {
                        }
                    }
                ],
                {
                    height: 750,
                    width: 600
                }
            );
            var mode = WIS_EMAP_SERV.getModel('/modules/xskcb.do', 'dyktyrgzpjbd', 'form');
            $('#pjForm').emapForm({
                data: mode,
                textareaEasyCheck: true,
                readonly: false,
                model: 'v',

            });
            var objStar = $("#pjForm [data-name=ZHPF]").parent();
			objStar.html('');
			if(!sfzcbj){
				objStar.bhStar({
				    score: 0 , //可选，设置分数，默认是0
				    size: 30, //可选，设置星的大小，单位按像素计算
				    isShowNum: true, //可选，是否显示数字，默认显示
				    text: '星' //可选，在分数后面显示的文字，默认是“分”
				});
			}else{
				 var zhpf = $(event.target).attr('data-x-zhpf');
				 objStar.bhStar({
					    score: zhpf , //可选，设置分数，默认是0
					    size: 30, //可选，设置星的大小，单位按像素计算
					    isShowNum: true, //可选，是否显示数字，默认显示
					    text: '星' //可选，在分数后面显示的文字，默认是“分”
					});
				 var xspj = $(event.target).attr('data-x-xspj');
				 if(!_.isEmpty(xspj) && xspj != 'null'){
					 $('#pjForm').emapForm("setValue", {XSPJ: xspj})
				 }
			}
        },
        editEvaluateForm: function (event) {
             self.actionEvaluate(event,true)
        },

        actionSaveEvaluate: function (wid, data) {
        	
        	if( 0 == $('.bh-star').attr('bh-star-score')){
       		 $.bhTip({content: '总体评价必填！', state: 'warning'});
       		 return false;
        	}
            var XSPJ = data.XSPJ
            var param = {
                XSPJ: XSPJ,
                ZHPF:$('.bh-star').attr('bh-star-score'),
                WID: wid
            }
            var res = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath('wdkbByController/saveEvaluate.do'), param);
            if (res.code == '0' && res.data.code == '0') {
                $.bhTip({content: '评价成功！', state: 'success'});
                self.reloadTable();
            } else {
                $.bhTip({content: res.data ? res.data.msg : res.msg, state: 'danger'});
                return false;
            }
        },

        reloadTable: function () {
            var querySetting = $(".dyktyrgz-index-search").emapFilterQuery('getValue');
            $(".dyktyrgz-index-table").emapdatatable("reload", {"querySetting": querySetting});
        }
    };

    return viewConfig;
});