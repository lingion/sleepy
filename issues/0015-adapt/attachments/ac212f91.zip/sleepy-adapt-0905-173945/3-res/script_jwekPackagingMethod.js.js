/**
 * 教务二开封装的jQuery方法集合
 */
(function ($) {
    $.extend({
        ek: {
            /**
             * 公共批量导出附件
             * @param param
             *
             */
            publicExportAttachmentBatch: function(param){
                if(!param.action || !param.page || !param.appName || !param.zipName || !param.attachmentField || !param.folderNameField){
                    console.log("参数错误");
                    return;
                }
                $.excelForm({
                    "param":JSON.stringify(param)
                }, contextPath + "/sys/jwcommon/api/exportAttachment/batchExportAttachment.do", 'batchExportAttachment');
            },

            /**
             * 公共导入查询组件
             * @param param
             */
            publicImportQuery: function (param){
                var self = this;
                if(!param.action || !param.page || !param.app || !param.pkField
                    || !param.filename || !param.reloadTableFunc || !param.buttonDom
                    ||(!param.canSelectField && !param.columns)){
                    console.log("参数错误");
                    return;
                }
                param.modules = param.modules||"modules";
                //是否先删除已经导入查询的数据情况
                if(param.firstLoad){
                    $.jwAjax({
                        url: '/sys/jwcommon/api/importQuery/closeDrcx.do',
                        data: {app: param.app, page: param.page, action: param.action},
                        async: false,
                        successMsg: '',
                        showLoading: true,
                        isWrapSuccessCallback: false,
                        success: function (resp) {
                            //如果成功删除对应数据，则重新加载表格
                            if(resp == 1){
                                param.reloadTableFunc();
                            }
                        }
                    });
                    //标记为非首次加载
                    param.firstLoad = false;
                }
                //获取到searchModel
                if(!param.searchModel){
                    var models = $.jwAjax({
                        url: '/sys/'+param.app+'/'+param.modules+'/'+param.page+'.do',
                        data: {'*json':'1'},
                        async: false,
                        successMsg: '',
                        isWrapSuccessCallback: false
                    }).models;
                    _.each(models, function(item){
                        if(item.name == param.action){
                            param.searchModel = item.modelName;
                        }
                    });
                }
                //查询当前用户是否已经有导入查询
                var drcxWid = $.jwAjax({
                    url: '/sys/jwcommon/api/importQuery/queryDrcxWid.do',
                    data: {app: param.app, page: param.page, action: param.action},
                    async: false,
                    successMsg: '',
                    isWrapSuccessCallback: false
                });
                var drcxButtonKey = param.app + '-' + param.page + '-' + param.action;
                if(drcxWid){
                    param.buttonDom.append('<a href="javascript:void(0)" id="'+drcxButtonKey+'-gbdrcx" class="bh-btn bh-btn-danger jwqueryandtable-button-gbdrcx">关闭导入查询</a>');
                    $('#'+drcxButtonKey+'-gbdrcx').on('click', function(){
                        $.jwAjax({
                            url: '/sys/jwcommon/api/importQuery/closeDrcx.do',
                            data: {app: param.app, page: param.page, action: param.action},
                            async: false,
                            successMsg: '',
                            showLoading: true,
                            isWrapSuccessCallback: false
                        });
                        $('#'+drcxButtonKey+'-gbdrcx').remove();
                        param.reloadTableFunc();
                        $.ek.publicImportQuery(param);
                    });
                } else {
                    param.buttonDom.append('<a href="javascript:void(0)" id="'+drcxButtonKey+'-drcx" class="bh-btn bh-btn-primary jwqueryandtable-button-drcx">导入查询</a>');
                    $('#'+drcxButtonKey+'-drcx').on('click', function(){
                        //如果可以选择字段
                        if(param.canSelectField){
                            var utils = require("utils");
                            var searchModelArr = $.jwAjax({
                                url: '/sys/jwcommon/api/importQuery/getDrcxSerachModel.do',
                                data: {app: param.app, page: param.page, action: param.action, module: param.modules, searchModel: param.searchModel},
                                async: false,
                                successMsg: '',
                                isWrapSuccessCallback: false
                            });
                            utils.window({
                                title: '选择支持导入查询的字段',
                                width: '600px',
                                height: '250px',
                                content: '<div id="import-query-select-field-div"></div>',
                                buttons: [{ //选填
                                    text: '确定',
                                    className: 'bh-btn-primary',
                                    callback: function() {
                                        var selectedFieldItems = $('#import-query-select-field-div').jqxDropDownList("getCheckedItems");
                                        if(selectedFieldItems.length == 0){
                                            A.errMsg('请选择支持导入查询的字段');
                                            return false;
                                        }
                                        var selectedFieldArr = [];
                                        _.each(selectedFieldItems, function(item){
                                            selectedFieldArr.push(item.value);
                                        });
                                        param.columns = selectedFieldArr.join(',');
                                        self.publicImportQueryOpenEmapImport(param, drcxButtonKey);
                                    }
                                }, {
                                    text: '取消',
                                    className: 'bh-btn-default',
                                    callback: function() {}
                                }]
                            });
                            var source = [];
                            _.each(searchModelArr, function(item){
                                source.push({label: item.caption, value: item.name});
                            });
                            $("#import-query-select-field-div").jqxDropDownList({
                                source: source,
                                placeHolder: "请选择...",
                                filterable:true,
                                filterPlaceHolder:"请查找...",
                                width: '100%',
                                height: '25px',
                                checkboxes: true
                            });
                        }else{
                            self.publicImportQueryOpenEmapImport(param, drcxButtonKey);
                        }
                    });
                }
            },

            publicImportQueryOpenEmapImport: function(param, drcxButtonKey){
                $.emapImport({
                    "contextPath": WIS_EMAP_SERV.getContextPath(),
                    "app": param.app,
                    "module": param.modules,
                    "page": param.page,
                    "action": param.action,
                    "params": {
                        "analyse": "com.wisedu.emap.jwcommon.ekdz.importQuery.service.ImportQueryAnalyse",
                        "save":"com.wisedu.emap.jwcommon.ekdz.importQuery.service.ImportQueryAnalyse",
                        "read": "com.wisedu.emap.jwcommon.ekdz.importQuery.service.ImportQueryAnalyse",
                        "filename": param.filename,
                        "transCommitCount":"500",
                        columns: param.columns,
                        queryParam: param.queryParam||{},
                        pkField: param.pkField
                    },
                    "preCallback": function() {},
                    "closeCallback": function() {
                        $('#'+drcxButtonKey+'-drcx').remove();
                        param.reloadTableFunc();
                        $.ek.publicImportQuery(param);
                    }
                });
            }
        }
    });
})(jQuery);