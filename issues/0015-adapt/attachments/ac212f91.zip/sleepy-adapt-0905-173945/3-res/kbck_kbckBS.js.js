define(function(require) {
  var utils = require('utils');
  var dj = [];
  var jc = [];
  var bs = {
	  api: {
		  jc: '/modules/jshkcb/jc.do',
		  cxjcgxxx: 'wdkbByController/cxjcgxxx.do'
	  },
	  initJcxxArr: function(param,isJcNew){
			var self=this;
			var jcxxArr = [];
			var jcCodeObject = {};
			sessionStorage.setItem('jcDjxxArr', "");
			//获取节次关系
	    	var jcgxData =$.jwAjax({
				url: '/sys/wdkbby/modules/dzkz/cxjcgxxxx.do',
				data:{},
				async:false,
				successMsg: '',
				success: function () {}
			});
	    	if(jcgxData && jcgxData.rows.length>0){
	    		dj=jcgxData.rows;
	    	}
			if(dj.length>0){
				sessionStorage.setItem('jcDjxxArr', JSON.stringify(dj));
			}else{
				$.bhTip({
					content : '查询节次关系信息失败',
					state : 'warning'
				});
			}
			//获取节次简称信息 用于课表内容展示
			sessionStorage.setItem('jcxxArr', "");
			sessionStorage.setItem('jcCodeObject', "");
	    	var jcData =$.jwAjax({
				url: '/sys/wdkbby/modules/dzkz/jcjcx.do',
				data:{},
				async:false,
				successMsg: '',
				success: function () {}
			});
	    	if(jcData && jcData.rows.length>0){
	    		jc=jcData.rows;
	    	}
			if(jc.length>0 ){
				var objTmp = {};
				var djIndex =0;
				$.each(jc, function(index, obj){
					objTmp = {
							code: obj.DM,
							name: self.getDjmc(djIndex,isJcNew),
							simpleName: (obj.MCJC?obj.MCJC:(obj.MC?obj.MC:obj.DM))
					};
					jcxxArr.push(objTmp);
					jcCodeObject[objTmp.code] = objTmp.simpleName;
					if(dj[djIndex]&&index===dj[djIndex].JSJC-1){
						djIndex++;
					}
				});
				sessionStorage.setItem('jcxxArr', JSON.stringify(jcxxArr));
				sessionStorage.setItem('jcCodeObject', JSON.stringify(jcCodeObject));
			}else{
				$.bhTip({
					content : '查询节次信息失败',
					state : 'warning'
				});
			}
		},
		getDjmc:function(djIndex,isJcNew){
			if(!dj[djIndex])return "未配置大节信息";
			if(dj[djIndex].DJDM=='6'){
				return "晚课";
			}
			if(dj[djIndex].DJDM=='3'){
				return "中课1-中课2";
			}
			return dj[djIndex].DJMC+'\n第'+dj[djIndex].KSJCLS+'-'+dj[djIndex].JSJCLS+'节';	 
		}
  };

  return bs;
});
