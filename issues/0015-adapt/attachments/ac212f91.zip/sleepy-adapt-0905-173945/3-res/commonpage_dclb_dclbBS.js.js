define(function(require) {

    var utils = require('utils');

    var bs = {
        api: {
            dcwjlb: window.context_path + "/sys/jwpubapp/modules/gg/cxdcdwjlb.do",
            downloadUrl: window.context_path + "/sys/jwpubapp/export/getAttachment.do"
        },

        queryDcwjlb: function(param) {
            return utils.fetch({
                url: bs.api.dcwjlb,
                data: param,

                /***parser用于对接口返回的数据做进一步处理***/
                parser: function(res) {

                }
            });
        },

        downLoadFile: function(param) {
            return utils.fetch({
                url: bs.api.downloadUrl,
                data: param,

                /***parser用于对接口返回的数据做进一步处理***/
                parser: function(res) {

                }
            });
        }
    };

    return bs;
});