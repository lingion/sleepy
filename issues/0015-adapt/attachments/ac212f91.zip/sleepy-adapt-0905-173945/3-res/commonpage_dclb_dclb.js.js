define(function(require) {
    require('css!./dclb.css');

    var utils = require('utils');
    var bs = require('./dclbBS');
    var self = null;

    var viewConfig = {
        /********页面内事件通过eventMap统一管理********/
        eventMap: function() {
            return {
                '.j-row-edit': this.actionDownLoad,
                '[data-action="dclb搜索"]': this.initDclbList,
                '#searchDclb@keypress': this.searchDclbPress
            };
        },

        /********页面入口方法********/
        initialize: function(param) {
            self = this;
            var indexView = utils.loadCompiledPage('dclbIndexPage', require);
            $.bhPaperPileDialog.show({
                content: indexView.render({}, true),
                render: function() {
                    self.initDclbList();
                }
            });
        },

        initDclbList: function() {
            self.paginationSearch(0, 10, $('#dclbList'), $('#dclbPagination'));
            $('#dclbPagination').off('pagersearch').on('pagersearch', function(e, pagenum, pagesize, total) {
                self.paginationSearch(pagenum, pagesize, $('#dclbList'), $('#dclbPagination')); //这个方法必须是渲染数据的方法
            });
        },

        paginationSearch: function(pagenum, pagesize, $listDom, $paginationDom) {
            var param = {
                '*order': '-CZSJ,-SCSJ,-XZSJ',
                pageSize: pagesize,
                pageNumber: (pagenum + 1)
            };
            var searchValue = $('#searchDclb').val();
            if (searchValue) {
                param.querySetting = JSON.stringify([{
                    "name": "FILENAME",
                    "linkOpt": "OR",
                    "builderList": "cbl_String",
                    "builder": "include",
                    "value": searchValue
                }, {
                    "name": "APPCNAME",
                    "linkOpt": "OR",
                    "builderList": "cbl_String",
                    "builder": "include",
                    "value": searchValue
                }, {
                    "name": "MENUNAME",
                    "linkOpt": "OR",
                    "builderList": "cbl_String",
                    "builder": "include",
                    "value": searchValue
                }]);
            }
            bs.queryDcwjlb(param).done(function(res) {
                if (res.code == '0') {
                    var view = utils.loadCompiledPage('rowTpl', require);
                    $.each(res.datas.cxdcdwjlb.rows, function(index, obj) {
                        if (obj.SFXZ != '1') {
                            obj.SFXZ_DISPLAY = '否';
                            obj.hasXz = false;
                        } else {
                            obj.SFXZ_DISPLAY = '是';
                            obj.hasXz = true;
                        }
                        if (obj.SFSC != '1') {
                            obj.SFSC_DISPLAY = '否';
                            obj.isLoading = true;
                        } else {
                            obj.SFSC_DISPLAY = '是';
                            obj.isLoading = false;
                        }
                        obj.src = window.context_path + "/sys/jwpubapp/export/getAttachment.do?wid=" + obj.WID;
                    });
                    var html = view.render({
                        hasDate: res.datas.cxdcdwjlb.rows.length > 0 ? true : false,
                        data: res.datas.cxdcdwjlb.rows
                    });
                    self.initPagination(pagenum, pagesize, $listDom, $paginationDom, html, res.datas.cxdcdwjlb.totalSize);
                } else {
                    $.bhTip({
                        content: '查询文件列表失败',
                        state: 'danger'
                    });
                }
            });
        },

        initPagination: function(pagenum, pagesize, $listDom, $paginationDom, html, totalSize) {
            $listDom.html(html);
            $paginationDom.pagination({
                mode: 'advanced', //可选， 分页的模式
                pagesize: pagesize, //可选， 一页展示的数据
                pageSizeOptions: [10, 20, 50, 100, 200], //可选，下拉框里面的数据
                selectedIndex: 0, //可选，下拉框的默认显示的index
                pagenum: pagenum, //可选，当前的页码
                totalSize: totalSize //必填，总共多少条数据
            });
        },


        actionDownLoad: function(e) {
        	var $dom = $(e.currentTarget);
        	if($dom.attr('isLosding') == '1'){
        		e.preventDefault();
        		e.stopPropagation();
        		$.bhTip({
        			content: '下载过于频繁，请稍后再试',
        			state: 'warning'
        		});
        		return false;
        	}else{
        		$dom.attr('isLosding', '1');
        		setTimeout(function(){
            		$dom.attr('isLosding', '0');
            	}, 5000);
        	}
        },

        searchDclbPress: function(event) {
            if (event.keyCode == "13") {
                self.initDclbList();
            }
        },

    };

    return viewConfig;
});