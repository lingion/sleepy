;(function (window, $) {

    _JW_BOOT_HELPER.addFrameworkInitCallback(function () {
        var _config = require("configUtils");
        // 禁用附件权限
        if (_config.disableAttachAuth) {
            return;
        }
        overrideFileAuth();
    });

    /**
     * 注入权限参数
     * @param $ele
     * @param options
     */
    function injectAuthParam($ele, options) {
        if (!options || options.disableAttachAuth) {
            // 未获取到选项或选项主动配置了禁用附件权限，那么不再处理
            return;
        }
        // 表单的JSONParam配置类似：{'uploadParam':{'authBeanName':'cjzhcxappFilePermissions','authAppName':'cjzhcxapp'}}
        if (_.isObject(options.uploadParam) && options.uploadParam.authAppName && options.uploadParam.authBeanName) {
            // 选项已经主动配置了附件权限类，那么不再处理
            return;
        }

        options.uploadParam = getUploadParam($ele, options.uploadParam);
    }

    var beanAppName = 'jwcommon';
    var beanName = 'JwCommonUploadFileAuth';

    function getUploadParam($ele, oldUploadParam) {
        var uploadParam = $.extend({}, {
            'authAppName': beanAppName,
            'authBeanName': beanName,
            // /sys/emapcomponent/file/saveAttachment 接口使用
            'saveAppName': beanAppName,
            'saveBeanName': beanName,
            // /sys/emapcomponent/file/uploadTempFileAsAttachment 接口使用
            'app': beanAppName,
            'customer': beanName,
            uploadAppName: getAppName(),
            hash: location.hash.replace(/\/|#/g, '')
        }, oldUploadParam);
        var $form = $ele.closest('[emap-role="form"]');
        if ($form.length) {
            var emapFormInfoStr = $form.attr('emap');
            if (emapFormInfoStr) {
                $.extend(uploadParam, toJson(emapFormInfoStr), {
                    'data-name': getDataName($ele)
                });
            }
        }
        return uploadParam;
    }

    function toJson(str){
        if (!str) {
            return str;
        }
        if (_.isString(str)) {
            str = (str || '').replace(/'/g, '"');
            return JSON.parse(str);
        }
        console.warn('参数对象有误,非字符串');
        return str;
    }

    /**
     * 覆盖附件上传权限
     */
    function overrideFileAuth() {
        overrideCacheUpload();
        overrideEmapUploadCore();
    }

    /**
     * 覆盖emapUploadCore组件
     */
    function overrideCacheUpload() {
        var oldFn = $.fn.cacheUpload;

        $.fn.cacheUpload = function () {
            if (_.isObject(arguments[0])) {
                var options = arguments[0];
                // 组件初始化，干预初始化参数
                injectAuthParam(this, options);
            }
            return oldFn.apply(this, arguments);
        };

        $.fn.cacheUpload.defaults = oldFn.defaults;
    }

    /**
     * 覆盖cacheUpload组件
     */
    function overrideEmapUploadCore() {
        var oldFn = $.fn.emapUploadCore;
        $.fn.emapUploadCore = function () {
            if (_.isObject(arguments[0])) {
                var options = arguments[0];
                // 组件初始化，干预初始化参数
                injectAuthParam(this, options);
            } else if ($.type(arguments[0]) === 'string') {
                // 调用方法
                var methodName = arguments[0];
                if (methodName === 'saveTempFile' || methodName === 'saveUpload') {
                    // 调用保存方法时也要设置参数
                    var param_data = arguments[1] || {};
                    $.extend(param_data, this.data('emapuploadcore').options.uploadParam);
                    arguments[1] = param_data;
                }
            }

            return oldFn.apply(this, arguments);
        };

        $.fn.emapUploadCore.defaults = oldFn.defaults;
    }

    function getDataName($ele) {
        // 先找本元素的data-name属性
        var dataName = $ele.attr('data-name');
        if (dataName) {
            return dataName;
        }
        // 再找有data-name的属性的父元素
        dataName = $ele.closest('[data-name]').attr('data-name');
        if (dataName) {
            return dataName;
        }
        // 最后找有data-field属性的父元素
        return $ele.closest('[data-field]').attr('data-field');
    }

    /**
     * 获取当前应用的应用名
     * @returns {*}
     */
    function getAppName() {
        if (window._JW_INIT_CONFIG) {
            return _JW_INIT_CONFIG.appname;
        }
        return window.appname;
    }


})(window, jQuery);