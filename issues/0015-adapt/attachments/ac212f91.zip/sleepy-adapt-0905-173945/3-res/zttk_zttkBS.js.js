define(function(require, exports, module) {
	
	var bs = {
		api: {
			pageModel : '/modules/jshkcb.do',
			cxztdkjl : 'cxztdkjl'
		}
	};
	return bs;
});