/**
 * 教师端首页常用应用数据记录表
 */
function init() {
    if (userId != '' && roleId != '') {
        gxyysj();
    }
}

function gxyysj() {
    $.ajax({
        url: contextPath + "/sys/jwpubapp/commonUseApp/updateVisitAppCount.do",
        data: {
            "appName": appname,
            "pageCode": window.location.hash.split('/')[1]
        },
        async: false,
        successMsg: '',
        success: function (resp) {
        }
    });
}

init();
