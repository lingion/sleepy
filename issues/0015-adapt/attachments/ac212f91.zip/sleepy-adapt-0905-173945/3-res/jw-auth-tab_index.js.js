(function (window, $) {
    var componentName = "jwAuthTab";

    var BASE_PATH = contextPath + "/sys/jwcommon/public/script/common/components/jw-auth-tab/";

    function getTemplate(path) {
        var utils = require("utils");
        var appVersion = utils.getConfig("APP_VERSION") || utils.getConfig("STATIC_TIMESTAMP") || "30000";
        var url = BASE_PATH + path + "?av=" + appVersion;
        var template = "";
        $.ajax({
            url: url,
            dataType: "text",
            async: false
        }).done(function (res) {
            template = res;
        });
        if ($.i18n) {
            template = utils.i18n(template);
        }
        return template;
    }

    function initTabContent(tabIndex, $tabContainer, tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var tab = tabs[i];
            if (tab.index == tabIndex) {
                tab.callback && $.type(tab.callback) === "function" && tab.callback($tabContainer);
                break;
            }
        }
    }

    function Plugin(element, options) {
        //将dom jquery对象赋值给插件，方便后续调用
        this.$element = $(element);

        var settings = $.extend(true, {}, $.fn.jwAuthTab.defaults, options);

        // 处理校验tabs,没有授权的pass
        var tabs = settings.tabs.filter(function (t) {
            if (!t.needAuth || $.jwAppConfig.hasPermission(t.authId)) {
                var uid = BH_UTILS.NewGuid().replace(new RegExp(/(-)/g), "");

                t.index = uid;

                return true;
            }
        });

        // 渲染无权限
        if (!tabs.length) {
            var notPermissionView = Hogan.compile(getTemplate("not-permission.html"));

            this.$element.html(notPermissionView.render(), true);

            return;
        }

        // 判断激活的标签页
        var selectedItem = 0;

        if (settings.defaultTabId) {
            var index = tabs.findIndex(function (t) {
                return t.authId === settings.defaultTabId;
            });
            selectedItem = index === -1 ? 0 : index;
        }

        var activeTabIndex = tabs[selectedItem].index;
        this.activeTabId = tabs[selectedItem].authId;

        // jqxTabs参数
        var jqxTabsParam = settings.extParam;
        jqxTabsParam.selectedItem = selectedItem;

        // 渲染页签html结构
        var layoutView = Hogan.compile(getTemplate("index.html"));

        this.$element.html(layoutView.render({ tabs: tabs }), true);

        var self = this;

        function initTabs() {
            if (!$(element).is(":visible")) {
                // 如果元素处于不可见状态，那么每200毫秒重新初始化一次，直到元素可见
                // console.warn("tab元素不可见，200ms后重新渲染");
                $(element).data("once_not_visible_", true);
                _.delay(initTabs, 200);
                return;
            }

            if ($(element).data("once_not_visible_")) {
                $(element).removeData("once_not_visible_");
                $(element).data("reset_tab_height", true);
                _.delay(initTabs, 200);
                return;
            }

            A.resetFooter();

            $(element).find(".jwAuthtab-tab").jqxTabs(jqxTabsParam);

            // 判断是否开启参数
            var configUtils = require("configUtils");

            if (configUtils && configUtils.LAYOUT_FLEX && _JW_INIT_CONFIG.jwTableHeightAuto && settings.autoHeight) {
                // 如果开启参数 需要让tab占满剩余空间  因此判断父容器是否有高度
                var parentContainerHeight = $(element).parent().height();

                if (parentContainerHeight) {
                    // 如果父容器有高度 则让tab容器height：100% 将authtab改造为flex布局
                    $(element).css({ height: "100%", flex: "1" });
                    $(element).find(".jwAuthtab-tab").css({
                        height: "100%",
                        display: "flex",
                        flexDirection: "column"
                    });
                    $(element).find(".jwAuthtab-tab .jqx-tabs-content").css({
                        flex: "1 1 auto",
                        height: "0",
                        overflowY: "auto"
                    });
                    $(element).find(".jwAuthtab-tab .jqx-tabs-content .jwAuthtab-tab-content").css({
                        height: "100%",
                        overflow: "hidden auto"
                    });
                } else {
                    // 如果父容器没有高度 则不支持flex布局 其下的content也就不能支持表格flex布局
                    console.warn("$(element) parent dom havenot height");
                }
            }

            if ($(element).data("reset_tab_height")) {
                var resetHeightFunc = function () {
                    var $content = $(element).find(".jqx-tabs-content");
                    $content.css({
                        height: "calc(100% - 37px)"
                    });
                    if ($content.height() < 20) {
                        _.delay(resetHeightFunc, 200);
                    }
                };
                _.delay(resetHeightFunc, 20);
            }

            // 渲染并跳转页面
            $(element)
                .find(".jwAuthtab-tab")
                .on("selected", function (event) {
                    var tabIndex = tabs[event.args.item].index;
                    var $tabContainer = $(element).find(".jwAuthtab-tab-content-" + tabIndex);
                    initTabContent(tabIndex, $tabContainer, tabs);
                    self.activeTabId = tabs[event.args.item].authId;
                });

            var $firstTabContainer = $(element).find(".jwAuthtab-tab-content-" + activeTabIndex);
            initTabContent(activeTabIndex, $firstTabContainer, tabs);
        }

        initTabs(this.$element, jqxTabsParam, settings, tabs);
    }

    Plugin.prototype.getActiveTabId = function () {
        return this.activeTabId;
    };

    /**
     * 教务权限标签页组件参数Tab定义
     * @callback FunctionTypeCallback
     * @param {jQuery} $element - 标签页内容 jQuery dom 对象
     * @returns {void}
     */

    /**
     * 教务权限标签页组件参数Tab定义
     * @typedef {Object} Tab
     * @property {string} title - 标签页标题
     * @property {string} [authId] - 标签页权限标识 permissionKey
     * @property {boolean} [needAuth] - 是否需要权限校验
     * @property {FunctionTypeCallback} callback - 渲染标签页的回调 参数为标签页的 jQuery 对象
     *
     * @see FunctionTypeCallback
     */

    /**
     * 教务权限标签页组件参数定义
     * @typedef {Object} Options
     * @property {Array<Tab>} tabs - 标签页列表
     * @property {string} [defaultTabId] - 默认激活的标签页 authId
     * @property {boolean} [autoHeight] - 标签页自适应高度
     * @property {object} [extParam] - 扩展参数-jqxTab组件参数
     * @see Tab
     */

    /**
     * 教务权限标签页
     * @param {Options | 'getActiveTabId'} options  getActiveTabId 获取激活的标签页authId
     * @returns {jQuery} - jQuery DOM 对象，包含匹配的元素
     * @see Options
     *
     * @example
     *
     * $().jwAuthTab({
     *      tabs: [{
     *          title: '标签页1',
     *          authId: 'bqy-1',
     *          needAuth: true,
     *          callback: function($element) {}
     *      }],
     *      defaultTabId: 'bqy-1'
     *  })
     *
     */

    $.fn.jwAuthTab = function (options) {
        var instance;
        instance = this.data(componentName);

        if (!instance || $.type(options) === "object") {
            if (!options.tabs || $.type(options.tabs) !== "array" || !options.tabs.length) {
                throw new Error("jwAuthTab component options.tabs should be array and must have length");
            }
            return this.each(function () {
                return $(this).data(componentName, new Plugin(this, options));
            });
        }

        if (options === true) return instance;
        if ($.type(options) === "string" && instance[options]) {
            return instance[options]();
        }

        return this;
    };

    $.fn.jwAuthTab.defaults = {
        /**
         * 自适应高度 开启之后判断root dom 是否有高度  如果有高度 让content内容撑满剩余空间
         * @type boolean
         */
        autoHeight: true,

        /**
         * jqxTabs相关参数
         * @type object
         */
        extParam: {
            position: "top"
        }
    };
})(window, jQuery);
