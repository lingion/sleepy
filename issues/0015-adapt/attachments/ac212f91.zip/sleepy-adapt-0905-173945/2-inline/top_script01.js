
      function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
          var pair = vars[i].split("=");
          if (pair[0] === variable) {
            return pair[1];
          }
        }
        return "";
      }

      window.contextPath = getQueryVariable("contextPath");
      // 动态设置 publicPath
      window.publicPath = window.contextPath + "/sys/homeapp/home/";
      window.resourceBaseUrl = window.contextPath + "/sys/homeapp/home/";

      window.WIS_CONFIG = {
        ROOT_PATH: window.contextPath,
      };
    