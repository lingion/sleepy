
      var userAgent = window.navigator.userAgent.toLocaleLowerCase();

      function compareVersion(version1, version2) {
        var arr1 = version1.split(".");
        var arr2 = version2.split(".");
        var length1 = arr1.length;
        var length2 = arr2.length;
        var minlength = Math.min(length1, length2);
        var i = 0;
        for (i; i < minlength; i++) {
          var a = parseInt(arr1[i]);
          var b = parseInt(arr2[i]);
          if (a > b) {
            return false;
          } else if (a < b) {
            return true;
          }
        }
        if (length1 > length2) {
          for (var j = i; j < length1; j++) {
            if (parseInt(arr1[j]) !== 0) {
              return false;
            }
          }
          return false;
        } else if (length1 < length2) {
          for (var j = i; j < length2; j++) {
            if (parseInt(arr2[j]) !== 0) {
              return true;
            }
          }
          return false;
        }
        return false;
      }

      function browser() {
        var rMsie = /(msie\s|trident\/7)([\w\.]+)/; //是否是ie
        var rIE11 = /(rv:)([\w.]+)/; //ie11
        var rFirefox = /(firefox)\/([\w.]+)/; //火狐
        var rOpera = /(opr)\/([\w.]+)/; //新Opera 基于谷歌
        var rEdge = /(edge)\/([\w.]+)/;
        var rSafari = /version\/([\w.]+).*(safari)/;
        var rChrome = /(chrome)\/([\w.]+)/; //谷歌
        var rQQ = /(qqbrowser)\/([\w.]+)/; //QQ
        var matchBS;
        // FireFox
        matchBS = rFirefox.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "66")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // Opera
        matchBS = rOpera.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "58")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // Edge
        matchBS = rEdge.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "18.17763")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // Safari
        matchBS = rSafari.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "12.0")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // IE浏览器
        matchBS = rMsie.exec(userAgent);
        if (rMsie.exec(userAgent) !== null) {
          if (rIE11.exec(userAgent) === null) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // QQ浏览器
        matchBS = rQQ.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "9.7")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
        // Chrome浏览器
        matchBS = rChrome.exec(userAgent);
        if (matchBS !== null) {
          if (compareVersion(matchBS[2], "71")) {
            window.location.href = "static/browsertips.html";
          }
          return false;
        }
      }

      browser();
    