
      window.publicPath = window.resourceBaseUrl || "./";
    