METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwpubapp/public/script/publicPrintFR.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (8819 字符) --------
/**
 * @author 01316040
 * 公共打印帆软报表方法
 * 引用实例: 在index.jsp文件中：
 * <script type="text/javascript" src="../../jwpubapp/public/script/publicPrintFR.js"></script>
 * 
 * 使用示例:
 * 		1.按搜索条件（带权限）打印:
 * 		  $.publicPrintFRBySearch(params,querySetting,true);
 * 		2.勾选（带权限）打印:
 * 		  $.publicPrintFRByCheck(params,checkedRecords,'XH','xhs',true);
 * 		3.其他打印（如单打）
 * 		  $.publicPrintFRBySingle(params,true);
 *      注:此处权限只是传参，报表内需自行根据实际情况写条件sql
 */
(function($) {
    $.extend({
    	/**
    	 * 公共打印帆软报表方法(按搜索条件)
    	 * @param params 示例{target:'ifram_name',reportlet:'appName/cptName.cpt',XNXQDM:'2018-2019-2',...}
    	 * @param querySetting
    	 * */
    	publicPrintFRBySearch:function(params,querySetting,needAuth){
    		var self = this;
    		if(querySetting){
    			params = $.extend(params,self.transQSettingToParam(querySetting));
    		}
    		if(needAuth){
			    this.getFRreportAuth({TYPE:params.reportlet}).done(function(res){
				    if(res.code==0&&res.datas.bbqxxr.extParams.code==1){
						var queryId =res.datas.bbqxxr.extParams.msg;
						params['queryId'] = queryId;
			    		self.doPrintFR(params);
					}
				});
    		}else{
	    		self.doPrintFR(params);
    		}
    	},
    	/**
    	 * 公共打印帆软报表方法(按勾选)
    	 * @param params 示例{reportlet:'appName/cptName.cpt',XNXQDM:'2018-2019-2',...}
    	 * @param checkedRecords 勾选数据
    	 * @param key 打印主键
    	 * @param keyName 报表中勾选接收参数的名字，不指定默认为key+'s'
    	 * */
    	publicPrintFRByCheck:function(params,checkedRecords,key,keyName,needAuth){
    		var self = this;
    		if(checkedRecords){
    			params = $.extend(params,self.transCheckedToParam(checkedRecords,key,keyName));
    		}
    		if(needAuth){
			    this.getFRreportAuth({TYPE:params.reportlet}).done(function(res){
				    if(res.code==0&&res.datas.bbqxxr.extParams.code==1){
						var queryId =res.datas.bbqxxr.extParams.msg;
						params['queryId'] = queryId;
			    		self.doPrintFR(params);
					}
				});
    		}else{
	    		self.doPrintFR(params);
    		}
    	},
    	/**
    	 * 公共打印帆软报表方法(单个打印)
    	 * @param params 示例{reportlet:'appName/cptName.cpt',XNXQDM:'2018-2019-2',...}
    	 * */
    	publicPrintFRBySingle:function(params,needAuth){
    		var self = this;
    		if(needAuth){
			    this.getFRreportAuth({TYPE:params.reportlet}).done(function(res){
				    if(res.code==0&&res.datas.bbqxxr.extParams.code==1){
						var queryId =res.datas.bbqxxr.extParams.msg;
						params['queryId'] = queryId;
			    		self.doPrintFR(params);
					}
				});
    		}else{
	    		self.doPrintFR(params);
    		}
    	},
    	/**
    	 * 将勾选的数据根据Key转化为param（只适用于单一主键）
    	 * */
    	transCheckedToParam:function(checkedRecords,key,keyName){
    		var str = "";
    		var result = {};
    		$.each(checkedRecords,function(index,item){
    			str += item[key] + ",";
    		});
    		keyName = keyName?keyName:key+'s';
    		result[keyName] = str.slice(0, -1);
    		return result;
    	},
    	/**
    	 * 将高级搜索转换为打印报表需要的数据格式
    	 *    约定 quickSearch 作为高级搜索中公共搜索文本域的参数名，报表中可如下处理
    	 *    示例:${if(len(quickSearch) == 0, "", " and (t.xh like '%"+quickSearch+"%' or t.xm like '%"+quickSearch+"%') " }   
    	 * */
    	transQSettingToParam:function(querySetting){
    		var report_params = {};
    		//字符串格式则转换
    		if(typeof querySetting == "string"){
    			querySetting = JSON.parse(querySetting);
    		}
    		//遍历querySetting
    		for(var i = 0 ; i < querySetting.length ; i++){
    			if(querySetting[i].length && querySetting[i].length>0){//快速搜索的文本域区域
    				report_params['quickSearch'] = querySetting[i][0].value;
    			}else{
    				report_params[querySetting[i].name] = querySetting[i].value;
    			}
    		}
    		return report_params;
    	},
		/**
		 * querySetting ==>json
		 * @param querySetting
		 * @returns {{}}
		 */
		querySettingToJson: function (querySetting) {
			var report_params = {};
			if (querySetting) {
				var search = JSON.parse(querySetting);
				$.querySettingToJsonss(report_params,search);
			}
			return report_params;
		},
		querySettingToJsonss: function (report_params, search) {
			for (var i = 0; i < search.length; i++) {
				if (Array.isArray(search[i])) {
					$.querySettingToJsonss(report_params, search[i]);
				} else {
					if ("lessEqual" == search[i].builder) {
						report_params[search[i].name + 'END'] = search[i].value;
					} else if ("moreEqual" == search[i].builder) {
						report_params[search[i].name + 'BEGIN'] = search[i].value;
					} else {
						report_params[search[i].name] = search[i].value;
					}
				}
			}
		},
    	/**
    	 * 执行打印操作
    	 * */
    	doPrintFR:function(params){
        	var sum_form=document.createElement("form");
        	sum_form.action=WIS_EMAP_SERV.getContextPath()+"/sys/frReport2/show.do";
        	sum_form.target=params.target?params.target:"_blank";
        	//delete params.target;
        	sum_form.method="post";
        	sum_form.style.display="none";
        	for(var key in params){
	        	var temp=document.createElement("input");
	        	temp.name=key;
	        	temp.value=params[key];
	        	sum_form.appendChild(temp);
        	}
        	document.body.appendChild(sum_form);
        	sum_form.submit();
    	},
		getFRreportAuth: function(param) {
			return $.ajax({
				url: window.WIS_CONFIG.ROOT_PATH+"/sys/jwpubapp/modules/bb/bbqxxr.do",
				data: param,
				parser: function(res) {
				}
			});
		},
		/**
		 * param 传 ID:报表名  PID:上级目录名
		 * */
    	getBBWID:function(param){
    		var bbwid = "";
    		$.ajax({
				url: window.WIS_CONFIG.ROOT_PATH+"/sys/jwpubapp/modules/bb/gjbbidhpidhqbbwid.do",
				data: param,
				async:false,
				success:function(bbxx){
					if(bbxx.code == "0" && bbxx.datas.gjbbidhpidhqbbwid.rows.length > 0){
		    			bbwid = bbxx.datas.gjbbidhpidhqbbwid.rows[0].WID;
		    		}
				}
			});
    		return bbwid;
    	},
    	/**
    	 * 异步打印帆软报表(只适用于个人打印,报表中必传userid为当前用户，系统会自动传此参数，报表中接收)
    	 * {
    	 * 		reportlet:xxx/xxx.cpt,
    	 * 		fileName:'下载文件名'
    	 * 		XNXQDM:'',
    	 * 		.....
    	 * }
    	 * */
    	printFrAsyn:function(params){
    		var token;
        	JWCOMMON.postAsyncAuto(window.WIS_CONFIG.ROOT_PATH+"/sys/jwpubapp/fRQueuePrint/doPrint.do",params,function(resultData){
        		token = resultData.data.token;
        		var msg = '报表计算中...';
        		var waitingSize = resultData.data.waitingSize;
        		if(waitingSize > 10){
        			msg = '当前为打印高峰期，等待时间可能较长，请您耐心等待';
        		}
        		var id = "fr-asyn-print-"+ token;
                BH_UTILS.bhWindow("<div id='" + id + "' style='text-align: center;'>" +
                		"<img style='width:360px;' src='../../jwpubapp/public/images/loading.gif'/>" +
                		"<div style='font-size:16px;' >"+ msg +"</div>" +
                		"</div>"
                		, "生成报表", 
                        [{
                                text:'关闭',
                                className:'bh-btn-default',
                                callback:function(){
                                }
                            }
                        ],
                        {
                            height: 450,
                            width: 500
                        }
                 );
                var $id = $('#' + id);
                var refreshProcess = function() {
                	JWCOMMON.postAsyncAuto(window.WIS_CONFIG.ROOT_PATH+"/sys/jwpubapp/fRQueuePrint/printProgress.do",{token:token},function(resultData){
                		if(resultData.data.isFinished == '1'){
                			var url = window.WIS_CONFIG.ROOT_PATH + '/sys/jwpubapp/fRQueuePrint/getAttachment.do?token='+ token;
                			$id.html("<img style='width:180px;' src='../../jwpubapp/public/images/report.png'/>");
                			$id.append('<a style="display:block;font-size:16px;padding-top: 10px;" href="' + url +'">下载</a>');
                		}else{
                            setTimeout(function() {
                                refreshProcess();
                            }, 2000);
                		}
                	});
                };
                refreshProcess();
        	});
    	}
    });
})(jQuery);

