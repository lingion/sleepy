METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/common/components/jw-bhFormOutline/jw-bhFormOutline.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (5051 字符) --------
(function (window, $) {
    _JW_BOOT_HELPER.addFrameworkInitCallback(function () {
        override();
    });
    function override() {
        var bhFormOutlineShowOld = $.bhFormOutline.show;

        $.bhFormOutline.show = function (options) {
            var formOutlineDefaults = {
                insertContainer: "", //必填，要插入的容器
                scrollContainer: "",
                outlineContainer: "", //可选,要读取的大纲容器,默认使用insetContainer的容器
                width: 0,
                className: "",
                offset: {}, //可选，大纲的偏移量{ top, left, right, bottom}，默认是右对齐
                scrollOffsetTop: $('header[bh-header-role="bhHeader"]').outerHeight(), //可选，锚点定位的位置的top偏移量
                statistics: true, //可选，是否对表单输入进行统计， true默认进行统计,
                affix: true,
                bottom: null,
                customClass: ""
            };

            options = $.extend({}, formOutlineDefaults, options);

            var result = bhFormOutlineShowOld(options);
            if (!options.outlineContainer) {
                options.outlineContainer = options.insertContainer;
            }
            var configUtils = require("configUtils");
            var bhPaperPileDialog = options.outlineContainer.parents('[bh-paper-pile-dialog-role="bhPaperPileDialog"]');
            var isEnableBreadcrumb = configUtils.enableBreadcrumb && bhPaperPileDialog.length;
            if (!isEnableBreadcrumb) { 
                return
            }

            var $formOutline = options.insertContainer.parent().find(".bh-form-outline");

           
          

            if (!options.offset || !options.offset.top || !options.offset.left) {
                options.offset = {
                    right: -256,
                    top: 84
                };
            }

            // var left = options.insertContainer.outerWidth() + options.insertContainer.offset().left + Math.abs(options.offset.right)
            var top = options.insertContainer.offset().top + options.offset.top;
            $formOutline.css({
                position: "fixed",
                right: Math.abs(options.offset.right),
                top: top
            });
            if (!options.scrollContainer || options.length) {
                options.scrollContainer = options.outlineContainer.parents('[bh-paper-pile-dialog-role="bhPaperPileDialogBody"]');
            }
            options.scrollContainer.on('scroll',function() {
                var groupnames = $(this).find('[emap-role="form"] [bh-role-form-outline="title"]')
                var showItems = []
                for(var i = 0 ; i < groupnames.length ; i++) {
                    var item = groupnames[i]
                    var itemTop = $(item).offset().top
                    if(itemTop && itemTop < options.scrollContainer.offset().top + 100 ) {
                        showItems.push(item)
                    }
                }
                if(!showItems.length) {
                    return
                }
                var min = {
                    top: $(showItems[0]).offset().top,
                    ele: showItems[0]
                }
                for(var j = 0 ; j < showItems.length;j++) {
                    if($(showItems[j]).offset().top > min.top) {
                        min = {
                            top: $(showItems[j]).offset().top,
                            ele: showItems[j]
                        }
                    }
                }
                if(min.ele) {
                    var guid = $(min.ele).attr('bh-role-form-outline-item-title-guid')
                    var $active = $formOutline.find('[bh-role-form-outline-fixed-item-guid="'+guid+'"]')
                    $formOutline.find('.bh-form-outline-item').removeClass('bh-active')
                    $active.addClass('bh-active')
                }
            })
            $formOutline.off("click", "div.bh-form-outline-item");
            $formOutline.on("click", "div.bh-form-outline-item", function () {
                var $item = $(this);
                var $formOutline = $item.closest("div[bh-role-form-outline-fixed=bhFormOutline]");
                var guid = $item.attr("bh-role-form-outline-fixed-item-guid");
                var $title = options.outlineContainer.find("[bh-role-form-outline-item-title-guid=" + guid + "]");
                var fixedTop = 0;

               
                fixedTop = $title.offset().top + options.scrollContainer.scrollTop() - options.scrollContainer.offset().top;
                options.scrollContainer.animate(
                    {
                        scrollTop: fixedTop
                    },
                    450
                );

                $formOutline.find("div.bh-form-outline-item").removeClass("bh-active");
                $item.addClass("bh-active");
            });
            return result;
        };
    }
})(window, jQuery);
