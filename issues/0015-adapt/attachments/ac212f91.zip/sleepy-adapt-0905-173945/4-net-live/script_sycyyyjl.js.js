METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwpubapp/public/script/sycyyyjl.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (480 字符) --------
/**
 * 教师端首页常用应用数据记录表
 */
function init() {
    if (userId != '' && roleId != '') {
        gxyysj();
    }
}

function gxyysj() {
    $.ajax({
        url: contextPath + "/sys/jwpubapp/commonUseApp/updateVisitAppCount.do",
        data: {
            "appName": appname,
            "pageCode": window.location.hash.split('/')[1]
        },
        async: false,
        successMsg: '',
        success: function (resp) {
        }
    });
}

init();
