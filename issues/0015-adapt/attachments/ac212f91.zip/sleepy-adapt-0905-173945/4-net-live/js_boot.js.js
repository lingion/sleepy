METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwpubapp/boot/js/boot.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (14615 字符) --------
;(function (window) {

    var _JW_INIT_CONFIG = window._JW_INIT_CONFIG || {};
    // 教务配置，需要定义在<jsp:include page="/sys/jwpubapp/pub/getPubCfg.do">之前
    var _JW_CONFIG = window._JW_CONFIG || {};

    var resResourcePath = _JW_INIT_CONFIG.resResourcePath;

    var contextPath = window.contextPath = _JW_INIT_CONFIG.contextPath;
    window.path = window.location.href;
    var end = window.end = window.path.indexOf('/sys/');
    var context_path = window.context_path = window.path.substring(0, end);
    var appname = window.appname = WIS_CONFIG.APPNAME;
    var appid = window.appid = WIS_CONFIG.APPID;
    var app_path = window.app_path = window.context_path + "/sys/" + window.appname;
    window.roleId = _JW_INIT_CONFIG.ROLEID;
    var userId = window.userId = _JW_INIT_CONFIG.userid;
    var userName = window.userName = _JW_INIT_CONFIG.username;

    var DEBUG = _JW_INIT_CONFIG.DEBUG || false;
    var APP_VERSION = _JW_INIT_CONFIG.APP_VERSION + '';
    
    // 框架加载完成后的回调
    var AFTER_FRAMEWORK_INIT_CALLBACKS = [];
    window._JW_BOOT_HELPER = {
        addFrameworkInitCallback: function(fn){
            if(typeof fn === 'function'){
                AFTER_FRAMEWORK_INIT_CALLBACKS.push(fn);
            }
        }
    };
    
    /**
     * APP_CONFIG
     */
    window.APP_CONFIG = {
        ROOT_PATH: _JW_INIT_CONFIG.ROOT_PATH,
        PATH: _JW_INIT_CONFIG.path,
        APP_VERSION: APP_VERSION,
        MODULE_PATH: app_path + '/modules/',
        FE_DEBUG_MODE: false,
        "ISSENTRY": true,
        /**
         * 业务线开发模式，转测时置false
         */
        "DEBUG_MODE": false,
        /**
         * 资源服务器地址
         */
        "RESOURCE_SERVER": resResourcePath,
        /**
         *
         */
        "BH_VERSION": '1.2',
        /*
         * 主题 blue purple
         */
        "THEME": _JW_INIT_CONFIG.jwAppTheme,

        "firstDayOfWeek": _JW_INIT_CONFIG.firstDayOfWeek + '',
        /**
         * 服务器端生成配置API(API_BASE_PATH目录下)
         * @example "/config.do" ./mock/serverconfig.json
         */
        "SERVER_CONFIG_API": context_path + "/sys/funauthapp/api/getAppConfig/" + appname + "-" + appid + ".do",
        /**
         * APP默认路由
         */
        'APP_ENTRY': "",
        /**
         * 应用底部说明文本
         */
        "FOOTER_TEXT": _JW_INIT_CONFIG.jwAppFooterText,
        "HEADER": {
            "dropMenuCallback": function (item) {
                var pageMeta = window.pageMeta;
                if (item.id == pageMeta.params.ROLEID) {
                    return false;
                }
                var url = WIS_CONFIG.ROOT_PATH + "/sys/funauthapp/api/changeAppRole/" + WIS_CONFIG.APPNAME + "/" + item.id + ".do";
                $.ajax({
                    url: url,
                    type: 'post',
                    async: false,
                    error: function () {
                        $.bhDialog({
                            title: '切换失败',
                            iconType: 'warning'
                        });
                    },
                    success: function (data) {
                        if (data != "" && data != null) {
                            BH_UTILS.doSyncAjax(WIS_CONFIG.ROOT_PATH + '/sys/jwpubapp/pub/setJwCommonAppRole.do', {
                                "ROLEID": item.id
                            });
                            location.href = location.href.replace(/&?gid_=[^&]*/, '').replace(/&?_yhz=[^&]*/, '').replace(/#.*/, '');
                        }
                    }
                });
            },
            "logo": _JW_INIT_CONFIG.indexLogoUrl,
            "icons": ["icon-apps"],
            "userInfo": {
                "image": resResourcePath + "/scenes/public/images/demo/user1.png",
                "info": [
                    userId,
                    userName
                ]
            }
        },
        "AFTER_FRAMEWORK_INIT": function () {
            AFTER_FRAMEWORK_INIT_CALLBACKS.forEach(function(cb){
                cb && cb();
            });
            WIS_EMAP_CONFIG['emapdatatable.fxss'] = true;
            WIS_EMAP_CONFIG['emapdatatable.isOnceEmpty'] = _JW_INIT_CONFIG.emapdatatableIsOnceEmpty === 'true';
            window.emapdatatableDefaultPageSize = _JW_INIT_CONFIG.emapdatatableDefaultPageSize;
            window.emapdatatableDefaultHeight = _JW_INIT_CONFIG.emapdatatableDefaultHeight;
            window.exportZipMaXFileNum = Number(_JW_INIT_CONFIG.exportZipMaXFileNum);
            window.platformDomainName = _JW_INIT_CONFIG.platformDomainName;

            if (!window.finishSetJwCommonAppRole) {
                BH_UTILS.doSyncAjax(WIS_CONFIG.ROOT_PATH + '/sys/jwpubapp/pub/setJwCommonAppRole.do', {
                    "ROLEID": pageMeta.params.ROLEID
                });
                window.finishSetJwCommonAppRole = true;
            }

            if (window.BH_UTILS && typeof window.BH_UTILS.bhWindow === 'function') {
                var _bhWindow = window.BH_UTILS.bhWindow;
                window.BH_UTILS.bhWindow = function (content, title, btns_def,
                                                     params, callback) {
                    var maxWidth = $(window).width() - 200;
                    var maxheight = $(window).height() - 40;
                    params = params || {};
                    var width = params.width;
                    var height = params.height;
                    if (typeof content === 'string' && content.indexOf('bh-customize-content') == -1) {//自定义的弹框里面有这个样式。
                        width = width || 500;
                        height = height || 600;
                    }
                    if (width === undefined || width === null) {
                        width = maxWidth * 3 / 4;
                    }
                    if (typeof width === 'string') {
                        width = parseFloat(width.replace('px', '').replace('%', ''));
                    }
                    if (width > maxWidth) {
                        width = maxWidth;
                    }
                    params.width = width;
                    if (height != 'auto') {
                        if (height === undefined || height === null) {
                            height = maxheight * 3 / 4;
                        }
                        if (typeof height === 'string') {
                            height = parseFloat(height.replace('px', '').replace('%', ''));
                        }
                        if (height > maxheight) {
                            height = maxheight;
                        }
                        params.height = height;
                    }
                    return _bhWindow(content, title, btns_def, params, callback);
                }
            }

            if ($.bh_choose && typeof $.bh_choose === 'function') {
                var _bhChoose = $.bh_choose;
                $.bh_choose = function (params) {
                    params.leftRendered = function () {
                    };
                    var maxheight = $(window).height() - 40;
                    params = params || {};
                    var height = params.height || 300;
                    if (height === undefined || height === null) {
                        height = maxheight * 3 / 4;
                    }
                    if (typeof height === 'string') {
                        height = parseFloat(height.replace('px', '').replace('%', ''));
                    }
                    if (height > maxheight) {
                        height = maxheight;
                    }
                    params.height = height + 'px';
                    params.scrollYEnable = true;
                    return _bhChoose(params);
                }
                $.bh_choose['default'] = _bhChoose['default'];
            }
        }
    };

    window.APP_CFG = {
        "app_footer": _JW_INIT_CONFIG.jwAppFooterText,
        "app_theme": _JW_INIT_CONFIG.jwAppTheme,
        "res_server_path": resResourcePath,
        "indexLogoUrl": _JW_INIT_CONFIG.indexLogoUrl,
        "header": {
            "dropMenuCallback": function (item) {
                if (item.id == pageMeta.params.ROLEID) {
                    return false;
                }
                var url = WIS_CONFIG.ROOT_PATH
                    + "/sys/funauthapp/api/changeAppRole/"
                    + WIS_CONFIG.APPNAME + "/" + item.id + ".do";
                $.ajax({
                    url: url,
                    type: 'post',
                    data: 'selectedRoleId=' + item.id,
                    async: false,
                    error: function () {
                        $.bhDialog({
                            title: '切换失败',
                            iconType: 'warning'
                        });
                    },
                    success: function (data) {
                        if (data != "" && data != null) {
                            BH_UTILS.doSyncAjax(WIS_CONFIG.ROOT_PATH + '/sys/jwpubapp/pub/setJwCommonAppRole.do', {
                                "ROLEID": item.id
                            });
                            location.href = location.href.replace(
                                /&?gid_=[^&]*/, '').replace(/&?_yhz=[^&]*/,
                                '').replace(/#.*/, '');
                        }
                    }
                });
            },
            "logo": _JW_INIT_CONFIG.indexLogoUrl,
            "icons": ["icon-apps"],
            "userInfo": {
                "image": resResourcePath + "/scenes/public/images/demo/user1.png",
                "info": [userId, userName]
            }
        }
    };

    var RESOURCE_CONFIG = {
        RES_BASE_CSS: [
            'bower_components/summernote-0.8.1/dist/summernote-bs3.min.css',
            'bower_components/summernote-0.8.1/dist/summernote.css',
            'bower_components/material-design-iconic-font/css/material-design-iconic-font.css'
        ],
        /*RES_BASE_JS: [
            'fe_components/commonlib.js',
            _getMin('bower_components/bootstrap/dist/js/bootstrap') + '.js',
            'bower_components/summernote-0.8.1/dist/summernote.js',
            'bower_components/cropper/cropper.min.js',
            _getMin('fe_components/appcore', '-') + '.js'
        ],*/
        COMMON_CSS: [
            'jwpubapp/public/css/publicStyle.css',
            'jwpubapp/public/script/zeroPlugin/dist/zero-plugin.min.css',
            'jwpubapp/public/script/doc/doc.css',
            'jwcommon/public/css/jwPackagingMethod.css'
        ],
        COMMON_JS: [
            _getMin('jwpubapp/public/script/publicfrreport/vue2') + '.js',
            // 'jwpubapp/public/script/publicfrreport/vue2.min.js',
            'jwpubapp/public/script/publicfrreport/public-frreport.js',
            'jwpubapp/public/script/jwcommon.js',
            'stateapp/public/js/common.js',
            'jwpubapp/public/script/jwrzlb.js',
            _getMin('jwcommon/public/script/jwPackagingMethod') + '.js',
            'jwcommon/public/script/goldenfinger/goldenfingerPlugins.js',
            'jwcommon/public/script/goldenfinger/goldenfinger.js',
            //首页常用应用记录js
            'jwpubapp/public/script/sycyyyjl.js',
            'jwcommon/public/script/common/jsloader.js'
        ],
        IE_SUPPORT_JS: [
            'jwcommon/public/script/common/lib/bluebird/bluebird.min.js'
        ],
        DEBUG_JS: [
            resResourcePath + '/fe_components/bh-1.2.js'
        ]
    }

    function _init() {
        // 初始化之前的回调
        _JW_CONFIG.beforeInit && _JW_CONFIG.beforeInit(RESOURCE_CONFIG);
        _initCss();
        _initJs();
        // 初始化之后的回调
        _JW_CONFIG.afterInit && _JW_CONFIG.afterInit();
    }

    _init();

    function _initCss() {
        // 先加载res的css
        var resCss = RESOURCE_CONFIG.RES_BASE_CSS;
        for (var i = 0; i < resCss.length; i++) {
            _createCss(resResourcePath + '/' + resCss[i]);
        }
        // 再加载本业务线通用的css
        var commonCss = RESOURCE_CONFIG.COMMON_CSS;
        for (var j = 0; j < commonCss.length; j++) {
            _createCss(contextPath + '/sys/' + commonCss[j]);
        }
    }

    function _initJs() {
        // 先加载res的js，res的js属于跨域，使用document.write会导致Chrome警告
        /*var resJs = RESOURCE_CONFIG.RES_BASE_JS;
        for (var i = 0; i < resJs.length; i++) {
            _createScript(resResourcePath + '/' + resJs[i]);
        }*/
        // 再加载本业务线通用的js
        var commonJs = RESOURCE_CONFIG.COMMON_JS;
        for (var j = 0; j < commonJs.length; j++) {
            _createScript(contextPath + '/sys/' + commonJs[j]);
        }
        if(isIE()){
            // 兼容IE的一些JS
            var ieSupportJs = RESOURCE_CONFIG.IE_SUPPORT_JS;
            for (var k = 0; k < ieSupportJs.length; k++) {
                _createScript(contextPath + '/sys/' + ieSupportJs[k]);
            }
        }
    }

    function isIE() {
        return !!window.ActiveXObject || "ActiveXObject" in window;
    }

    function _getMin(path, suffix) {
        suffix = suffix || '.';
        return DEBUG ? path : path + suffix + 'min';
    }

    function _createScript(url) {
        /*var script = document.createElement('script');
        script.type = 'text/javascript';
        document.getElementsByTagName('head')[0].appendChild(script);*/
        var src = url + '?av=' + APP_VERSION;
        document.write('<script type="text/javascript" src="' + src + '"></script>');
    }


    function _createCss(url) {
        var link = document.createElement('link');
        link.type = 'text/css';
        link.rel = 'stylesheet';
        link.href = url + '?av=' + APP_VERSION;
        document.getElementsByTagName('head')[0].appendChild(link);
    }

    /**
     * 提供一个控制台方法方便DEBUG某些文件的源代码
     * @private
     */
    window.__loadJwDebugJs = function () {
        if (!DEBUG) {
            return;
        }
        // DEBUG模式下加载的js
        _.each(RESOURCE_CONFIG.DEBUG_JS, function (url) {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = url + '?av=' + APP_VERSION;
            document.getElementsByTagName('head')[0].appendChild(script);
        });
    }
})(window);