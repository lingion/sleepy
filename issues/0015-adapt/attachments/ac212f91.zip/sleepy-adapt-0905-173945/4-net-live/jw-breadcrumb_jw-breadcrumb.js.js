METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/common/components/jw-breadcrumb/jw-breadcrumb.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (64454 字符) --------
(function (window, $) {
    var BASE_PATH = contextPath + "/sys/jwcommon/public/script/common/components/jw-breadcrumb/";
    var urlParams = null;
    var __IS_MIN_FLAG = false;
    /**
     * @module jwBreadcrumb
     * @description 面包屑
     * @example
     $.jwBreadcrumb.show({
        content: '' //html内容
     });
     */
    $(document).on("click", "[jw-breadcrumb]", function () {
        var active_id = $.trim($(this).attr("jw-breadcrumb"));
        var data = {
            openDialogDom: $(this)
        };

        if (active_id) {
            data.content = $("#" + active_id).html();
        }

        $.jwBreadcrumb.show(data);
    });
    // 点击nav 清除body绑定数据
    $(document).on("click", "a[bh-header-role] .bh-headerBar-nav-item", function () {
        $("body").data("bh-paper-pile-dialog", []);
    });

    /**
     * 面包屑。
     */
    $.jwBreadcrumb = {
        /**
         * 初始化并显示弹框
         * @method show
         * @param options {object} 初始化参数
         * @param options.titleContainer {jQuery} 可选，弹框父层的title
         * @param options.insertContainer {jQuery} 可选，想要将弹框插入的容器
         * @param options.referenceContainer {jQuery} 可选，弹框要参考的容器，主要用于获取容器的宽度和位置
         * @param options.addDialogFlagClass {string} 可选，想要在弹出框中添加的样式类名
         * @param options.toHideContainer {jQuery} 可选，显示弹框时,要隐藏的容器
         * @param options.title {string} 可选，弹出框的title,可在content中添加,请参考example
         * @param options.content {string} 必填，在弹出框中显示的内容
         * @param options.footer {string} 可选，在弹出框页脚,可在content中添加,请参考example
         * @param options.aside {string} 可选，在弹出框页脚,可在content中添加,请参考example
         * @param options.close {callback} 可选，当关闭弹框的回调
         * @param options.closeBefore {callback} 可选，当关闭弹框前的回调,返回true不关闭弹框,返回false关闭弹框
         * @param options.ready {callback} 可选，初始化且动画执行完成的回调
         * @param options.render {callback} 可选，dom节点生成并插入页面时的回调，此时动画未完成
         * @example
         $.jwBreadcrumb.show({
            content: '' //html内容
         });
         */
        show: function (options) {
            urlParams = require("utils").getUserParams();
            __IS_MIN_FLAG = urlParams && urlParams.min && urlParams.min === "1";
            var dialogDefaults = {
                openDialogDom: "",
                //隐藏属性,保存通过属性按钮打开弹框的节点
                titleContainer: "",
                //必填，父层的title
                insertContainer: $("#levityPlaceholder"),
                //可选，想要将dialog插入的容器
                referenceContainer: "",
                //必填，dialog要参考的容器，主要用于获取容器的宽度和位置
                addDialogFlagClass: "",
                //可选，想要在弹出框中添加的类名，一般用在有多个弹出框时能做操作，
                toHideContainer: "",
                //可选，要隐藏的容器，主要用于当弹框内容过少，无法完全遮盖已经存在的内容
                multipleHideContainer: [],
                //用于处理多重弹框时,其他内容没有隐藏的问题
                hideCloseIcon: false,
                //可选，隐藏关闭按钮，false不隐藏
                title: "",
                // 可选，面包屑标题
                breadCrumbTitle: "",
                // 可选，隐藏h2标题
                hideTitle: false,
                //必填，弹出框的title
                content: "",
                //必填，在弹出框中显示的内容，一般是html标签
                footer: "",
                //可选，在弹出框页脚中显示的按钮，html标签
                aside: "",
                //隐藏字段，在固定html结构中存放侧边栏弹框用
                close: null,
                //可选，当关闭的回调，关闭时自动将弹框销毁
                autoDestroy: true,
                //可选, 隐藏时自动销毁，默认销毁
                closeBefore: null,
                //可选，当关闭前的回调
                open: null,
                //可选，每次打开弹出框后的回调，不包括第一次的初始化
                openBefore: null,
                //可选，每次打开弹出框前的回调，不包括第一次的初始化
                ready: null,
                //可选，初始化并渲染完成的回调
                render: null //dom节点生成并插入页面时就调用，此时动画未完成
            };
            options = $.extend({}, dialogDefaults, options);
            $(window).scrollTop(0);
            showDialog(options);
        },

        /**
         * 当弹框高度发生变化时,重置页面页脚的位置
         * @method resetPageFooter
         * @param options {object} 参数
         * @param options.titleContainer {jQuery} 可选，弹框父层的title
         * @param options.insertContainer {jQuery} 可选，想要将弹框插入的容器
         * @param options.referenceContainer {jQuery} 可选，弹框要参考的容器，主要用于获取容器的宽度和位置
         * @param options.guid {string} 可选，该弹框动态生成出来的guid
         * @example
         $.jwBreadcrumb.resetPageFooter();
         */
        resetPageFooter: function (options) {
            return;
            //当弹出框的高度发生变化时，重设页脚高度
            // var dialogDefaults = {
            //     titleContainer: "", //可选，父层的title
            //     referenceContainer: "", //可选，想要将dialog插入的容器
            //     dialogContainer: "", //可选，弹出框容器
            //     guid: "" //可选，弹出框的guid
            // };
            // options = $.extend({}, dialogDefaults, options);
            // resetPageFooter(options);
        },
        //重设弹框的最小高度
        resetMinHeight: function (options) {
            var dialogDefaults = {
                titleContainer: "",
                //可选，与弹出框关联的title容器
                referenceContainer: "",
                //可选，与弹出框关联的内容容器
                guid: "" //可选，弹出框的guid
            };
            options = $.extend({}, dialogDefaults, options);
            resetDialogMinHeight(options);
        },

        /**
         * 当弹框高度发生变化时,重置弹框页脚的位置
         * @method resetDialogFooter
         * @param options {object} 参数
         * @param options.titleContainer {jQuery} 可选，弹框父层的title
         * @param options.referenceContainer {jQuery} 可选，弹框要参考的容器，主要用于获取容器的宽度和位置
         * @example
         $.jwBreadcrumb.resetDialogFooter();
         */
        resetDialogFooter: function (options) {
            // $(window).scrollTop(($(window).scrollTop()||0)+1) //JW-24268 ,XG-14429修复设置DialogFooter不起作用   王敏 2022-05-25
            return;
            // var dialogDefaults = {
            //     titleContainer: "", //可选，与弹出框关联的title容器
            //     referenceContainer: "" //可选，与弹出框关联的内容容器
            // };
            // options = $.extend({}, dialogDefaults, options);
            // resetDialogFooter(options);
        },

        /**
         * 关闭弹框
         * @method hide
         * @param options {object} 参数
         * @param options.titleContainer {jQuery} 可选，弹框父层的title
         * @param options.referenceContainer {jQuery} 可选，弹框要参考的容器，主要用于获取容器的宽度和位置
         * @param options.guid {string} 可选，该弹框动态生成出来的guid
         * @param options.isHideAll {boolean} 可选，true删除所有弹框,默认false
         * @param options.ignoreAllCallback {boolean} 可选，true忽略所有的回调方法,默认false
         * @param options.ignoreCloseCallback {boolean} 可选，true忽略close的回调方法,默认false
         * @param options.ignoreCloseBeforeCallback {boolean} 可选，true忽略closeBefore的回调方法,默认false
         * @example
         $.jwBreadcrumb.hide();
         */
        hide: function (options) {
            var dialogDefaults = {
                titleContainer: "",
                //可选，与弹出框关联的title容器
                referenceContainer: "",
                //可选，与弹出框关联的内容容器
                guid: "",
                //可选，弹出框的guid
                isHideAll: false,
                //可选，true删除所有弹框
                ignoreAllCallback: false,
                //忽略所有的回调方法
                ignoreCloseCallback: false,
                //忽略close的回调方法
                ignoreCloseBeforeCallback: false,
                //忽略closeBefore的回调方法
                destroy: true //可选，值为true或false； true则在隐藏的同时将弹出框remove
            };
            options = $.extend({}, dialogDefaults, options);
            dialogHide(options);
        },
        destroy: function (options) {
            var dialogDefaults = {
                titleContainer: "",
                //可选，与弹出框关联的title容器
                referenceContainer: "",
                //可选，与弹出框关联的内容容器
                guid: "" //可选，弹出框的guid
            };
            options = $.extend({}, dialogDefaults, options);
            dialogDestroy(options);
        }
    };

    /***
     * titleContainer 必填，父层的title
     * referenceContainer 必填，想要将dialog插入的容器
     * addDialogFlagClass 可选，想要在弹出框中添加的类名，一般用在有多个弹出框时能做操作
     * title 必填，弹出框的title
     * content 必填，在弹出框中显示的内容，一般是html标签
     * footer 可选，在弹出框页脚中显示的按钮，html标签
     * close 可选，当关闭的回调
     * show 可选，每次打开弹出框后的回调，不包括第一次的初始化
     * ready 可选，初始化并渲染完成的回调
     */
    function showDialog(options) {
        var $body = $("body");

        var $pageHeader = $("#pageHeader");
        var $normalHeader = $pageHeader.children('[bh-header-role="bhHeader"]');
        if ($normalHeader.hasClass("bh-normalHeader-hide")) {
            $normalHeader.removeClass("bh-normalHeader-hide").addClass("bh-normalHeader-show");
            $pageHeader.children('[bh-header-role="bhHeaderMini"]').removeClass("bh-miniHeader-show").addClass("bh-miniHeader-hide");
            $pageHeader.children(".bh-header-bg").removeClass("").addClass("bh-headerBg-hide");
        }

        var $dialog = "";
        var $insertToDialog = getTheNewestOpenDialog();

        //重置titleContainer,referenceContainer,toHideContainer，使其兼容固定的html结构
        options = resetOptionContainer(options, $insertToDialog);

        if ($insertToDialog.length > 0) {
            //如果要加入的父层是paper对话框，将父层弹出框的边框去掉，对于多层弹框有用
            $insertToDialog.find(".bh-paper-pile-closeIcon").hide();
            $insertToDialog.find(".jw-breadcrumb-container").addClass("bh-bg-transparent");
        }

        setTimeout(function () {
            //隐藏父层弹框的内容，避免子级弹框的内容过少，会看到父级的内容
            if ($insertToDialog.length > 0) {
                $insertToDialog.find("div[jw-breadcrumb-role=jwBreadcrumbBody]").hide();
            } else {
                //将内容的border去掉
                var $layoutContainer;
                var fixedArticle = getFixedArticle();
                if (fixedArticle) {
                    $layoutContainer = fixedArticle;
                } else {
                    $layoutContainer = $("[bh-container-role=container]");
                }
                if ($layoutContainer && $layoutContainer.length > 0) {
                    $layoutContainer.addClass("bh-border-transparent").addClass("bh-bg-transparent");
                }
            }
        }, getAnimateTime());

        //若弹框之前创建过且没有remove，则直接显示，否则新建一个
        var existGuid = options.titleContainer.attr("jw-breadcrumb-role-title-guid");
        if (existGuid) {
            $dialog = $("div[jw-breadcrumb-role-guid=" + existGuid + "]");
            $dialog.removeClass("bh-negative-zIndex").show();
            // $dialog.find("div.jw-breadcrumb-container").removeClass("jw-breadcrumb-outDown").addClass("jw-breadcrumb-intoUp");

            setTimeout(function () {
                if (typeof options.open != "undefined" && options.open instanceof Function) {
                    //执行再次打开的回调
                    options.open();
                }
            }, getAnimateTime() * 2);

            if (typeof options.openBefore != "undefined" && options.openBefore instanceof Function) {
                //执行再次打开的回调
                options.openBefore();
            }
        } else {
            //创建guid与绑定的title容器和内容容器关联
            var guid = NewGuid();
            var dialogHtml = getDialogHtml();
            options = getContentHtml(options);
            var footerContentHtml = "";
            var footerClass = "bhFooterNoActiveFlag";
            if (options.footer) {
                footerContentHtml = options.footer;
                //为多重弹框隐藏页脚用
                footerClass = "";
            }
            var layoutRole = options.layoutRole ? options.layoutRole : "";
            var layoutClass = options.layoutClass ? options.layoutClass : "";

            var titleOffset = options.titleContainer.offset();
            if (!titleOffset) {
                paperConsole("触发面包屑的页面没有h2");
            }
            //设置弹框的位置和宽度
            var dialogStyle = "";

            if (__IS_MIN_FLAG) {
                dialogStyle += "top: 0;";
                dialogStyle += "width: 100%;";
                dialogStyle += "max-width:none;";
                dialogStyle += "height: 100%;";
            } else {
                dialogStyle += "top: 44px;";
                dialogStyle += "width: 96%;";
                dialogStyle += "max-width:1584px;";
                dialogStyle += "height: calc(100% - 76px);";
            }
            // RESQD-39 添加纸质弹窗宽度自适应，将width从固定值改成百分比并居中
            dialogStyle += "left:0;";
            dialogStyle += "right:0;";
            dialogStyle += "margin:0 auto;";
            //68是弹框的头部高度

            dialogHtml = dialogHtml
                .replace("@title", options.title)
                .replace("@footerHtml", footerContentHtml)
                .replace("@footerClass", footerClass)
                .replace("@content", options.content)
                .replace("@guid", guid)
                .replace("@style", dialogStyle)
                .replace(/@layoutRole/g, layoutRole)
                .replace("@layoutClass", layoutClass);
            //当出现多重弹框时，将已存在的弹框信息放到body上
            var dialogIndex = 1;
            var existDialogData = $body.data("bh-paper-pile-dialog");
            //多重弹框从父层删除,传入id错误的处理  ----9/21  ghlong
            var saveDialogData = {
                titleContainer: options.titleContainer,
                insertContainer: options.insertContainer,
                referenceContainer: options.referenceContainer,
                addDialogFlagClass: options.addDialogFlagClass,
                toHideContainer: options.toHideContainer,
                close: options.close,
                autoDestroy: options.autoDestroy,
                closeBefore: options.closeBefore,
                ignoreAllCallback: options.ignoreAllCallback,
                guid: guid,
                index: dialogIndex,
                breadCrumbTitle: options.breadCrumbTitle || ""
            };
            if (existDialogData) {
                dialogIndex = existDialogData.length + 1;
                saveDialogData.index = dialogIndex;
                existDialogData.push(saveDialogData);
            } else {
                existDialogData = [saveDialogData];
            }
            var breadcrumbTemp = getBreadcrumb(existDialogData, options);

            dialogHtml = dialogHtml.replace("@breadcrumb", breadcrumbTemp);
            //将弹框添加到body
            $dialog = $(dialogHtml);

            if (options.insertContainer.length === 0) {
                options.insertContainer = $body;
            }

            //当title没有的时候，隐藏title的div
            if (!options.title) {
                $dialog.find("div[bh-paper-pile-dialog-role=bhPaperPileDialogHeader]").hide();
                if (!options.layoutRole || options.layoutRole.indexOf("navLeft") === -1) {
                    $dialog.find("div[bh-paper-pile-dialog-role=bhPaperPileDialogBody]").css("margin-top", "24px");
                }
            }
            if (options.hideTitle) {
                $dialog.find("h2").hide();
            }
            //隐藏关闭按钮
            if (options.hideCloseIcon) {
                $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogCloseIcon]").hide();
            }

            //将aside加入弹框结构中
            if (options.aside) {
                $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogFooter]").before(options.aside);
            } else {
                $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogFooter]").before('<aside bh-paper-pile-dialog-role="aside"></aside>');
            }
            options.insertContainer.append($dialog);
            if ($dialog.find(".bh-paper-pile-body > section").length) {
                if (!$dialog.find(".bh-paper-pile-body > section").css("height")) {
                    $dialog.find(".bh-paper-pile-body > section").css("height", "100%");
                }
                if (!$dialog.find(".bh-paper-pile-body > section").css("overflow")) {
                    $dialog.find(".bh-paper-pile-body > section").css("overflow", "hidden auto");
                }
            }
            var breadcrumbHeight = $dialog.find(".jw-breadcrumb-wrapper").outerHeight();
            var titleHeight = $dialog.find("h2").outerHeight();
            var bodyheight = 0;
            if (options.hideTitle) {
                bodyheight = __IS_MIN_FLAG ? breadcrumbHeight : breadcrumbHeight - 1;
            } else {
                bodyheight = __IS_MIN_FLAG ? breadcrumbHeight + titleHeight : breadcrumbHeight + titleHeight - 1;
            }
            $dialog.find('[bh-paper-pile-dialog-role="bhPaperPileDialogBody"]').css("height", "calc(100% - " + bodyheight + "px)");
            $body.data("bh-paper-pile-dialog", existDialogData);
            //设置当前弹框的index和高度
            $dialog.attr("bh-paper-pile-dialog-role-index", dialogIndex);
            options.titleContainer.attr("bh-paper-pile-dialog-role-title-guid", guid);
            options.referenceContainer.attr("bh-paper-pile-dialog-role-container-guid", guid);
            //给要隐藏的容器加guid
            if (options.toHideContainer) {
                var hideContLen = options.toHideContainer.length;
                if (hideContLen > 1) {
                    for (var i = 0; i < hideContLen; i++) {
                        options.toHideContainer[i].attr("bh-paper-pile-dialog-role-hide-container-guid", guid);
                    }
                } else {
                    options.toHideContainer.attr("bh-paper-pile-dialog-role-hide-container-guid", guid);
                    var multiple_hide_container = options.multipleHideContainer;
                    var multiple_hide_container_len = multiple_hide_container.length;
                    if (multiple_hide_container_len > 0) {
                        for (var k = 0; k < multiple_hide_container_len; k++) {
                            var multiple_item = multiple_hide_container[k];
                            if (multiple_item.length > 0) {
                                multiple_item.attr("bh-paper-pile-dialog-role-hide-container-guid", guid);
                            }
                        }
                    }
                }
            }

            //若用户有要添加的样式类，则加入到弹框中
            if (options.addDialogFlagClass) {
                $dialog.addClass(options.addDialogFlagClass);
            }

            if (options.footer) {
                //操作栏定高66px
                var dialogPaddingBottom = 66;
                $dialog.find("div[bh-paper-pile-dialog-role=bhPaperPileDialogBody]").css({
                    "padding-bottom": dialogPaddingBottom
                });
            }

            $dialog.data("closeFun", options.close);
            $dialog.data("closeBeforeFun", options.closeBefore);

            //获取该弹框的header，section，footer，aside的jquery对象
            var dialogParts = getDialogPartDom($dialog);

            if (options.compile) {
                options.compile(dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside);
            }

            setTimeout(function () {
                //动画结束后再进行事件绑定，避免动画未结束时点击关闭，导致显示错误
                //弹出框事件绑定
                dialogEventListen($dialog, options);

                if (options.openDialogDom.length > 0) {
                    options.openDialogDom.attr("jw-breadcrumb-bind-btn", guid);
                    options.openDialogDom.trigger("ready", [dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside]);
                }

                if (typeof options.ready != "undefined" && options.ready instanceof Function) {
                    //执行初始化完成事件，并将对应节点的jquery对象返回
                    options.ready(dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside);
                }
            }, getAnimateTime() * 2 + 10);

            if (options.openDialogDom.length > 0) {
                options.openDialogDom.trigger("render", [dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside]);
            }

            if (typeof options.render != "undefined" && options.render instanceof Function) {
                var dialogParts = getDialogPartDom($dialog);
                //执行初始化完成事件，并将对应节点的jquery对象返回
                options.render(dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside);
            }
        }

        //将要隐藏的容器隐藏
        if (options.toHideContainer) {
            var hideContLen = options.toHideContainer.length;
            if (hideContLen > 1) {
                for (var i = 0; i < hideContLen; i++) {
                    options.toHideContainer[i].hide();
                }
            } else {
                options.toHideContainer.hide();

                var multiple_hide_container = options.multipleHideContainer;
                var multiple_hide_container_len = multiple_hide_container.length;
                if (multiple_hide_container_len > 0) {
                    for (var k = 0; k < multiple_hide_container_len; k++) {
                        var multiple_item = multiple_hide_container[k];
                        if (multiple_item.length > 0) {
                            multiple_item.hide();
                        }
                    }
                }
            }
        }
        if (options.titleContainer) {
            options.titleContainer.hide();
        }

        setTimeout(function () {
            //给弹出框的页脚添加浮动属性
            dialogFooterToFixed($dialog, options);

            //移除弹框动画，避免fixed属性不可用
            $dialog.find("div.jw-breadcrumb-container").removeClass("jw-breadcrumb-intoUp");
            setTimeout(function () {
                //调整底部渲染的时间 王敏  2022-06-15
                setCurrentFooterPosition($dialog);
            }, 10);
            //给按钮添加水波纹效果
            BH_UTILS && BH_UTILS.wavesInit();
        }, getAnimateTime() * 2);

        // $('[bh-footer-role=footer]').hide();
    }
    function getBreadcrumb(existDialogData, options) {
        var temp = '<div class="jw-breadcrumb-wrapper' + (options.hideTitle ? " bh-pb-16" : "") + '">';
        existDialogData.forEach(function (item, index) {
            if (existDialogData[index - 1] && existDialogData[index - 1].breadCrumbTitle && $.type(existDialogData[index - 1].breadCrumbTitle) === "string") {
                temp +=
                    '<div class="jw-breadcrumb-item bh-str-cut jw-breadcrumb-item-link" title="' +
                    existDialogData[index - 1].breadCrumbTitle +
                    '" jw-breadcrumb-item-role-title-guid="' +
                    item.guid +
                    '">' +
                    existDialogData[index - 1].breadCrumbTitle +
                    "</div>";
            } else {
                var title = item.titleContainer.prop("firstChild").nodeValue;
                if (!title.trim() && item.titleContainer.children().length) {
                    title = item.titleContainer.find("*:first").text();
                }
                temp += '<div class="jw-breadcrumb-item bh-str-cut jw-breadcrumb-item-link" title="' + title + '" jw-breadcrumb-item-role-title-guid="' + item.guid + '">' + title + "</div>";
            }
        });

        if (options.title) {
            if (options.breadCrumbTitle && $.type(options.breadCrumbTitle) === "string") {
                temp += '<div class="jw-breadcrumb-item bh-str-cut" title="' + options.breadCrumbTitle + '">' + options.breadCrumbTitle + "</div>";
            } else {
                temp += '<div class="jw-breadcrumb-item bh-str-cut" title="' + $(options.title).prop("firstChild").nodeValue + '">' + $(options.title).prop("firstChild").nodeValue + "</div>";
            }
        } else {
            temp += '<div class="jw-breadcrumb-item bh-str-cut" title="****">****</div>';
        }

        temp += "</div>";
        return temp;
    }
    //获取该弹框的header，section，footer，aside的jquery对象
    function getDialogPartDom($dialog) {
        // var $dialogHeader = $dialog.find("[jw-breadcrumb-role=jwBreadcrumbHeader]");
        // var $dialogBody = $dialog.find("[jw-breadcrumb-role=jwBreadcrumbBody]");
        // var $dialogSection = $dialogBody.children("section");
        // var $dialogAside = $dialog.find("[jw-breadcrumb-role=aside]");
        // var $dialogFooter = $dialog.find("[jw-breadcrumb-role=jwBreadcrumbFooter]").children("footer");

        var $dialogHeader = $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogHeader]");
        var $dialogBody = $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogBody]");
        var $dialogSection = $dialogBody.children("section");
        var $dialogAside = $dialog.find("[bh-paper-pile-dialog-role=aside]");
        var $dialogFooter = $dialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogFooter]").children("footer");
        return {
            dialogHeader: $dialogHeader,
            dialogSection: $dialogSection,
            dialogFooter: $dialogFooter,
            dialogAside: $dialogAside
        };
    }

    function getBindBtn(guid) {
        return $('[jw-breadcrumb-bind-btn="' + guid + '"]');
    }

    /***
     * 重新设置option的container数据
     * @param options
     * @param $insertToDialog 当存在多层弹框时，该值是最新弹出的弹框层
     * @returns {*}
     */
    function resetOptionContainer(options, $insertToDialog) {
        if ($insertToDialog) {
            options = resetContainerHandle(options, $insertToDialog, true);
        } else {
            var fixedArticle = getFixedArticle();
            if (fixedArticle && fixedArticle.length > 0) {
                options = resetContainerHandle(options, fixedArticle, false);
            }
        }
        return options;
    }

    /***
     * 对option进行赋值
     * @param options
     * @param $dom
     * @param isDialogFlag true是存在多层弹框
     * @returns {*}
     */
    function resetContainerHandle(options, $dom, isDialogFlag) {
        if ($dom && $dom.length > 0) {
            if (!options.titleContainer) {
                if (isDialogFlag) {
                    options.titleContainer = $dom.find("[bh-paper-pile-dialog-role=bhPaperPileDialogHeader]");
                    // options.titleContainer = $('h2[jw-breadcrumb-role-guid="' + $dom.attr("jw-breadcrumb-role-guid") + '"]');
                } else {
                    if ($dom.children("h2").length > 0) {
                        options.titleContainer = $dom.children("h2");
                    } else {
                        options.titleContainer = $dom.children("hgroup");
                    }
                }
            }
            if (!options.referenceContainer) {
                options.referenceContainer = isDialogFlag ? $dom.find("[jw-breadcrumb-role=jwBreadcrumbBody]") : $dom;
            }
            if (!options.toHideContainer) {
                if (isDialogFlag) {
                    var $referenceDialog = options.referenceContainer.closest("[bh-paper-pile-dialog-role=bhPaperPileDialog]");
                    options.toHideContainer = $referenceDialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogBody]");

                    var $aside = $referenceDialog.children(".bh-paper-pile-dialog-container").children("aside");
                    var $footer = $referenceDialog.find('[bh-paper-pile-dialog-role="bhPaperPileDialogFooter"]');
                    var $pageFooter = $referenceDialog.find('[bh-paper-pile-dialog-role="pageFooter"]');
                    options.multipleHideContainer.push($aside);
                    options.multipleHideContainer.push($pageFooter);
                    if (!$footer.hasClass("bhFooterNoActiveFlag")) {
                        options.multipleHideContainer.push($footer);
                    }
                } else {
                    var layoutType = $dom.attr("bh-layout-role");
                    if (layoutType && layoutType.indexOf("navLeft") > -1) {
                        options.toHideContainer = [$dom.children("section"), $dom.children("nav")];
                    } else {
                        options.toHideContainer = $dom.children("section");
                    }
                }
            }
        }

        return options;
    }

    //获取固定结构的article
    function getFixedArticle() {
        var fixedArticle = null;
        var $body = $("body");
        if ($body.children("main").length > 0) {
            var tempFixedArticle = $body.children("main").children("article");
            if (tempFixedArticle.length > 0) {
                fixedArticle = tempFixedArticle;
            }
        }
        return fixedArticle;
    }

    //获取传入的content，若传入的content的article下的第一级子节点有h2，则将其移除
    function getContentHtml(options) {
        var contentHtml = options.content;
        var $contentHtml = $(contentHtml);
        var $title = $contentHtml.children("h2");
        var $footer = $contentHtml.children("footer");
        //判断是否是固定结构的dom
        var isFixedDom = false;
        if ((options.openDialogDom.length === 0 || $contentHtml.length > 0) && $contentHtml.first().prop("localName") === "article" && $contentHtml.children("section").length > 0) {
            isFixedDom = true;
        }

        if (!options.title) {
            if ($title.length > 0) {
                $title.append('<i class="iconfont icon-close bh-pull-right bh-paper-pile-closeIcon jw-breadcrumb-closeIcon " bh-paper-pile-dialog-role="bhPaperPileDialogCloseIcon"></i>');

                $title.addClass("jw-breadcrumb-headerTitle bh-str-cut").attr("bh-paper-pile-dialog-role", "bhPaperPileDialogHeader");
                if (options.hideTitle) {
                    $title.attr("bh-paper-pile-dialog-role-hide", "1");
                }
                $title.attr("title", $title.prop("firstChild").nodeValue);
                options.title = $title[0].outerHTML;
                $title.remove();
            } else {
                paperConsole("面包屑的页面没有h2");
                throw new Error("面包屑的页面没有h2");
            }
        } else {
            //当通过属性传入的title时，默认在外面套上h2标签
            options.title =
                '<h2 class="jw-breadcrumb-headerTitle bh-str-cut" title="' +
                options.title +
                '" bh-paper-pile-dialog-role="bhPaperPileDialogHeader" bh-paper-pile-dialog-role-hide="' +
                (options.hideTitle ? "1" : "0") +
                '">' +
                options.title +
                '<i class="iconfont icon-close bh-pull-right bh-paper-pile-closeIcon jw-breadcrumb-closeIcon " bh-paper-pile-dialog-role="bhPaperPileDialogCloseIcon"></i></h2>';
            if (isFixedDom) {
                $title.remove();
            }
        }

        if (!options.footer) {
            if ($footer.length > 0) {
                $footer.addClass("bh-clearfix");
                options.footer = $footer[0].outerHTML;
                $footer.remove();
            } else {
                if (options.openDialogDom.length > 0 && options.openDialogDom.attr("bh-show-footer") !== "false") {
                    options.footer = '<footer class="bh-clearfix"></footer>';
                }
            }
        } else {
            //当通过属性传入的footer时，默认在外面套上footer标签
            options.footer = '<footer class="bh-clearfix">' + options.footer + "</footer>";
            if (isFixedDom) {
                $footer.remove();
            }
        }
        if (isFixedDom) {
            var $dialogAside = $contentHtml.children("aside");
            if ($dialogAside.length > 0) {
                options.aside = $dialogAside[0].outerHTML;
                $dialogAside.remove();
            }
            options.layoutRole = $contentHtml.attr("bh-layout-role");
            options.layoutClass = $contentHtml.attr("class");
            options.content = $contentHtml[0].innerHTML;
        } else {
            options.content = "<section style='height:100%;overflow: hidden auto'>" + options.content + "</section>";
        }

        return options;
    }

    /***
     * 给容器设定最小高度
     * @param $dialogBody
     */
    function setDialogContentMinHeight($dialogBody) {
        var heightData = getFrameHeight();
        var diffTop = $dialogBody.offset().top;
        var minHeight = heightData.windowHeight - heightData.footerHeight - diffTop;
        $dialogBody.css("min-height", minHeight + "px");
    }

    function getFrameHeight() {
        var windowHeight = $(window).height();
        var footerHeight = $("[bh-footer-role=footer]").outerHeight() || 0;
        var headerHeight = $("[bh-header-role=bhHeader]").outerHeight() || 0;
        return {
            windowHeight: windowHeight,
            footerHeight: footerHeight,
            headerHeight: headerHeight
        };
    }

    /***
     * 隐藏弹出框
     * titleContainer 可选，与弹出框关联的title容器
     * referenceContainer 可选，与弹出框关联的内容容器
     * guid 可选，弹出框的guid
     * destroy 可选，值为true或false； true则在隐藏的同时将弹出框remove
     */
    function dialogHide(options) {
        var $dialog = "";
        var $titleContainer = "";
        var $referenceContainer = "";
        var guid = "";

        if (options.titleContainer) {
            $titleContainer = options.titleContainer;
            guid = $titleContainer.attr("bh-paper-pile-dialog-role-title-guid");
        } else if (options.referenceContainer) {
            $referenceContainer = options.titleContainer;
            guid = $referenceContainer.attr("bh-paper-pile-dialog-role-container-guid");
        } else if (options.guid) {
            guid = options.guid;
        }

        if (!guid) {
            var $newestDialog = getTheNewestOpenDialog();
            if ($newestDialog) {
                $dialog = $newestDialog;
            } else {
                $dialog = $("div[bh-paper-pile-dialog-role=bhPaperPileDialog]");
            }
            guid = $dialog.attr("bh-paper-pile-dialog-role-guid");
        }
        if (!$dialog) {
            $dialog = $("div[bh-paper-pile-dialog-role-guid=" + guid + "]");
        }

        if ($dialog.length > 0) {
            if ($dialog.attr("hide-flag") === "true") {
                return;
            }

            $dialog.attr("hide-flag", "true");

            var dialogIndex = $dialog.attr("bh-paper-pile-dialog-role-index");
            dialogIndex = parseInt(dialogIndex, 10);

            var existDialogData = $("body").data("bh-paper-pile-dialog");
            var existDialogLen = existDialogData.length;

            //当传入关闭所有弹框时，将对话框指向最低一层
            if (options.isHideAll) {
                dialogIndex = 1;
            }
            //当点击父级弹框时，由高到低依次隐藏弹框
            if (dialogIndex < existDialogLen) {
                for (var i = existDialogLen; i >= dialogIndex; i--) {
                    var existItem = existDialogData[i - 1];
                    if (existItem) {
                        // var childOptions = getCallbackFun(options, existItem, 'hasChild');
                        var existGuid = existItem.guid;
                        guid = existGuid;
                        //多重弹框不做回调检查
                        existItem.ignoreAllCallback = existItem.ignoreAllCallback === undefined ? true : existItem.ignoreAllCallback;
                        dialogToHide(existGuid, existItem);
                    }
                }
            } else {
                // options = getCallbackFun(options, $dialog);
                for (var k = 0; k < existDialogLen; k++) {
                    var existItem = existDialogData[k];
                    var existGuid = existItem.guid;
                    if (existGuid === guid) {
                        options = $.extend({}, existItem, options);
                        break;
                    }
                }
                dialogToHide(guid, options);
            }
        }

        //当隐藏面包屑时,若有侧边栏弹框,则重新显示滚动条    ghlong  2017-3-7
        $.bhPropertyDialog.showScrollBar();
        //当隐藏面包屑时,部分带有fixed定位的组件需要设置scrollTop事件来触发重新定位  王敏 2021-9-10
        setTimeout(function () {
            $(window).scrollTop(1);
        }, 500);
    }

    /***
     * 执行隐藏操作
     * @param guid
     * @param options
     */
    function dialogToHide(guid, options) {
        options.guid = guid;

        var $bind_btn = getBindBtn(guid);
        if ($bind_btn.length > 0) {
            var flag = $bind_btn.triggerHandler("closeBefore");
            if (typeof flag === "boolean" && !flag) {
                $("[bh-paper-pile-dialog-role-guid=" + guid + "]").attr("hide-flag", "false");
                return;
            }
        }

        if (!options.ignoreCloseBeforeCallback && !options.ignoreAllCallback && options.closeBefore && options.closeBefore instanceof Function) {
            var closeFlag = options.closeBefore();
            if (closeFlag) {
                doDialogHideHandle(guid, options);
            } else {
                $("[bh-paper-pile-dialog-role-guid=" + guid + "]").attr("hide-flag", "false");
            }
        } else {
            doDialogHideHandle(guid, options);
        }
    }

    function doDialogHideHandle(guid, options) {
        var $dialog = $("[bh-paper-pile-dialog-role-guid=" + guid + "]");
        var $titleContainer = $("[bh-paper-pile-dialog-role-title-guid=" + guid + "]");
        var $dialogContainer = $dialog.find("div.bh-paper-pile-dialog-container");
        // 获取h2标题是否需要hide
        var hide = $titleContainer.attr("bh-paper-pile-dialog-role-hide");
        if (hide && hide === "1") {
            $titleContainer.hide();
        } else {
            var breadcrumbHide = $titleContainer.attr("bh-paper-pile-breadcrumb-role-hide");
            if (!breadcrumbHide || breadcrumbHide !== "1") {
                $titleContainer.show();
            }
        }
        var $insertToDialog = $titleContainer.closest("[bh-paper-pile-dialog-role=bhPaperPileDialog]");

        setTimeout(function () {
            //将父级弹框的内容显示出来
            if ($insertToDialog.length > 0) {
                $insertToDialog.find("[bh-paper-pile-dialog-role=bhPaperPileDialogBody]").show();
            } else {
                //将内容的border去掉
                var fixedArticle = getFixedArticle();
                var $layoutContainer;
                if (fixedArticle) {
                    $layoutContainer = fixedArticle;
                } else {
                    $layoutContainer = $("[bh-container-role=container]");
                }
                if ($layoutContainer && $layoutContainer.length > 0) {
                    $layoutContainer.removeClass("bh-border-transparent").removeClass("bh-bg-transparent");
                }
            }

            $dialogContainer.removeClass("bh-bg-transparent");
            //隐藏弹框时重置一下页脚
            resetPageFooter({
                titleContainer: "",
                //可选，父层的title
                referenceContainer: "",
                //可选，想要将dialog插入的容器
                dialogContainer: "",
                //可选，弹出框容器
                guid: "" //可选，弹出框的guid
            });
            resetDialogFooter({
                titleContainer: "",
                //可选，与弹出框关联的title容器
                referenceContainer: "" //可选，与弹出框关联的内容容器
            });
        }, getAnimateTime());

        //弹出框的头部透明度变成0时，使其隐藏起来，避免出现文字重叠
        setTimeout(function () {
            if ($insertToDialog.length > 0) {
                $insertToDialog.find(".bh-paper-pile-closeIcon").show();
            }
            $dialog.addClass("bh-negative-zIndex").hide();

            setPageFooterToRelative();
            var $bind_btn = getBindBtn(guid);

            //延迟50毫秒返回close回调,解决面包屑关闭后jqxtable显示宽度错误
            setTimeout(function () {
                if (!options.ignoreCloseCallback && !options.ignoreAllCallback && options.close && options.close instanceof Function) {
                    //获取该弹框的header，section，footer，aside的jquery对象
                    var dialogParts = getDialogPartDom($dialog);
                    //执行初始化完成事件，并将对应节点的jquery对象返回
                    options.close(dialogParts.dialogHeader, dialogParts.dialogSection, dialogParts.dialogFooter, dialogParts.dialogAside);
                }

                if ($bind_btn.length > 0) {
                    $bind_btn.removeAttr("bh-paper-pile-dialog-bind-btn").trigger("close");
                }
            }, 150);

            //当传入destroy是true，或autoDestroy是false时，将弹框移除
            if ((options && options.destroy) || (options && options.autoDestroy)) {
                dialogDestroy(options);
            }

            if (options.toShowContainer) {
                options.toShowContainer.show();
            } else {
                $("body")
                    .find("[bh-paper-pile-dialog-role-hide-container-guid=" + guid + "]")
                    .show();
            }

            if ($("body").find('[bh-paper-pile-dialog-role="bhPaperPileDialog"]').length === 0) {
                $('[bh-footer-role="footer"]').show();
            }
        }, getAnimateTime() * 2);
    }

    //获取最新打开的弹框对象
    function getTheNewestOpenDialog() {
        var $newestDialog = "";
        var insertToDialogIndex = 0;
        var hasOpenDialogs = $("body").find("div[bh-paper-pile-dialog-role=bhPaperPileDialog]");
        if (hasOpenDialogs.length > 0) {
            hasOpenDialogs.each(function () {
                var $itemDialog = $(this);
                // var dialogIndex = parseInt($itemDialog.attr("jw-breadcrumb-role-index"), 10);
                var dialogIndex = parseInt($itemDialog.attr("bh-paper-pile-dialog-role-index"), 10);
                if (dialogIndex > insertToDialogIndex) {
                    $newestDialog = $itemDialog;
                }
            });
        }
        return $newestDialog;
    }

    function setPageFooterToRelative() {}

    function resetPageFooter(options) {}

    function paperConsole(message) {
        if (console && console.error) {
            console.error(message);
        }
    }

    /***
     * 动画的执行的基础时间
     * @returns {number}
     */
    function getAnimateTime() {
        return 0;
    }

    /***
     * 将弹框销毁，不传任何值，则将所有的弹出框删除
     * titleContainer 可选，与弹出框关联的title容器
     * referenceContainer 可选，与弹出框关联的内容容器
     * guid 可选，弹出框的guid
     */
    function dialogDestroy(options) {
        var guid = getDialogGuid(options);

        if (guid) {
            removeDialogAttr(guid);
        } else {
            var $dialogs = $("body").find("div[bh-paper-pile-dialog-role=bhPaperPileDialog]");
            $dialogs.each(function () {
                var guid = $(this).attr("bh-paper-pile-dialog-role-guid");
                removeDialogAttr(guid);
            });
        }
    }

    /***
     * 移除对话框及与其关联的容器属性
     * @param guid
     */
    function removeDialogAttr(guid) {
        var $dialog = $("div[bh-paper-pile-dialog-role-guid=" + guid + "]");
        if ($dialog.length === 0) {
            return;
        }
        var dialogIndex = $dialog.attr("bh-paper-pile-dialog-role-index");
        dialogIndex = parseInt(dialogIndex, 10);
        $("[bh-paper-pile-dialog-role-title-guid=" + guid + "]")
            .removeAttr("bh-paper-pile-dialog-role-title-guid")
            .off("click");
        $("[bh-paper-pile-dialog-role-container-guid=" + guid + "]").removeAttr("bh-paper-pile-dialog-role-container-guid");
        $dialog.remove();

        var existDialogData = $("body").data("bh-paper-pile-dialog");
        var existDialogLen = existDialogData.length;
        if (existDialogLen === 1) {
            $("body").removeData("bh-paper-pile-dialog");
        } else {
            var newDialogData = [];
            for (var i = 0; i < existDialogLen; i++) {
                var existItem = existDialogData[i];
                var existIndex = existItem.index;
                if (existIndex != dialogIndex) {
                    if (existIndex > dialogIndex) {
                        existItem.index = existIndex - 1;
                        newDialogData.push(existItem);
                    } else {
                        newDialogData.push(existItem);
                    }
                }
            }
            $("body").data("bh-paper-pile-dialog", newDialogData);
        }
    }

    /***
     * 弹出框的结构html
     * @returns {string}
     */
    function getDialogHtml() {
        var $pageFooter = $('[bh-footer-role="footer"]').clone();
        var pageFooterHtml = "";
        var noPageFooterFlag = "bhNoPageFooterFlag";
        if ($pageFooter.length > 0) {
            $pageFooter.removeAttr("bh-footer-role").removeAttr("style").removeAttr("id").attr("bh-paper-pile-dialog-role", "pageFooter");

            pageFooterHtml = $pageFooter[0].outerHTML;
            noPageFooterFlag = "";
        } else {
            pageFooterHtml = '<footer bh-paper-pile-dialog-role="pageFooter"></footer>';
        }
        var _html =
            '<div class="bh-paper-pile-dialog jw-breadcrumb @layoutRole ' +
            noPageFooterFlag +
            '" style="@style" bh-paper-pile-dialog-role="bhPaperPileDialog" bh-paper-pile-dialog-role-guid="@guid">' +
            '<div class="bh-paper-pile-dialog-container jw-breadcrumb-container bh-animated-doubleTime jw-breadcrumb-intoUp">' + // '<i class="iconfont icon-close bh-pull-right bh-paper-pile-closeIcon" jw-breadcrumb-role="jwBreadcrumbCloseIcon"></i>' + '<div class="jw-breadcrumb-headerTitle" jw-breadcrumb-role="jwBreadcrumbHeader">' +
            "@breadcrumb" +
            "@title" +
            '<div class="bh-paper-pile-body bh-card bh-card-lv1 jw-breadcrumb-body @layoutClass" bh-paper-pile-dialog-role="bhPaperPileDialogBody" bh-layout-role="@layoutRole">' +
            "@content" +
            "</div>" +
            '<div class="jw-breadcrumb-footer bh-border-v @footerClass" bh-paper-pile-dialog-role="bhPaperPileDialogFooter" jw-breadcrumb-role="jwBreadcrumbFooter">@footerHtml</div>';
        return _html;
    }

    /***
     * 判断弹出框是否有页脚，有则显示页脚
     * @param $dialog
     * @param data
     * @param flag flag=get那就直接返回样式
     */
    function dialogFooterToFixed($dialog, data, flag) {
        var footerStyle = "";
        if (data.footer) {
            var dialogWidth = $dialog.outerWidth();
            var dialogLeft = $dialog.offset().left;
            footerStyle = "left:" + dialogLeft + "px;width:" + dialogWidth + "px;position:fixed;bottom:0;top:auto;display:block;";
            if (flag !== "get") {
                $dialog.find("div[jw-breadcrumb-role=jwBreadcrumbBody]").removeClass("jw-breadcrumb-footer-on-relative");

                $dialog
                    .find("div[jw-breadcrumb-role=jwBreadcrumbFooter]")
                    .css({
                        left: dialogLeft + "px",
                        width: dialogWidth + "px",
                        position: "fixed",
                        bottom: "0",
                        top: "auto",
                        display: "block"
                    })
                    .removeClass("jw-breadcrumb-footer-relative");

                $dialog.find('[jw-breadcrumb-role="jwBreadcrumbBody"]').removeClass("bhRelativeFlag").addClass("bhFixedFlag");
            }
        }
        return footerStyle;
    }

    /***
     * 获取浏览器和对话框的相关位置和高度等
     * @param $dialog
     * @returns {{}}
     */
    function getPositionAndHeight($dialog) {
        var data = {};
        var $window = $(window);
        var $body = $("body");
        var scrollTop = $window.scrollTop();
        var windowHeight = $window.height();

        var bodyHeight = 0;
        var userAgent = window.navigator.userAgent;
        if (userAgent.indexOf("Safari") > -1 && userAgent.indexOf("Chrome") === -1) {
            bodyHeight = $body.get(0).scrollHeight;
        } else {
            bodyHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
        }

        var footerHeight = $dialog.find('[jw-breadcrumb-role="pageFooter"]').outerHeight();

        if ($dialog) {
            var $dialogBody = $dialog.find("div[jw-breadcrumb-role=jwBreadcrumbBody]");
            var dialogBodyHeight = $dialogBody.outerHeight(true);
            var dialogHeight = $dialog.outerHeight();
            var dialogOffset = $dialog.offset();
            var dialogBodyOffset = $dialogBody.offset();
            var dialogFooterHeight = 0;
            var $dialogFooter = $dialog.find('div[jw-breadcrumb-role="jwBreadcrumbFooter"]');
            if ($dialogFooter.length > 0) {
                dialogFooterHeight = $dialogFooter.outerHeight(true);
            }

            data.dialogBodyHeight = dialogBodyHeight;
            data.dialogBodyOffset = dialogBodyOffset;
            data.dialogOffset = dialogOffset;
            data.dialogHeight = dialogHeight;
            data.dialogFooterHeight = dialogFooterHeight;
        }

        data.windowHeight = windowHeight;
        data.scrollTop = scrollTop;
        data.bodyHeight = bodyHeight;
        data.footerHeight = footerHeight;
        return data;
    }

    /***
     * 设置页面和对话框页脚style
     * @param $dialog
     */
    function setCurrentFooterPosition($dialog) {
        var positionAndHeight = getPositionAndHeight($dialog);

        var $dialogFooter = $dialog.find("div[jw-breadcrumb-role=jwBreadcrumbFooter]");
        var dialogFooterFixedStyle = dialogFooterToFixed(
            $dialog,
            {
                footer: true
            },
            "get"
        );
        $dialogFooter.attr("jw-breadcrumb-role-footer-fixed", dialogFooterFixedStyle);

        //设置页面页脚style，使其绝对定位到页面底部
        setPageFooterToAbsolute(positionAndHeight);
        var footerPositionTop = positionAndHeight.bodyHeight - positionAndHeight.footerHeight;

        //对话框高度小于浏览器高度，则让对话框页脚取消浮动
        var dialogShowHeight = positionAndHeight.dialogBodyHeight + positionAndHeight.dialogOffset.top;
        if (dialogShowHeight <= positionAndHeight.windowHeight) {
            //如果弹出框的显示高度达不到页脚的top，则将页脚的位置下移，避免出现超出的侧边框线
            if (dialogShowHeight < footerPositionTop) {
                setDialogFooterRelative($dialogFooter, "low");
            } else {
                setDialogFooterRelative($dialogFooter);
            }
        }
    }

    function setPageFooterToAbsolute(positionAndHeight) {}

    /***
     * 滚动条滚动时，设置页脚样式
     * @param $dialog
     */
    function scrollToSetFooterPosition($dialog) {
        var positionAndHeight = getPositionAndHeight($dialog);

        var $dialogFooter = $dialog.find("div[jw-breadcrumb-role=jwBreadcrumbFooter]");
        $dialogFooter.each(function () {
            var $footerItem = $(this);
            if ($footerItem.css("display") !== "none") {
                if (positionAndHeight.windowHeight + positionAndHeight.scrollTop + positionAndHeight.footerHeight >= positionAndHeight.bodyHeight) {
                    setDialogFooterRelative($footerItem, "low");

                    $footerItem.addClass("bh-border-v").removeClass("bh-border");

                    $dialog.find('[jw-breadcrumb-role="jwBreadcrumbBody"]').addClass("bhRelativeFlag").removeClass("bhFixedFlag");
                } else {
                    var dialogFooterFixedStyle = $footerItem.attr("jw-breadcrumb-role-footer-fixed");
                    $footerItem.attr("style", dialogFooterFixedStyle).removeClass("bh-border-v").addClass("bh-border");

                    $dialog.find('[jw-breadcrumb-role="jwBreadcrumbBody"]').removeClass("bhRelativeFlag").addClass("bhFixedFlag");
                }
                return false;
            }
        });
    }

    /***
     * 将对话框页脚设成相对定位
     * @param $dialogFooter
     * @param flag  low
     */
    function setDialogFooterRelative($dialogFooter, flag) {
        //当弹出框的页脚没有任何内容时，不做任何处理
        if ($dialogFooter.contents().length === 0) {
            return;
        }

        var footerHeight = $("[bh-footer-role=footer]").outerHeight() || 0;
        var $dialog = $dialogFooter.closest('div[jw-breadcrumb-role="jwBreadcrumb"]');
        var $dialogBody = $dialog.find("[jw-breadcrumb-role=jwBreadcrumbBody]");
        var layoutRole = $dialogBody.attr("bh-layout-role");
        var $dialogHeader = $dialog.find("[jw-breadcrumb-role=jwBreadcrumbHeader]");
        var dialogFooterHeight = $dialogFooter.outerHeight();
        var dialogFooterBottom = dialogFooterHeight + footerHeight;
        var dialogBodyHeight = 0;
        var layoutType = "";
        $dialogBody.children().each(function () {
            var $item = $(this);
            //先判断该布局是不是左右布局，是左右布局则继续读取它里面的子结构然后取高度大的nav或section的高度做dialogBodyHeight高度
            if ($item[0].localName === "nav") {
                layoutType = "navLeft";
            }

            if (layoutType === "navLeft") {
                var navContentHeight = 0;
                $item.children().each(function () {
                    navContentHeight += $(this).outerHeight();
                });
                if (navContentHeight > dialogBodyHeight) {
                    dialogBodyHeight = navContentHeight;
                }
            } else {
                var itemHeight = $item.outerHeight();
                dialogBodyHeight += itemHeight;
            }
        });

        var dialogBodyMinHeight = parseInt($dialogBody.css("min-height"), 10);
        dialogBodyMinHeight = dialogBodyMinHeight ? dialogBodyMinHeight : 0;

        //当弹出框的内容高度比弹出框的最小高度还小的时候，让弹出框的页脚能自适应高度
        if (dialogBodyHeight + dialogFooterHeight < dialogBodyMinHeight) {
            $dialogFooter.removeAttr("style");
            /**
             * 24是对话框页脚距离内容的间距
             * dialogBodyMinHeight是页面页脚高度和对话框页脚高度的和
             * 页面页脚的高度是32，所以24是安全距离可以直接加
             */

            var dialogHeaderHeight = $dialogHeader.length > 0 ? $dialogHeader.outerHeight() : 0;
            dialogBodyHeight += dialogHeaderHeight;
            //40 是设计给出的页脚与内容的距离, 16 是footer的padding-top值,故真实的页脚与内容的间距是40 - 16
            dialogBodyHeight += 40 - 16;

            $dialogFooter
                .css({
                    bottom: "auto"
                })
                .addClass("jw-breadcrumb-footer-relative");

            if (layoutRole.indexOf("navLeft") > -1) {
                $dialogBody.addClass("jw-breadcrumb-footer-on-relative");
            }
        } else {
            if ($dialogFooter.css("position") !== "absolute") {
                $dialogFooter.css({
                    left: 0,
                    bottom: dialogFooterHeight + "px",
                    position: "relative"
                });
            } else {
                $dialogFooter.css({
                    top: "auto",
                    bottom: "0"
                });
            }

            $dialogBody.removeClass("jw-breadcrumb-footer-on-relative");
        }

        $dialog.find('[jw-breadcrumb-role="jwBreadcrumbBody"]').addClass("bhRelativeFlag").removeClass("bhFixedFlag");

        $dialogFooter.show();
    }

    /***
     * 弹出框的关闭事件监听
     * @param $dialog
     * @param data
     */
    function dialogEventListen($dialog, data) {
        //点击关闭按钮
        // $dialog.on("click", "i[jw-breadcrumb-role=jwBreadcrumbCloseIcon]", function () {
        //     data.guid = $(this).closest("[jw-breadcrumb-role=jwBreadcrumb]").attr("jw-breadcrumb-role-guid");
        //     dialogHide(data);
        // });
        $dialog.on("click", "i[bh-paper-pile-dialog-role=bhPaperPileDialogCloseIcon]", function () {
            var guid = $(this).closest("[bh-paper-pile-dialog-role=bhPaperPileDialog]").attr("bh-paper-pile-dialog-role-guid");
            data.guid = guid;
            dialogHide(data);
        });
        $dialog.find("div[jw-breadcrumb-item-role-title-guid]").on("click", function (event) {
            event.stopPropagation();
            var existDialogData = $("body").data("bh-paper-pile-dialog");
            var guid = $(this).attr("jw-breadcrumb-item-role-title-guid");
            var options = _.find(existDialogData, function (item) {
                return item.guid === guid;
            });
            dialogHide(options);
        });

        //监听浏览器滚动事件，设置页脚样式
        if (data.footer) {
            $(window).scroll(function (e) {
                scrollToSetFooterPosition($dialog);
            });
        }
    }

    //重新设置弹框页脚的位置
    function resetDialogFooter(options) {
        var guid = getDialogGuid(options);
        if (guid) {
            setTimeout(function () {
                var $dialog = $("div[jw-breadcrumb-role-guid=" + guid + "]");
                if (!$dialog.find('[jw-breadcrumb-role="jwBreadcrumbFooter"]').html()) {
                    return;
                }
                var positionAndHeight = getPositionAndHeight($dialog);
                var dialogShowHeight = positionAndHeight.dialogBodyHeight + positionAndHeight.dialogOffset.top;
                //对话框高度小于浏览器高度，则让对话框页脚取消浮动
                if (dialogShowHeight < positionAndHeight.windowHeight) {
                    setCurrentFooterPosition($dialog);
                } else {
                    //给弹出框的页脚添加浮动属性
                    dialogFooterToFixed($dialog, {
                        footer: true
                    });
                }

                resetPageFooter(options);
            }, 50);
        }
    }

    function NewGuid() {
        return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
    }

    function S4() {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    }

    //重设弹框的最小高度
    function resetDialogMinHeight(options) {
        var guid = getDialogGuid(options);
        if (guid) {
            var $dialog = $("div[jw-breadcrumb-role-guid=" + guid + "]");
            var $dialogBody = $dialog.find("div[jw-breadcrumb-role=jwBreadcrumbBody]");
            setDialogContentMinHeight($dialogBody);
        }
    }

    //获取弹框的guid
    function getDialogGuid(options) {
        var guid = "";
        if (options.guid) {
            guid = options.guid;
        } else if (options.titleContainer) {
            guid = options.titleContainer.attr("jw-breadcrumb-role-title-guid");
        } else if (options.referenceContainer) {
            guid = options.referenceContainer.attr("jw-breadcrumb-role-container-guid");
        } else {
            var $insertToDialog = getTheNewestOpenDialog();
            if ($insertToDialog.length > 0) {
                guid = $insertToDialog.attr("jw-breadcrumb-role-guid");
            }
        }
        return guid;
    }

    (function () {
        var cnzz_s_tag = document.createElement("link");
        cnzz_s_tag.rel = "stylesheet";
        cnzz_s_tag.type = "text/css";
        var av = window._JW_INIT_CONFIG ? window._JW_INIT_CONFIG.APP_VERSION : "30001";
        cnzz_s_tag.href = BASE_PATH + "jw-breadcrumb.css?v=" + av;
        document.getElementsByTagName("head")[0].appendChild(cnzz_s_tag);
    })();
    _JW_BOOT_HELPER.addFrameworkInitCallback(function () {
        var _config = require("configUtils");
        if (_config.enableBreadcrumb) {
            $.bhPaperPileDialogOld = $.bhPaperPileDialog;
            $.bhPaperPileDialog = $.jwBreadcrumb;
        }
    });

    // overrideBhPaperPileDialog();
})(window, jQuery);
