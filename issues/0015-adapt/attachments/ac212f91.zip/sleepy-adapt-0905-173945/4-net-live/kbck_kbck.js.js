METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/public/commonpage/kbck/kbck.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (37098 字符) --------
define(function(require) {

	var utils = require('utils');
	var bs = require('./kbckBS');
	var zttk = require('../zttk/zttk');
	var kblb = require('../kblb/kblb');
	var dyktyrgz = require('../dyktyrgz/dyktyrgz');
	var pub_param={};
	var nqxnxq="";
	var dqxq="";//当前星期几
	var tkType = '0';
	var self = '';
	var totalJc = '';
	var printBb = require('./printkb/printkb');
	var weekSelector = require('../../widget/weekSelector/weekSelector');
	var ZZC = "22";
	var mergeTimetable = require('./mergeTimetable');
	var jasfblx = '01';
	var kbTsy = "";
	var viewConfig = {
		initialize: function(param,xnxq) {
			self = this;
			this.pushSubView([kblb,dyktyrgz]);
			nqxnxq=param.xnxqdm;
			//获取当年学年学期教室发布类型
			if(!self.initJasfblx(nqxnxq)){
				return;
			}
			//获取当年学年学期校历总周次
			self.getZcc(nqxnxq);
			var week=self.initZc();
			if(week!=null && week<ZZC){
				param.zc=week;
			}
			pub_param=param;
			var indexView = utils.loadCompiledPage('kbckIndexPage', require);
			var list=this.initTkWpk();
			self.$rootElement.html(indexView.render({data:list}), true);
			$("#zkbzc").text(param.zc);

			$('#zttk_zc').on('click', function(e){
				self.initZttk(tkType);
			});
			self.initXnxq(param);
			self.initClick();
			if(pub_param.action == "cxjszhxqkb"){
				self.serchJskbTsy(pub_param.xnxqdm);
			}
			if(pub_param.action == "cxxszhxqkb"){
				self.serchXskbTsy(pub_param.xnxqdm);
			}
			self.initWpkAndTkHeight();
			self.eventMap = {
				'[data-action="确认课表"]': self.queRenKB
			};
			$('div[data-action="周课表学年学期"]').trigger("click");

			self.queryQrxx();
		},
		serchJskbTsy:function(xnxqdm){
			kbTsy = "";
			$.jwAjax({
				url: '/sys/wdkbby/modules/dzkz/cxjskbtsy.do',
				data:{
					XNXQDM: xnxqdm
	            },
				async:false,
				successMsg: '',
				success: function (res) {
					if(res && res.rows.length>0){
						kbTsy=res.rows[0].WHUTTSY;
					}
				}
			});
		},
		serchXskbTsy:function(xnxqdm){
			kbTsy = "";
			$.jwAjax({
				url: '/sys/wdkbby/modules/xskcb/cxxskcbtsy.do',
				data:{
					XNXQDM: xnxqdm
	            },
				async:false,
				successMsg: '',
				success: function (res) {
					if(res && res.rows.length>0){
						kbTsy=res.rows[0].WHUTTSY;
					}
				}
			});
		},
		initJasfblx:function(xnxqdm){
	    	var kbfbcx =$.jwAjax({
				url: '/sys/wdkbby/modules/jshkcb/kbfbcx.do',
				data:{                
					XNXQDM: xnxqdm,
	                pageSize: 1,
	                pageNum: 1,
	                '*order': '-CZSJ'
	            },
				async:false,
				successMsg: '',
				success: function () {}
			});
	    	if(kbfbcx && kbfbcx.rows.length==1 && kbfbcx.rows[0]){
	    		jasfblx=kbfbcx.rows[0].WHUTJASFBLX;
	    		return true;
	    	}else{
	    		$.bhTip({
				    content: '未查询到当前学年学期设置的教室发布类型！',
				    state: 'danger'
				 });
				return false;
	    	}    		
	    },
	    
		initZc:function(){
			var week=1;
			var xnxqArr = nqxnxq.split("-");
			var xn = xnxqArr[0] + "-" + xnxqArr[1];
			var xq = xnxqArr[2];
			var myDate = new Date();
			var year = myDate.getFullYear();
			var month = myDate.getMonth() + 1;
			var day = myDate.getDate();
			var rq = year + '-' + month + '-' + day;// 拼写出的日期2015-3-27
			var dqrqParams ={XN: xn,XQ: xq,RQ: rq};
			var data=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/dqzc.do"), dqrqParams);
			if(data.datas.dqzc.extParams.code==1 && data.datas.dqzc.rows.length == 1){
				week=data.datas.dqzc.rows[0].ZC;
				if(week <= 0){
					week = 1;
				}
				dqxq=data.datas.dqzc.rows[0].XQJ;
			}
			return week;
		},

		actionCheckXnxqKb:function(){
			$("div[data-action='周课表学年学期']").hide();
			$("div[data-action='周课表周课表']").show();
			$("div[data-action='周课表切换']").hide();
			pub_param.zc="";
			pub_param.xnxqdm = $("#dqxnxq2").attr("value");
			self.inintWeekTable("xnxq");
			self.initWpkAndTk();
			tkType = '1';
			$('#zttk_zc').on('click', function(e){
				self.initZttk(tkType);
			});
		},

		actionCheckZKb:function(){
			$("div[data-action='周课表切换']").show();
			$("div[data-action='周课表学年学期']").show();
			$("div[data-action='周课表周课表']").hide();
			pub_param.zc=$("#zkbzc").text();
			pub_param.xnxqdm = $("#dqxnxq2").attr("value");
			self.inintWeekTable();
			self.initWpkAndTk();

			tkType = '0';
			$('#zttk_zc').on('click', function(e){
				self.initZttk(tkType);
			});
		},

		actionLeft:function(){
			$("div[data-action='周课表学年学期']").show();
			$("div[data-action='周课表周课表']").hide();
			var zc=$("#zkbzc").text();
			if(zc>1){
				$("#zkbzc").text(parseInt(zc)-1);
			}
			if(zc==1){
				$("#zkbzc").text(ZZC);
			}
			pub_param.zc=$("#zkbzc").text();
			pub_param.xnxqdm = $("#dqxnxq2").attr("value");
			self.inintWeekTable();
			self.initWpkAndTk();
			$('#zttk_zc').on('click', function(e){
				self.initZttk(tkType);
			});
		},

		actionRight:function(){
			$("div[data-action='周课表学年学期']").show();
			$("div[data-action='周课表周课表']").hide();
			var zc=$("#zkbzc").text();
			if(zc<ZZC){
				if((parseInt(zc) + 1) == 0){
					$("#zkbzc").text(parseInt(zc)+2);
				}else{
					$("#zkbzc").text(parseInt(zc)+1);
				}
			}
			if(zc>=ZZC){
				$("#zkbzc").text(1);
			}
			pub_param.zc=$("#zkbzc").text();
			pub_param.xnxqdm = $("#dqxnxq2").attr("value");
			self.inintWeekTable();
			self.initWpkAndTk();
			$('#zttk_zc').on('click', function(e){
				self.initZttk(tkType);
			});
		},

		initClick:function(){
			$('a[data-action="更改2"]').off('click').on('click', function() {
				self.actionChange();
			});
			/**
			 * 打印、下载都为全学期打印
			 */
			$('a[id="print_button"]').off('click').on('click', function() {
				//self.print();
				self.printAndDownload();
			});
			/** 2019-06-05 01116336 隐藏下载按钮功能  **/
			/*$('a[id="down_button"]').off('click').on('click', function() {
                //self.down_picture();
                self.printAndDownload();
            });*/

			$('i[data-action="周课表左移"]').off('click').on('click', function() {
				self.actionLeft();
			});
			$('i[data-action="周课表右移"]').off('click').on('click', function() {
				self.actionRight();
			});
			$('div[data-action="周课表学年学期"]').off('click').on('click', function() {
				self.actionCheckXnxqKb();
			});
			$('[data-action="周课表周课表"]').off('click').on('click', function() {
				self.actionCheckZKb();
			});
			$('a[id="kblb-xs"]').off('click').on('click', function() {
				kblb.initialize(pub_param);
			});
			$('a[id="kblb-ls"]').off('click').on('click', function() {
				kblb.initialize(pub_param);
			});
			$('a[id="dyktyrgz"]').off('click').on('click', function() {
				dyktyrgz.initialize(pub_param);
			});
			var domainName = window.platformDomainName;
			$('#bkkcxsmd').on('click', function(){
				if(domainName){
					window.open(domainName+'/appShow?appId=4802999063802776');
				}else{
					window.open(window.location.origin+window.contextPath+'/sys/dfcdmcdy/*default/index.do#/dfcdmcdy');
				}
			});
			$('#yjskcxsmd').on('click', function(){
				if(domainName){
					window.open(domainName+'/appShow?appId=5877162436303186');
				}else{
					window.open(window.location.origin+'/gsapp/sys/xkglappbit/*default/index.do#/jsdmcdy');
				}
			});


		},

		isIE:function() { //ie?
			if (!!window.ActiveXObject || "ActiveXObject" in window){
				return true;
			}else{
				return false;
			}
		},

		printAndDownload : function(){
//		if(totalJc == 12){// 调用12节次的课表
			//self.checkStuAndTea(12);
			printBb.initialize(pub_param);
//		}else{// 调用10节次的课表
//			//self.checkStuAndTea(10);
//			printBb.initialize(pub_param,10);
//		}
		},

		queRenKB : function(){
			BH_UTILS.bhDialogSuccess({
				title: '提示',
				content: '是否确认该课表？',
				buttons: [{
					text: '确定',
					className: 'bh-btn-warning',
					callback: function() {
						var qrkbParam = {
							XNXQDM : pub_param.xnxqdm
						};
						var qrkbData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/kbxxqr.do"),qrkbParam);
						if(qrkbData.code == 0  && qrkbData.datas.kbxxqr.extParams.code==1){
							$.bhTip({
								content : qrkbData.datas.kbxxqr.extParams.msg,
								state : 'success'
							});
							$("#KByiQueRen").show();
							$("#queRenKB").hide();
							return true;
						}else{
							$.bhTip({
								content : qrkbData.datas.kbxxqr.extParams.msg,
								state : 'warning'
							});
						}
					}
				}, {
					text: '取消',
					className: 'bh-btn-default',
					callback:function(){
					}
				}]
			});
		},

		// 区分学生教师身份
		checkStuAndTea : function(jc){
			if(pub_param.isStudent){
				//学生
				var param = {
					TYPE : "WDKB_XSKB"
				};
				var data = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/xskcb/bbqxxr.do"),param);
				if(data.code == 0  && data.datas.bbqxxr.extParams.code==1){
					var QUERYID = data.datas.bbqxxr.extParams.msg;
					window.open(WIS_EMAP_SERV.getContextPath()+"/sys/frReport2/show.do?reportlet=wdkbby/timeTableForStu"+jc+".cpt&XH="+userId+"&XNXQDM="+pub_param.xnxqdm+"&QUERYID="+QUERYID);
				}
			}else{
				//老师
				var param = {
					TYPE : "WDKB_LSKB"
				};
				var data = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/bbqxxr.do"),param);
				if(data.code == 0  && data.datas.bbqxxr.extParams.code==1){
					var QUERYID = data.datas.bbqxxr.extParams.msg;
					window.open(WIS_EMAP_SERV.getContextPath()+"/sys/frReport2/show.do?reportlet=wdkbby/timeTableForTea"+jc+".cpt&JSH="+userId+"&XNXQDM="+pub_param.xnxqdm+"&QUERYID="+QUERYID);
//    		$("#kb_title").html($("#dqxnxq2").html() + "教师授课时间表");
				}
			}
		},

		down_picture:function(){
			html2canvas($('#kcb_container').find('table'), {
				onrendered: function(canvas) {
					//var isIe = /msie/.test(navigator.userAgent.toLowerCase());
					if (self.isIE() || (navigator && navigator.userAgent.indexOf("Edge") !== -1)) {
						var blob = canvas.msToBlob();
						navigator.msSaveBlob(blob, 'my_schedule.png');
					} else {
						var url = canvas.toDataURL();
						//以下代码为下载此图片功能
						var triggerDownload = $("<a>").attr("href", url).attr("download", "my_schedule.png").appendTo("body");
						triggerDownload[0].click();
						triggerDownload.remove();
					}
				}
			});
		},

		print:function(){
			if(pub_param.isStudent){
				$("#kb_title").html($("#dqxnxq2").html() + "课表");
			}else{
				$("#kb_title").html($("#dqxnxq2").html() + "教师授课时间表");
			}
			$("#ry_infor").html(pub_param.info);
			$("div[id='print_area']").printArea();
			$("#kb_title").html("");
			$("#ry_infor").html("");
		},

		initTkWpk:function(){
			if(!pub_param.flag){
				return;
			}
			var params=self.getParam();

			var data2=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath(pub_param.wpkurl), params);
			params['*order'] = '-SQSJ';
			params.querySetting = JSON.stringify([{"name":"BYBZ","builder":"notEqual","linkOpt":"AND","value":"1"}]);//研究生的调课，会反写排课数据  右侧的调课信息没必要
			var data1=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath(pub_param.tkurl), params);
			var tkurl_data=data1.datas[pub_param.tk_ation].rows;
			var wpkurl_data=data2.datas[pub_param.wpk_action].rows;
			var kcList={};
			//kcList.tk_data=tkurl_data;
			//kcList.wpk_data=wpkurl_data;
			if(tkurl_data.length == 0 || data1.datas[pub_param.tk_ation].extParams.code!=1){
				kcList.tk_empty=[{}];
			}else{
				for(var i=0;i<tkurl_data.length;i++){
					var tk=tkurl_data[i];
					if('01'==tk.TKLXDM){//调课
						tkurl_data[i].TK=1;
					}else if('02'==tk.TKLXDM){//停课
						tkurl_data[i].DK=1;
					}else{//补课
						tkurl_data[i].BK=1;
					}
					if('1'==tk.BYBZ){//研究生
						tkurl_data[i].YJS=1;
					}else if('0'==tk.BYBZ){//教务
						tkurl_data[i].JW=1;
					}
					tkurl_data[i].KCM_ALL=tkurl_data[i].KCM;
					if(tk.KCM && tk.KCM.length>3){
						tkurl_data[i].KCM=tkurl_data[i].KCM.substring(0,3)+'..';
					}
				}
				kcList.tk_data=tkurl_data;
			}
			if(wpkurl_data.length == 0 || data2.datas[pub_param.wpk_action].extParams.code!=1){
				kcList.wpk_empty=[{}];
			}else{
				self.resetSKZC(wpkurl_data);
				for(var i=0;i<wpkurl_data.length;i++){
					var wpk=wpkurl_data[i];
					if('1'==wpk.BYBZ){//研究生
						wpkurl_data[i].YJS=1;
					}else if('0'==wpk.BYBZ){//教务
						wpkurl_data[i].JW=1;
					}
					wpkurl_data[i].KCM_ALL=wpkurl_data[i].KCM;
					if(wpk.KCM && wpk.KCM.length>3){
						wpkurl_data[i].KCM=wpkurl_data[i].KCM.substring(0,3)+'..';
					}
				}
				kcList.wpk_data=wpkurl_data;
			}

			//教师角色增加点名册功能
			if(!pub_param.isStudent){
				kcList.DMC = 1;
			}
			return kcList;
		},
	    resetSKZC:function(arr){
			var sort = function(a,b){
				var o = a.split('-');
				var t = b.split('-');
				return o[0]-t[0];
			};
	    	var order = function(zc){
	    		if(!zc||!typeof zc === 'string'){
	    			return zc;
	    		}
	    		var zcArr = zc.split(';');
	    		zcArr = zcArr.sort(sort);
	    		zcArr.forEach(function(item){
	    			var tArr = item.split(',');
	    			tArr.sort(sort);
	    			item = tArr.join();
	    		});
	    		return zcArr.join(';');
	    	};
	    	arr.forEach(function(item){
	    		 item.SKZC = order(item.SKZC);   		
	    	});
	    },
		getParam:function(){
			var params={};
			params.XNXQDM=pub_param.xnxqdm;
			if(pub_param.zc!=""){
				params.SKZC=pub_param.zc;
			}
			return params;
		},

		inintWeekTable:function(value){
			bs.initJcxxArr({
				XNXQDM: pub_param.xnxqdm
			});
			var jcCodeObject = sessionStorage.getItem('jcCodeObject');
			if(jcCodeObject){
				jcCodeObject = JSON.parse(jcCodeObject);
			}else{
				$.bhTip({
					content: '无节次信息',
					state: 'warning'
				});
				return false;
			}
			var params=self.getParam();
			var data=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath(pub_param.url), params);
			var kb_data=data.datas[pub_param.action].rows;
			var results=[];
			var _this = this;
			if(kb_data.length>0){
				kb_data = _this.mergeSameSchedule(kb_data);
				for(var i=0;i<kb_data.length;i++){
					var kb={};
					kb.kcdm=kb_data[i].KCH;
					kb.kxh = kb_data[i].KXH;
					kb.kcmc=kb_data[i].KCM;
					kb.BYBZ=kb_data[i].BYBZ;
					if(kb_data[i].TYXMDM == null || kb_data[i].TYXMDM == "null" || kb_data[i].TYXMDM.length == 0){
						kb.kcmc=kb_data[i].KCM;
					}else{
						kb.kcmc=kb_data[i].KCM + "(" + kb_data[i].TYXMDM_DISPLAY + ")";
						//rowData.KCM + "(" + rowData.TYXMDM_DISPLAY + ")";
					}
					kb.jxbid=kb_data[i].JXBID;
					kb.JXBID=kb_data[i].JXBID;
            		if(kb_data[i].JXBID){            			
            			kb.xkzrs=kb_data[i].JXBID+"("+(kb_data[i].XKRS?kb_data[i].XKRS:0)+"人)";
            		}
					kb.JASDM=kb_data[i].JASDM || '';
					kb.beginUnit=kb_data[i].KSJC;
					kb.endUnit= kb_data[i].JSJC;
					kb.week=kb_data[i].SKXQ+"";
					kb.KBID= kb_data[i].KBID;
					//kb.weekNum= kb_data[i].SKXQ;
					//weekName: kb_data.ZCMC;
					kb.teacherName= kb_data[i].SKJS || kb_data[i].JSM || '';
					if(pub_param.action != "jaskcb"){
						if(value == "xnxq"){
							var ksjc = kb_data[i].KSJC;
							var jsjc = kb_data[i].JSJC;
							ksjc= ksjc=='6'?'中课1':ksjc=='7'?'中课2':ksjc=='13'?'晚课':jcCodeObject[ksjc];
							jsjc= jsjc=='6'?'中课1':jsjc=='7'?'中课2':jsjc=='13'?'晚课':jcCodeObject[jsjc];
							kb.classroomName = "["+kb_data[i].ZCMC+"]"+","+ksjc+"-"+jsjc+","+"<span style='color: red;'>"+
							(!kb_data[i].XXXQMC? "无," : kb_data[i].XXXQMC+"," )+"</span>"+(kb_data[i].JASMC == null ? "无" :(jasfblx=='01'?(kb_data[i].JASMC?kb_data[i].JASMC:""):(kb_data[i].JASLXDM_DISPLAY?kb_data[i].JASLXDM_DISPLAY:"")));
						}else{
							kb.classroomName = "<span style='color: red;'>"+
							(!kb_data[i].XXXQMC? "无" : kb_data[i].XXXQMC )+"</span>"+ ',' + (kb_data[i].JASMC == null ? "无" : (jasfblx=='01'?(kb_data[i].JASMC?kb_data[i].JASMC:""):(kb_data[i].JASLXDM_DISPLAY?kb_data[i].JASLXDM_DISPLAY:"")));
						}
					}
					if(pub_param.action == "jskcb"){
						kb.className = (kb_data[i].SKBJ == null ? "" : kb_data[i].SKBJ);
						if(kb.className.length > 15){
							kb.classNameCut = kb.className.substring(0, 15) + "...";
						}else{
							kb.classNameCut = kb.className;
						}
					}
					kb.tzkc=(kb_data[i].ISTK==0 ? false:true);
					if(kb_data[i].SFZFXB && kb_data[i].SFZFXB != "01" && kb_data[i].SFZFXB != "1"){
						kb.sffx = true;
					}
					if(kb_data[i].JQXX){
						kb.jqxx=kb_data[i].JQXX
					}
					results.push(kb);
				}
			}else{
				if($('.bh-tip').length == 0 && !(data.code == '0' && data.datas && data.datas[pub_param.action].extParams.code == '1')){
					$.bhTip({
						content : data.datas?data.datas[pub_param.action].extParams.msg: '查询课表失败',
						state : 'warning'
					});

				}
			}
			if(value != 'xnxq'){
				results = self.initKbData(results);
			}
			results.forEach(function (item){
				if(item.kcdm === '20220706' && item.week == '5' && item.beginUnit == '9'){
					item.beginUnit = 8;
				}
			});
			results = mergeTimetable.merge(results);
			var strs = pub_param.xnxqdm.split("-");
			var data = BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/cxjcs.do"), {"XN":strs[0]+"-"+strs[1],"XQ":strs[2]});
			var rows = data.datas.cxjcs.rows;
			var total = 12;
			totalJc = total;
			var swjc = 4;
			var xwjc = 4;
			var wsjc = 4;
			if(rows.length>0){
				swjc = rows[0].SFJJ == null ? 4 : rows[0].SFJJ;
				xwjc = rows[0].XFJJ == null ? 4 : rows[0].XFJJ;
				wsjc = rows[0].WSJJ == null ? 4 : rows[0].WSJJ;
				total = parseInt(swjc) + parseInt(xwjc) + parseInt(wsjc);
				totalJc = total;
			}
			var weeks = [{
				code: "1",
				name: "星期一"
			}, {
				code: "2",
				name: "星期二"
			}, {
				code: "3",
				name: "星期三"
			}, {
				code: "4",
				name: "星期四"
			}, {
				code: "5",
				name: "星期五"
			}, {
				code: "6",
				name: "星期六"
			}, {
				code: "7",
				name: "星期日"
			}];
			var units = [];
			var jcxxArr = sessionStorage.getItem('jcxxArr');
			var allUnitsResult = [];
			if(jcxxArr){
				allUnitsResult = JSON.parse(jcxxArr);
			}else{
				$.bhTip({
					content: '无节次信息',
					state: 'warning'
				});
				return false;
			}
//			if (total < allUnitsResult.length) {
//				units = allUnitsResult.slice(0, total);
//			} else {
//				units = allUnitsResult;
//			}
//			var unitsSpread = [{
//				code: "1",
//				name: "上午",
//				spread: swjc
//			}, {
//				code: "2",
//				name: "下午",
//				spread: xwjc
//			}, {
//				code: "3",
//				name: "晚上",
//				spread: wsjc
//			}];
			units = allUnitsResult.slice(0, 16);
        	unitsSpread = [{
                code: "1",
                name: "上午",
                spread: 5
            }, {
                code: "2",
                name: "中课",
                spread: 2
            }, {
                code: "3",
                name: "下午",
                spread: 5
            }, {
                code: "4",
                name: "晚课",
                spread: 1
            }, {
                code: "5",
                name: "晚上",
                spread: 3
            }];
			var weekUnitTableInfo;
			if(dqxq==""){
				weekUnitTableInfo = new WeekUnitTableInfo({
					container: '.d',//必填
					weeks: weeks,
					units: units,
					unitsSpread:unitsSpread,
					unitMode: 2
				});
			}else{
				weekUnitTableInfo = new WeekUnitTableInfo({
					container: '.d',//必填
					weeks: weeks,
					units: units,
					unitsSpread:unitsSpread,
					unitMode: 2,
					highLightWeeks:dqxq
				});
			}
			weekUnitTableInfo.render();
			weekUnitTableInfo.setResults(results, function() {

			});
			self.resetTableHeight();
		},
	    mergeSameSchedule:function(pkjgArr){
	    	var week = new weekSelector();
	    	var spliter = '@';
	    		let pkjgGroup = pkjgArr.reduce(function(group,item){
	    		let key = item.KCH+spliter+item.JXBID+spliter+item.SKXQ+spliter+item.KSJC+spliter+item.JSJC+spliter+item.JASDM;
	    		if(!group[key]){
	    			group[key] = [];
	    		}
	    		group[key].push(item);
	    		return group;  		
	    	},{});
	    	var mergeArr = [];
	    	for(key in pkjgGroup){
	    		item = pkjgGroup[key];
	    		if(item.length===1){
	    			mergeArr.push($.extend(item[0],{ZCMC:self.getZcName(item[0].SKZC)}));
	    		}else{
	    			let res = item.reduce((origin, item) => {
	    				origin.SKZC = self.mergeWeekNum(origin.SKZC, item.SKZC);
	    				origin.JSM.add(item.JSM);

	    				// 维护一个排序数组
	    				origin.sortedJSMList.push({ JSM: item.JSM, PX: item.PX?item.PX:'999' });

	    				return origin;
	    			}, { SKZC: "00", JSM: new Set(), sortedJSMList: [] });

	    			// 排序 JSMList
	    			res.sortedJSMList.sort((a, b) => a.PX - b.PX);

	    			// 最终得到按 px 排序的 JSM 列表
	    			res.JSM=res.sortedJSMList.map(i => i.JSM);
	    			    			
//	    			let res = item.reduce(function(orgin,item){
//	    				orgin.SKZC = self.mergeWeekNum(orgin.SKZC,item.SKZC);
//	    				orgin.JSM.add(item.JSM);
//	    				return orgin;
//	    			},{SKZC:"00",JSM:new Set()});	
	    			var newSkzc = res.SKZC;	    			
	    			mergeArr.push($.extend(item[0],{SKZC:newSkzc,ZCMC:self.getZcName(newSkzc),JSM:[...new Set(Array.from(res.JSM))]}));
	    		}
	    	}

	    	return mergeArr;
	    },
	    cutLastZero:function(zcdm){
	    	 // 去除尾部连续的 '0'
	        return zcdm.replace(/0+$/, '');
	    },
	    getZcName:function(zcdm){
	    	var weeksString = '';
	        if (typeof zcdm === 'undefined'||!zcdm||!zcdm.includes('1')) {
	            return weeksString;
	        }
	        var zcArr=self.cutLastZero(zcdm).split('');
	        var tempArr=[];
	        for(var i = 0;i<zcArr.length;i++){
	        	var temp = [];
	        	var zcNum = 0;
	        	var zc = {zc:temp,start:i+1};
	        	while((i<zcArr.length)){
	        		var coiled = false;
	        		if(temp.length>1&&zcNum==temp.length){
	            		coiled = true;
	        		}
	        		if(i<zcArr.length-1&&(zcArr[i]==='0'&&zcArr[i]!=zcArr[i+1])){
	        			if(coiled){
	        				zc.coiled = true;
	        				i--;
	        				break;
	        			}
	            		temp.push(zcArr[i++]);
	        		}else if(zcArr[i]==='1'){
	        			if(temp.length>1&&!coiled&&temp[temp.length-1]==='1'){
	        				zc.coiled = false;
	        				i--;
	        				break;
	        			}
	            		temp.push(zcArr[i++]);
	            		zcNum++;
	        		}else{
	        			zc.coiled = coiled;
	        			break;
	        		}    		
	        	}
	        	zc.num =zcNum;
	        	zc.coiled = zcNum === temp.length;
	        	if(!zc.coiled){
	        		var a = 0;
	        		while(zc.zc[a]!=='1'){
	        			a++;
	        		}   		
	        		zc.odd=(zc.start+a)%2===0;
	        	}
	        	zc.end = zc.start+temp.length-1;;
	        	if(i<zcArr.length-1){
	        		while(i<zcArr.length-1&& zcArr[i]==='0'&&zcArr[i]==zcArr[i+1]){
	        			i++;
	        		}
	        	}
	        	if(zc.zc.length){        		
	        		tempArr.push(zc);
	        	}
	        }      
	        return tempArr.map(function(week){
	        	return self.getName(week);
	        	}).join(', ');
	    	
	    },
	    getName:function(week){
	    	if(week.coiled){
	    		if(week.start === week.end){    			
	    			return week.start+'周';
	    		}
	    		return week.start+'-'+week.end+'周';
	    	}else{
	    		return week.zc.map(function(a,index){
	    			if(a==='0'&&index>0){
	    				return ',';
	    			}else if(a==='0'){
	    				return '';
	    			}
	    			return index+week.start;
	    		}).join('')+'周'; 	
	    	}
	    },
	    mergeWeekNum:function(orgin,target){
	    	if(!orgin||!typeof orgin === 'string'||!orgin.includes('1')){
	    		return target;
	    	}
	    	if(!target||!typeof target === 'string'||!target.includes('1')){
	    		return orgin;
	    	}
	    		let max = orgin;
	    		let min = target;
	    		if(orgin.length<target.length){
	    			max = target;
	    			
	    			min = orgin;
	    		}
	    		let maxArr = max.split('');
	    		let minArr = min.split('');
	    		minArr.forEach(function(item,index){
	    			if(maxArr[index]==='1'||minArr[index]==='1'){
	    				maxArr[index]='1';
	    			}
	    		});
	    		return maxArr.join('');
	    },
		initXnxq: function(param){
			$("#dqxnxq2").html(param.xnxqmc);
			$("#dqxnxq2").attr("value",param.xnxqdm);
		},

		actionChange: function() {
			var indexView = utils.loadCompiledPage('./ggxnxq', require);
			utils.window({
				title: '更改学年学期',
				content: indexView.render(),
				height: 'auto',
				width: '465px',
				buttons: [{ //选填
					text: '确定',
					className: 'bh-btn-primary',
					callback: function() {
						var selectedItem = $('.dropdowm-xnxqList2').jqxDropDownList("getSelectedItem");
						$("#dqxnxq2").html(selectedItem.label);
						$("#dqxnxq2").attr("value",selectedItem.value);
						//pkglUtil.Dom.setXnxqText({MC: selectedItem.label, DM: selectedItem.value});
						$("div[data-action='周课表切换']").show();
						$("div[data-action='周课表学年学期']").show();
						$("div[data-action='周课表周课表']").hide();
						pub_param.zc=$("#zkbzc").text();
						pub_param.xnxqdm = selectedItem.value;
						pub_param.xnxqmc = selectedItem.label;
						if(!self.initJasfblx(pub_param.xnxqdm)){
	    					return;
	    				}
						if(pub_param.action == "cxjszhxqkb"){
							self.serchJskbTsy(pub_param.xnxqdm);
						}
						if(pub_param.action == "cxxszhxqkb"){
							self.serchXskbTsy(pub_param.xnxqdm);
						}
						self.getZcc(pub_param.xnxqdm);
						self.inintWeekTable();
						self.initWpkAndTk();
						$('#zttk_zc').on('click', function(e){
							self.initZttk(tkType);
						});
						$('div[data-action="周课表学年学期"]').trigger("click");
						self.queryQrxx();
						return true;
					}
				}, {
					text: '取消',
					className: 'bh-btn-default',
					callback: function() {}
				}]
			});
			$('.dropdowm-xnxqList2').jqxDropDownList({
				source: self.getXNXQSource(),
				selectedIndex: 0,
				width: '100%',
				height: '25px'
			});
			$('.dropdowm-xnxqList2').jqxDropDownList('selectItem',$("#dqxnxq2").attr("value"));
		},

		getXNXQSource:function(){
			var data=BH_UTILS.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/xnxqcx.do"), {"*order":"-DM"});
			var xnxqList = [{value:"",label:"请选择"}];
			for (var i = 0; i < data.datas.xnxqcx.rows.length; i ++) {
				var r = data.datas.xnxqcx.rows[i];
				xnxqList.push({ value: r.DM, label: r.MC });
			}
			return xnxqList;
		},
		initZttk:function(type) {
			var xnxqdm = $("#dqxnxq2").attr("value");
			var zc = $("#zkbzc").text();
			var param = new Object();
			param.xnxqdm = xnxqdm;
			if (type != null && type == '0') {
				param.zc = zc;
			}
			zttk.initialize(param);
		},

		/**
		 * 处理课表数据与调课数据，根据调课数据修改课表数据
		 */
		initKbData: function(results){
			var retultTmp = [];
			var tkWpkDataList = self.initTkWpk();
			if(tkWpkDataList.tk_data && tkWpkDataList.tk_data.length > 0){
				var mixedKbid = ','; //记录有交集的KBID
				var xzcFlag = null; //调停补课后的本周次是否上课
				var xjsFlag = true; //调停补课后本教师是否还上课
				$.each(tkWpkDataList.tk_data, function(index, tkObj){
					if(tkObj.TKLXDM != '02'){ //非停课，即为 调课、补课
						xzcFlag = tkObj.XSKZC[parseInt(pub_param.zc) - 1] == '1';
						if(pub_param.action == "jskcb"){
							if((tkObj.XSKJS && tkObj.XSKJS.indexOf(userId) > -1) || (!tkObj.XSKJS && tkObj.YSKJS && tkObj.YSKJS.indexOf(userId) > -1)){
								//现上课教师存在且包含本登陆教师  或  先上课教师不存在但原上课教师存在且包含本登陆教师
								xjsFlag = true;
							}else{
								xjsFlag = false;
							}
						}else{
							xjsFlag = true;
						}
						var kcmc = null;
						if(tkObj.TYXMDM == null || tkObj.TYXMDM == "null" || tkObj.TYXMDM.length == 0){
							kcmc = tkObj.KCM;
						}else{
							kcmc = tkObj.KCM + "(" + tkObj.TYXMDM_DISPLAY + ")";
						}
						if(tkObj.TKLXDM == '01'){//调课
							if(xzcFlag && xjsFlag){
								retultTmp.push({
									kcdm: tkObj.KCH,
									kxh:  tkObj.KXH,
									kcmc: kcmc,
									jxbid: tkObj.JXBID,
									JXBID: tkObj.JXBID,
									JASDM: tkObj.XJASDM || tkObj.JASDM || 'empty',
									beginUnit: tkObj.XKSJC?tkObj.XKSJC:tkObj.YKSJC,
									endUnit: tkObj.XJSJC?tkObj.XJSJC:tkObj.YJSJC,
									week: (tkObj.XSKXQ?tkObj.XSKXQ:tkObj.YSKXQ) + "",
									teacherName:  (tkObj.XSKJS?tkObj.XSKJS:tkObj.YSKJS) || 'empty',
									classroomName: (tkObj.XJASMC?tkObj.XJASMC:tkObj.YJASMC)?"无":(tkObj.XJASMC?
											(jasfblx=='01'?tkObj.XJASMC:tkObj.XJASLXDM_DISPLAY)
											:
											(jasfblx=='01'?tkObj.YJASMC:tkObj.JASLXDM_DISPLAY)),
									tzkc: true,
									BYBZ:tkObj.BYBZ
								});
							}
						}else{//补课
							if(xzcFlag && xjsFlag){
								retultTmp.push({
									kcdm: tkObj.KCH,
									kxh:  tkObj.KXH,
									kcmc: kcmc,
									jxbid: tkObj.JXBID,
									JXBID: tkObj.JXBID,
									JASDM: tkObj.XJASDM || 'empty',
									beginUnit: tkObj.XKSJC,
									endUnit: tkObj.XJSJC,
									week: tkObj.XSKXQ + '',
									teacherName:  tkObj.XSKJS || 'empty',
									classroomName: (tkObj.XJASMC == null ? "无" : (jasfblx=='01'?tkObj.XJASMC:tkObj.XJASLXDM_DISPLAY)),
									tzkc: true,
									BYBZ:tkObj.BYBZ
								});
							}
						}
					}
					if(tkObj.SKZC && (tkObj.SKZC[parseInt(pub_param.zc) - 1] == '1')){ //调整的本周次课表
						mixedKbid += tkObj.KBID + ',';
					}
				});
				$.each(results, function(index, obj){
					if((obj.KBID && mixedKbid.indexOf(',' + obj.KBID + ',') == -1) || obj.BYBZ=='1'){
						retultTmp.push(obj);
					}
				});
			}else{
				retultTmp = results;
			}
			return retultTmp;
		},
	       //在重绘后重置表格高度
        resetTableHeight:function(flag){
        	var allCell =$('table.wut_table td');
        	var index = 9;
            !flag && (flag = '');
        	for(var i =9 ;i<allCell.length;i++){
        		//如果当前行存在非空单元格  跳过     （查找当前单元格下是否存在目标类型的时间片）
        		var	arrangNum = $(allCell[i]).find('mtt_arrange_item ').length;
        		if(arrangNum>0){
        			index +=8;
        			i=index;
        		//如果当前行表格全为空
        		}else if((i+1)%8===0){    			
        			$(allCell[i]).height('100px');
        			index +=8;
        			i++;
        		}
        	}
    		// 教师课表添加水印
    		if(pub_param.action == "cxjszhxqkb"){
    			$("#ry_infor").html(kbTsy);
    			self.addWatermark(kbTsy);
    		}
    		// 学生课表添加水印
    		if(pub_param.action == "cxxszhxqkb"){
    			$("#ry_infor").html(kbTsy);
    			self.addWatermark(kbTsy);
    		}
        },
		initWpkAndTk: function(){
			var wptk = utils.loadCompiledPage('wptk', require);
			$("#wptk_contaner").html(wptk.render({data:self.initTkWpk()}), true);
			self.initWpkAndTkHeight();
		},
		initWpkAndTkHeight: function(){
			$.initHeightByOtherDom({
				baseElement: {
					selector: '#kcb_container', //依据元素的选择器,取值时会包含padding和margin
					heightDifference: 57 //依据元素的高度差（此值会加上元素高度作为最终依据的高度）
				},
				targetElement: [{
					selector: '.wpk-container', //目标元素的选择器
					heightDifference: -48, //目标元素的高度差（此值会加上元素高度作为最终依据的高度，一般传负值）
					scale: 0.5, //比例（每个目标所占依据高度的比例）
					style: 'max-height' //设置的高度类型， 默认为height
				},{
					selector: '.tk-container',
					heightDifference: -64,
					scale: 0.5,
					style: 'max-height'
				}]
			});
		},
		/*********************
		 * 获取当前学年学期，校历总周次
		 ********************/
		getZcc :function(XNXQDM){
			if(!XNXQDM){
				return;
			}
			var xnxqArr = XNXQDM.split("-");
			if(xnxqArr.length<3){
				return;
			}
			var param = {
				XN : xnxqArr[0]+"-"+xnxqArr[1],
				XQ : xnxqArr[2]
			};
			var data = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/xskcb/cxxljc.do"),param);
			if(data.code == 0  && data.datas.cxxljc.extParams.code==1){
				ZZC = data.datas.cxxljc.rows[0].ZZC;
			}
		},
		/**
		 * 查看当前教师课表确认信息
		 */
		queryQrxx : function(){
			if(!pub_param.isStudent){
				var qrxxParam = {
					XNXQDM : pub_param.xnxqdm
				};
				var qrxxData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/ckjskbqrxx.do"),qrxxParam);
				if(qrxxData.code == 0  && qrxxData.datas.ckjskbqrxx.extParams.code==1){
					CNT = qrxxData.datas.ckjskbqrxx.rows[0].CNT;
					if(CNT>0){
						$("#KByiQueRen").show();
						$("#queRenKB").hide();
					}else{
						var fbxxParam=qrxxParam;
						var fbxxData = utils.doSyncAjax(WIS_EMAP_SERV.getAbsPath("/modules/jshkcb/ckjskbfbxx.do"),fbxxParam);
						if(fbxxData.code == 0  && fbxxData.datas.ckjskbfbxx.extParams.code==1){
							isFb = fbxxData.datas.ckjskbfbxx.rows[0].ISFB;
							if(isFb>0){
								isSjn= fbxxData.datas.ckjskbfbxx.rows[0].ISSJN;
								if(isSjn>0){
									$("#queRenKB").show();
									$("#KByiQueRen").hide();
								}else{
									$("#KByiQueRen").hide();
									$("#queRenKB").hide();
								}
							}else{
								$("#KByiQueRen").hide();
								$("#queRenKB").hide();
							}
						}else{
							$("#KByiQueRen").hide();
							$("#queRenKB").hide();
						}
					}
				}
			}
		},
		addWatermark :function(watermarkText){
	    	if(!watermarkText){
	    		return;
	    	}
	    	// wut_container是class不是id，使用querySelector获取
	    	var container = document.querySelector('.wut_container');
	    	if(!container){
	    		return;
	    	}
	    	var containerMb = document.querySelector('.wut_table');
	    	// 如果容器尺寸为0，等待后再试
	    	var containerWidth = containerMb.offsetWidth;
	    	var containerHeight = containerMb.offsetHeight;
	    	if(containerWidth === 0 || containerHeight === 0){
	    		setTimeout(function(){
	    			self.addWatermark(watermarkText);
	    		}, 500);
	    		return;
	    	}

	    	// 先移除旧水印
	    	var oldWatermark = container.querySelector('.kbck-watermark-container');
	    	if(oldWatermark){
	    		oldWatermark.parentNode.removeChild(oldWatermark);
	    	}
	    	// 创建水印容器，宽高与wut_container实际尺寸一致
	    	var watermarkDiv = document.createElement('div');
	    	watermarkDiv.className = 'kbck-watermark-container';
	    	watermarkDiv.style.cssText = 'position:absolute;top:0;left:0;width:' + containerWidth + 'px;height:' + containerHeight + 'px;z-index:9999;pointer-events:none;overflow:hidden;';

	    	// 计算水印数量和位置
	    	var watermarkWidth = 300;
	    	var watermarkHeight = 200;
	    	var cols = Math.ceil(containerWidth / watermarkWidth);
	    	var rows = Math.ceil(containerHeight / watermarkHeight);

	    	// 生成水印元素
	    	for(var i = 0; i < rows; i++){
	    		for(var j = 0; j < cols; j++){
	    			var watermarkItem = document.createElement('div');
	    			watermarkItem.className = 'kbck-watermark-item';
	    			watermarkItem.style.cssText = 'position:absolute;font-size:14px;color:#999;opacity:0.3;transform:rotate(-20deg);white-space:nowrap;';
	    			watermarkItem.style.left = (j * watermarkWidth + 50) + 'px';
	    			watermarkItem.style.top = (i * watermarkHeight + 30) + 'px';
	    			watermarkItem.innerHTML = watermarkText;
	    			watermarkDiv.appendChild(watermarkItem);
	    		}
	    	}

	    	container.style.position = 'relative';
	    	container.appendChild(watermarkDiv);
	    }
	};

	return viewConfig;
});