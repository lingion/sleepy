METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/common/components/jw-audit-flows/jw-audit-flows.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (111918 字符) --------
(function (window, $) {
    var BASE_PATH = contextPath + "/sys/jwcommon/public/script/common/components/jw-audit-flows/";
    var A = _JW_CONFIG.getCommon();
    var Assert = A.Assert;

    var ORDER_INTERVAL = 10;

    // 教务审核可配置按钮类型枚举
    window.JW_AUDIT_TYPE = {
        // 申请
        apply: "apply",
        // 修改
        edit: "edit",
        // 详情
        detail: "detail",
        // 删除
        delete: "delete",
        // 待申请
        auditApply: "auditApply",
        // 提交
        submit: "submit",
        // 撤回申请
        rollback: "rollback",
        // 审核通过
        auditPass: "auditPass",
        // 审核不通过
        auditNoPass: "auditNoPass",
        // 退回草稿
        auditSendBack: "auditSendBack",
        // 撤回审核
        auditRollback: "auditRollback",
        // 办结退回
        auditRepulse: "auditRepulse"
    };

    //region 审核流程一条龙组件
    (function ($) {
        var componentName = "jwAuditFlows";

        var Plugin;

        Plugin = (function () {
            function Plugin(element, options) {
                _.each(options, function (option, index) {
                    options[index] = $.extend({}, $.fn[componentName].defaults, option);
                });
                this.settings = options;
                //将dom jquery对象赋值给插件，方便后续调用
                this.$element = $(element);
                // 初始化组件
                init(this);
            }

            return Plugin;
        })();

        Plugin.prototype = {
            /**
             * 获取申请组件
             */
            getApply: function () {
                return this.$element.find('[data-x-role="apply-container"]');
            },
            /**
             * 获取待审核组件
             */
            getAuditing: function () {
                return this.$element.find('[data-x-role="auditing-container"]');
            },
            /**
             * 获取已审核组件
             */
            getAudited: function () {
                return this.$element.find('[data-x-role="audited-container"]');
            }
        };

        function init(instance) {
            var tabs = [];
            _.each(instance.settings, function (setting) {
                if (setting.type === "custom") {
                    // 自定义tab
                    tabs.push(setting);
                    return true;
                }
                var name = setting.name;
                var title = setting.title;

                var auditOpt = setting.auditOpt;
                // 非空检查
                Assert.notNull(name, "标识[name]不得为空");
                Assert.notNull(title, "标题[title]不得为空");
                Assert.notEmpty(auditOpt, "{}的审核选项[auditOpt]不得为空，apply/auditing/audited至少传入一项", title);

                var redPointSupporter = null;

                // 申请选项
                var applyOpt = auditOpt.apply;
                if (!_.isEmpty(applyOpt)) {
                    addTabObj(setting, "apply", tabs, function ($element) {
                        $element.html('<div data-x-role="apply-container" style="height: 100%"></div>');
                        $element.find('[data-x-role="apply-container"]').jwAuditFlowApply(
                            $.extend(
                                {
                                    tableReload: function () {
                                        redPointSupporter && redPointSupporter.refresh();
                                    },
                                    onLogFold: setting.onLogFold
                                },
                                applyOpt
                            )
                        );
                    });
                }

                // 待审核选项
                var auditingOpt = auditOpt.auditing;
                if (!_.isEmpty(auditingOpt)) {
                    auditingOpt = auditOpt.auditing = $.extend(
                        {
                            getRedPointParams: function () {
                                // 小红点参数默认获取queryAndTableOpts的params传参
                                return _.get(auditingOpt.queryAndTableOpts, "params");
                            }
                        },
                        auditOpt.auditing
                    );
                    redPointSupporter = {
                        refresh: function () {
                            var authId = setting.name + "_auditing";
                            refreshBadge($("#" + authId), auditingOpt);
                        }
                    };
                    addTabObj(setting, "auditing", tabs, function ($element) {
                        $element.html('<div data-x-role="auditing-container" style="height: 100%"></div>');
                        $element.find('[data-x-role="auditing-container"]').jwAuditFlowAuditing(
                            $.extend(
                                {
                                    onLogFold: setting.onLogFold
                                },
                                auditingOpt
                            )
                        );
                    });
                }

                // 已审核选项
                var auditedOpt = auditOpt.audited;
                if (!_.isEmpty(auditedOpt)) {
                    addTabObj(setting, "audited", tabs, function ($element) {
                        $element.html('<div data-x-role="audited-container" style="height: 100%"></div>');
                        $element.find('[data-x-role="audited-container"]').jwAuditFlowAudited(
                            $.extend(
                                {
                                    tableReload: function () {
                                        redPointSupporter && redPointSupporter.refresh();
                                    },
                                    onLogFold: setting.onLogFold
                                },
                                auditedOpt
                            )
                        );
                    });
                }
            });
            var tabOptions = { tabs: tabs };
            tabOptions.defaultTabId = getDefaultTabId(tabs);

            instance.$element.jwAuthTab(tabOptions);
            _.each(tabs, function (tab) {
                tab._initCb && tab._initCb();
            });
        }

        /**
         * 添加tab页签对象
         * @param setting 设置
         * @param type 类型
         * @param tabs 待添加的页签数组
         * @param callback 选中的回调
         */
        function addTabObj(setting, type, tabs, callback) {
            var titleTpl;
            var _initCb = undefined;
            var auditTypeOpt = setting.auditOpt[type];
            var authId = auditTypeOpt.authId || setting.name + "_" + type;
            var flowCode = setting.flowCode;
            if ("apply" === type) {
                titleTpl = setting.applyTitle;
            } else if ("auditing" === type) {
                titleTpl = setting.auditingTitle;
                _initCb = function () {
                    // 待审核需要在tab右上方显示待审核数量角标
                    refreshBadge($("#" + authId), auditTypeOpt);
                };
            } else if ("audited" === type) {
                titleTpl = setting.auditedTitle;
            }
            var tabTitle = A.formatStr(titleTpl, {
                title: setting.title
            });
            $.extend(
                auditTypeOpt,
                {
                    title: tabTitle,
                    // tab页不需要渲染h2标题
                    noTitle: true,
                    name: authId,
                    needReview: auditTypeOpt.needReview,
                    apiPrefix: setting.apiPrefix,
                    tableParams: setting.tableParams
                },
                auditTypeOpt
            );
            var needAuth = auditTypeOpt.needAuth !== undefined ? auditTypeOpt.needAuth : setting.needAuth;
            tabs.push({
                title: tabTitle,
                type: type,
                needAuth: needAuth,
                authId: authId,
                callback: callback,
                flowCode: flowCode,
                _initCb: _initCb
            });
        }

        // 这里定义一些组件内部的函数
        // function internalMethod(){}

        /**
         * 刷新或初始化右上角角标
         * @param $ele
         * @param auditTypeOpt
         */
        function refreshBadge($ele, auditTypeOpt) {
            if (!$ele.length) {
                return;
            }
            // 根据pagePath和action查询一次总数据条数
            var pagePath = auditTypeOpt.pagePath;
            var action = auditTypeOpt.action;
            var url = WIS_EMAP_SERV.getAbsPath(pagePath);
            url = WIS_EMAP_SERV.joinActionIdToDoUrl(url, action);
            $.ajax({
                url: auditTypeOpt.url || url,
                data: $.extend(
                    {
                        pageNumber: 1,
                        pageSize: 1,
                        __isAuditing: "1"
                    },
                    auditTypeOpt.tableParams,
                    auditTypeOpt.getRedPointParams()
                ),
                type: "post"
            }).done(function (res) {
                var total = res.datas[action].totalSize;
                // 初始化角标
                var $badgeEle = $ele.find(".jw-audit-flow-badge");
                if (!$badgeEle.length) {
                    $badgeEle = $(A.formatStr('<div class="bh-bg-danger">{}</div>', total));
                    // 给角标添加一些属性，后续当数据发生改变时可以根据这些属性修改数量
                    $badgeEle.addClass("jw-audit-flow-badge");
                    $badgeEle.attr("data-x-page-path", auditTypeOpt.pagePath);
                    $badgeEle.attr("data-x-action", auditTypeOpt.action);
                    $ele.append($badgeEle);
                } else {
                    $badgeEle.text(total);
                }
                var opt = parseInt(total) > 0 ? "removeClass" : "addClass";
                $badgeEle[opt]("bh-hide");
            });
        }

        /**
         * 教务标准审核流程tabs一条龙组件，数组中每个元素选项内容如下：
         * <ul>
         *     <li>name【string:null】【必填】:审核流程标识名</li>
         *     <li>title【string:null】【必填】:审核流程标题</li>
         *     <li>applyTitle【string:null】【选填】:申请tab的显示名，默认为'{title}申请记录'</li>
         *     <li>auditingTitle【string:null】【选填】:待审核tab的显示名，默认为'{title}待审核'</li>
         *     <li>auditedTitle【string:null】【选填】:已审核tab的显示名，默认为'{title}已审核'</li>
         *     <li>apiPrefix【string:null】【必填】:后台API前缀</li>
         *     <li>onLogFold【Function:[boolean,$ele]】【选填】:日志展开或收起的回调</li>
         *     <li>needAuth【boolean:null】【必填】:是否需要tab页权限</li>
         *     <li>tableParams【Object:null】【选填】:申请记录/待审核/已审核表格渲染时都会携带的参数</li>
         *     <li>
         *         auditOpt：审核选项【Object:null】，参数如下
         *         <ul>
         *             <li>apply：申请记录页面参数【Object】，不传此参数表示无需渲染申请页面，若传，则参数同 ：{@link jwAuditFlowApply}</li>
         *             <li>auditing：待审核页面参数【Object】，不传此参数表示无需渲染申请页面，若传，则参数同 ：{@link jwAuditFlowAuditing}</li>
         *             <li>audited：已审核页面参数【Object】，不传此参数表示无需渲染申请页面，若传，则参数同 ：{@link jwAuditFlowAudited}</li>
         *         </ul>
         *     </li>
         * </ul>
         * @param {Array} options 选项数组
         * @param params
         * @param callback
         * @see jwAuditFlowApply
         * @see jwAuditFlowAuditing
         * @see jwAuditFlowAudited
         */
        $.fn.jwAuditFlows = function (options, params, callback) {
            // 判断有些组件不需要url控制跳转详情
            if (params && params.needDetail === false) {
                IS_DETAIL = false;
            } else {
                IS_DETAIL = urlParams.type ? true : false;
            }
            var instance;
            instance = this.data(componentName);
            if (!instance || ($.type(options) === "object" && options.forceInit === true)) {
                if (!_.isArray(options)) {
                    options = [options];
                }
                return this.each(function () {
                    return $(this).data(componentName, new Plugin(this, options));
                });
            }
            if (options === true) return instance;
            if ($.type(options) === "string") {
                return instance[options](params, callback);
            }
            return this;
        };

        $.fn[componentName].defaults = {
            // tab和按钮是否需要走授权
            needAuth: true,
            // 申请记录tab标题
            applyTitle: "{title}申请记录",
            // 待审核tab标题
            auditingTitle: "{title}待审核",
            // 已审核tab标题
            auditedTitle: "{title}已审核",
            // 审核日志展开或收起的回调
            onLogFold: function (fold, $ele) {}
        };
    })($);
    //endregion

    //region 审核流程-申请记录组件
    (function ($) {
        var componentName = "jwAuditFlowApply";

        var Plugin;

        Plugin = (function () {
            function Plugin(element, options) {
                this.settings = $.extend({}, $.fn[componentName].defaults, options);
                //将dom jquery对象赋值给插件，方便后续调用
                this.$element = $(element);
                // 初始化组件
                init(this);
            }

            return Plugin;
        })();

        // API接口
        var apis = {
            // 获取当前用户信息
            getCurrentUserInfo: "getCurrentUserInfo",
            // 是否可代申请
            canAuditApply: "canAuditApply",
            // 保存申请单
            save: "save",
            // 单条申请单提交
            submit: "submit",
            // 单条申请单代申请提交
            auditSubmit: "auditSubmit",
            // 批量提交
            batchSubmit: "batchSubmit",
            // 撤回申请
            rollback: "rollback",
            // 删除
            delete: "delete"
        };

        Plugin.prototype = {
            /**
             * 获取jwQueryAndTable对象
             * @return {jQuery}
             */
            getJwQueryAndTable: function () {
                return this.$element.find('[data-x-role="jw-query-and-table"]');
            },
            /**
             * 刷新表格
             */
            refreshTable: function () {
                var settings = this.settings;
                this.getJwQueryAndTable().jwQueryAndTable("refreshTable");
                settings.tableReload && settings.tableReload();
            },
            // 获取页面动作参数信息
            getPageActionInfo: function () {
                return _getPageActionInfo(this);
            },
            /**
             * 打开申请单
             */
            openApplyForm: function () {
                var _this = this;
                var applyUserIdFieldName = _this.settings.applyUserIdFieldName;
                _sendRequest(_this, "getCurrentUserInfo", {
                    successMsg: "",
                    success: function (currentUserInfo) {
                        _openApplyForm(_this, {
                            title: "申请",
                            type: "apply",
                            afterFormInit: function ($form) {
                                var formUserInfo = {
                                    JBXX_SQR_XM_: currentUserInfo.name,
                                    JBXX_SQR_SZDWDM_: currentUserInfo.deptCode,
                                    JBXX_SQR_SZDWDM__DISPLAY: currentUserInfo.deptName
                                };
                                formUserInfo[applyUserIdFieldName] = currentUserInfo.id;
                                $form.emapForm("disableItem", ["JBXX_SQR_XM_", "JBXX_SQR_SZDWDM_", applyUserIdFieldName]);
                                $form.emapForm("setValue", formUserInfo);
                            },
                            onSubmit: function (opts) {
                                opts.loadingStart();
                                _sendRequest(_this, "submit", {
                                    data: opts.formValue,
                                    success: function () {
                                        _this.refreshTable();
                                        opts.close();
                                    },
                                    error: function () {
                                        opts.loadingEnd();
                                    }
                                });
                            }
                        });
                    }
                });
            },
            /**
             * 打开代申请单
             */
            openAuditApplyForm: function () {
                var _this = this;
                var settings = _this.settings;
                var applyUserIdFieldName = settings.applyUserIdFieldName;
                _openApplyForm(_this, {
                    title: "代申请",
                    type: JW_AUDIT_TYPE.auditApply,
                    afterFormInit: function ($form) {
                        $form.emapForm("disableItem", ["JBXX_SQR_XM_", "JBXX_SQR_SZDWDM_", applyUserIdFieldName]);
                        $form.emapForm("enableItem", applyUserIdFieldName);
                        $form
                            .find(A.formatStr('[data-name="{}"]', applyUserIdFieldName))
                            .off("click")
                            .on("click", function () {
                                // 动作名固化，在表格查询动作名后 + 代申请人员信息
                                var actionName = settings.action + "dsqryxx";
                                chooseAuditApplyPerson(
                                    function (res) {
                                        var selectUser = res[0] || {};
                                        var formUserInfo = {
                                            JBXX_SQR_XM_: selectUser.XM,
                                            JBXX_SQR_SZDWDM_: selectUser.SZDWDM,
                                            JBXX_SQR_SZDWDM__DISPLAY: selectUser.SZDWMC
                                        };
                                        formUserInfo[applyUserIdFieldName] = selectUser.USER_ID;
                                        $form.emapForm("setValue", formUserInfo);
                                    },
                                    settings.pagePath,
                                    actionName
                                );
                            });
                    },
                    onSubmit: function (opts) {
                        opts.loadingStart();
                        _sendRequest(_this, "auditSubmit", {
                            data: opts.formValue,
                            success: function () {
                                _this.refreshTable();
                                opts.close();
                            },
                            error: function () {
                                opts.loadingEnd();
                            }
                        });
                    }
                });
            },
            /**
             * 提交申请单
             */
            submitApplyForms: function (cs) {
                var msg = A.formatStr("确定提交{}的记录吗？", cs.isSingle ? "选择" : cs.isChecked ? "勾选" : "查询条件下");
                var _this = this;
                A.confirm(msg, function () {
                    _sendRequest(_this, "batchSubmit", {
                        data: $.extend({}, _getPageActionInfo(_this), {
                            querySetting: cs.querySetting
                        }),
                        successMsg: "",
                        success: function (countRes) {
                            countTips(countRes, "批量提交", cs.isSingle);
                            _this.refreshTable();
                        }
                    });
                });
            },
            /**
             * 编辑申请单
             */
            editApplyForm: function (data) {
                var _this = this;
                var applyUserIdFieldName = this.settings.applyUserIdFieldName;
                getAuditLogs(_this, data, function (logs) {
                    _openApplyForm(_this, {
                        title: "申请",
                        type: JW_AUDIT_TYPE.apply,
                        formValue: data,
                        logs: logs,
                        afterFormInit: function ($form) {
                            $form.emapForm("disableItem", ["JBXX_SQR_XM_", "JBXX_SQR_SZDWDM_", applyUserIdFieldName]);
                        },
                        onSubmit: function (opts) {
                            opts.loadingStart();
                            // 申请人是本人，走提交逻辑，否则视为代申请提交
                            var action = _JW_INIT_CONFIG.userid === opts.formValue[applyUserIdFieldName] ? "submit" : "auditSubmit";
                            _sendRequest(_this, action, {
                                data: opts.formValue,
                                success: function () {
                                    _this.refreshTable();
                                    opts.close();
                                },
                                error: function () {
                                    opts.loadingEnd();
                                }
                            });
                        }
                    });
                });
            },
            /**
             * 申请单详情
             */
            detailApplyForm: function (data) {
                var _this = this;
                var settings = this.settings;
                getAuditLogs(_this, data, function (logs) {
                    var createWinFormOpts = {
                        readonly: true,
                        title: "审核详情",
                        formValue: data,
                        logs: logs,
                        fullscreen: settings.fullscreen
                    };
                    // 展示前干预回调
                    settings.beforeWinFormShown && settings.beforeWinFormShown(createWinFormOpts);
                    createWinForm(_this, createWinFormOpts);
                });
            },
            /**
             * 撤回申请单
             */
            rollbackApplyForms: function (cs) {
                var msg = A.formatStr("确定撤回{}的申请吗？", cs.isSingle ? "选择" : cs.isChecked ? "勾选" : "查询条件下");
                var _this = this;
                A.confirm(msg, function () {
                    _sendRequest(_this, "rollback", {
                        data: $.extend({}, _getPageActionInfo(_this), {
                            querySetting: cs.querySetting
                        }),
                        successMsg: "",
                        success: function (countRes) {
                            countTips(countRes, "批量撤回申请", cs.isSingle);
                            _this.refreshTable();
                        }
                    });
                });
            },
            /**
             * 删除申请单
             */
            deleteApplyForms: function (cs) {
                var msg = A.formatStr("确定删除{}的记录吗？", cs.isSingle ? "选择" : cs.isChecked ? "勾选" : "查询条件下");
                var _this = this;
                A.confirm(msg, function () {
                    _sendRequest(_this, "delete", {
                        data: $.extend({}, _getPageActionInfo(_this), {
                            querySetting: cs.querySetting
                        }),
                        successMsg: "",
                        success: function (countRes) {
                            countTips(countRes, "批量删除", cs.isSingle);
                            _this.refreshTable();
                        }
                    });
                });
            }
        };

        function init(instance) {
            var settings = instance.settings;
            // 基础参数检查
            baseOptionsCheck(settings);
            var title = settings.title;
            // 创建默认按钮
            var btns = createBtns(instance);
            // 混合传入的按钮
            if (!_.isEmpty(settings.btns)) {
                btns = mergeAndSortBtns(btns, settings.btns);
            }
            // 初始化表格

            var appConfig = require("configUtils");
            // 判断是否开启参数

            var layoutView = Hogan.compile(settings.tpl || getTemplate("apply-layout.html"));
            instance.$element.html(
                layoutView.render({
                    title: title,
                    noTitle: settings.noTitle,
                    autoHeight: appConfig && appConfig.LAYOUT_FLEX && _JW_INIT_CONFIG.jwTableHeightAuto
                }),
                true
            );
            var tableOptions = $.extend(
                true,
                {},
                {
                    pagePath: settings.pagePath,
                    action: settings.action,
                    hasExport: true,
                    fileName: _.trim(title),
                    buttons: btns,
                    params: {
                        __isApply: "1"
                    }
                },
                settings.queryAndTableOpts
            );
            var $table = instance.getJwQueryAndTable();
            // 渲染前的回调
            settings.beforeTableRender && settings.beforeTableRender($table, tableOptions);
            $table.jwQueryAndTable(tableOptions);

            // 消息跳转 打开详情
            if (IS_DETAIL && urlParams.bizKey && urlParams.type === "apply" && !READ_DETAIL[urlParams.type + tableOptions.action]) {
                var url = WIS_EMAP_SERV.getAbsPath(tableOptions.pagePath);
                url = WIS_EMAP_SERV.joinActionIdToDoUrl(url, tableOptions.action);
                var requestParams = _.cloneDeep(tableOptions.params);

                var emapTableOptions = $table.jwQueryAndTable("getOptions").emapTable;
                var pk = emapTableOptions.pk;

                var queryOption = { name: pk, builder: "m_value_equal", linkOpt: "AND", value: urlParams.bizKey };

                if (requestParams.querySetting) {
                    var querySetting = JSON.parse(requestParams.querySetting);
                    querySetting.push(queryOption);
                    requestParams.querySetting = JSON.stringify(querySetting);
                } else {
                    requestParams.querySetting = JSON.stringify([queryOption]);
                }

                $.ajax({
                    url: url,
                    data: requestParams,
                    type: "post"
                }).done(function (res) {
                    if (res.datas && res.datas[tableOptions.action] && res.datas[tableOptions.action].rows && res.datas[tableOptions.action].rows.length === 1) {
                        var records = res.datas[tableOptions.action].rows;
                        var findDetailButton = tableOptions.buttons.find(function (btn) {
                            return btn.canSingle && !btn.canBatch && btn.type && btn.type === "detail";
                        });
                        if (!!findDetailButton && findDetailButton.callback && $.type(findDetailButton.callback) === "function") {
                            findDetailButton.callback({ records: records, isSingle: true, isChecked: true, hasRecord: true, querySetting: JSON.stringify([queryOption]) });
                        }
                    }
                });
                // 防止在切换审核tab时 再次打开详情弹窗
                READ_DETAIL[urlParams.type + tableOptions.action] = true;
            }
            setSpecialFieldNameFromTable(settings, $table);
            settings.afterInit && settings.afterInit(instance);
        }

        function createBtns(instance) {
            var order = 0;

            var btns = [
                {
                    order: (order += ORDER_INTERVAL),
                    text: "申请",
                    type: JW_AUDIT_TYPE.apply,
                    className: "bh-btn-primary",
                    needValidateCheckedRecords: false,
                    callback: function () {
                        instance.openApplyForm();
                    }
                }
            ];
            // 是否可代申请
            var canAuditApply = _sendRequest(instance, "canAuditApply", {
                async: false,
                successMsg: ""
            });
            if (canAuditApply) {
                btns.push({
                    order: (order += ORDER_INTERVAL),
                    text: "代申请",
                    type: JW_AUDIT_TYPE.auditApply,
                    needValidateCheckedRecords: false,
                    callback: function () {
                        instance.openAuditApplyForm();
                    }
                });
            }
            btns = btns.concat([
                {
                    order: (order += ORDER_INTERVAL),
                    text: "提交",
                    type: JW_AUDIT_TYPE.submit,
                    className: "bh-btn-success",
                    callback: function (cs) {
                        instance.submitApplyForms(cs);
                    }
                },
                {
                    order: (order += ORDER_INTERVAL),
                    text: "修改",
                    type: JW_AUDIT_TYPE.edit,
                    canBatch: false,
                    canSingle: true,
                    callback: function (cs) {
                        instance.editApplyForm(cs.records[0]);
                    },
                    beforeRender: function (options, rowData) {
                        return rowData.__CAN_EDIT_;
                    }
                },
                {
                    order: (order += ORDER_INTERVAL),
                    text: "详情",
                    type: JW_AUDIT_TYPE.detail,
                    canBatch: false,
                    canSingle: true,
                    callback: function (cs) {
                        instance.detailApplyForm(cs.records[0]);
                    },
                    beforeRender: function (options, rowData) {
                        // 不可编辑，则可查看详情
                        return !rowData.__CAN_EDIT_;
                    }
                },
                {
                    order: (order += ORDER_INTERVAL),
                    text: "撤回申请",
                    type: JW_AUDIT_TYPE.rollback,
                    canSingle: true,
                    callback: function (cs) {
                        instance.rollbackApplyForms(cs);
                    },
                    beforeRender: function (options, rowData) {
                        return rowData.__CAN_ROLLBACK_;
                    }
                },
                {
                    order: order + ORDER_INTERVAL,
                    text: "删除",
                    type: JW_AUDIT_TYPE.delete,
                    canSingle: true,
                    callback: function (cs) {
                        instance.deleteApplyForms(cs);
                    },
                    beforeRender: function (options, rowData) {
                        return rowData.__CAN_EDIT_;
                    }
                }
            ]);
            return btns;
        }

        // 私有打开申请窗口方法
        function _openApplyForm(instance, options) {
            var settings = instance.settings;
            createWinForm(
                instance,
                $.extend(options, {
                    btns: [
                        {
                            title: "保存",
                            className: "bh-btn-primary",
                            callback:
                                settings.applyFormSaveCallback ||
                                function (opts) {
                                    if (!opts.validateForm()) {
                                        return;
                                    }
                                    opts.loadingStart();
                                    _sendRequest(instance, "save", {
                                        data: opts.formValue,
                                        success: function () {
                                            instance.refreshTable();
                                            opts.close();
                                        }
                                    });
                                }
                        },
                        {
                            title: "提交",
                            className: "bh-btn-success",
                            callback:
                                settings.applyFormSubmitCallback ||
                                function (opts) {
                                    if (!opts.validateForm()) {
                                        return;
                                    }
                                    A.confirm("确认提交么？", function () {
                                        options.onSubmit(opts);
                                    });
                                }
                        }
                    ].concat(options.btns || [])
                })
            );
        }

        /**
         * 发送请求
         * @param instance
         * @param action
         * @param opts
         * @private
         */
        function _sendRequest(instance, action, opts) {
            var settings = instance.settings;
            opts.data = $.extend(
                {
                    __isApply: "1"
                },
                opts.data
            );
            return sendRequest(settings.apiPrefix, apis[action], opts);
        }

        /**
         * 获取页面模型动作组装的参数
         * @private
         */
        function _getPageActionInfo(instance) {
            var settings = instance.settings;
            var pageName = settings.pagePath.split("/").pop();
            if (/\.do$/.test(pageName)) {
                pageName = pageName.substring(0, pageName.length - 3);
            }
            var _pagePath = settings.pagePath;
            if (_pagePath.charAt(0) === "/") {
                _pagePath = _pagePath.substr(1);
            }
            var module = _pagePath.split("/").shift();

            var action = settings.action;
            return {
                app: _JW_INIT_CONFIG.appname,
                module: module,
                page: pageName,
                action: action,
                __isApply: "1"
            };
        }

        /**
         * 选择代申请的人员
         */
        function chooseAuditApplyPerson(cb, pagePath, actionName, opts) {
            var url = WIS_EMAP_SERV.getAbsPath(pagePath);
            url = WIS_EMAP_SERV.joinActionIdToDoUrl(url, actionName);
            var render = function (row, column, value, rowData) {
                return A.formatStr('<p class="gm-member-row bh-clearfix" >' + '<span class=" bh-col-md-9" row="{}">{}/{}/{}</span>' + "</p>", row, rowData.XM, rowData.USER_ID, rowData.SZDWMC);
            };
            $.bh_choose(
                $.extend(
                    {
                        leftSourceUrl: url,
                        leftSourceAction: actionName,
                        placeholder: "搜索职工号/姓名",
                        id: "USER_ID",
                        height: "600px",
                        multiSelect: false,
                        title: "选择教师",
                        params: {
                            __isQueryAuditApplyUser: "1"
                        },
                        rightcellsRenderer: render,
                        leftcellsRenderer: render,
                        callback: cb
                    },
                    opts
                )
            ).show();
        }

        /**
         * 教务标准审核流程申请记录组件
         * <ul>
         *     <li>name【string:null】【必填】:申请记录标识名</li>
         *     <li>title【string:null】【必填】:申请记录标题</li>
         *     <li>pagePath【string:null】【必填】:请求表格数据页面地址</li>
         *     <li>action【string:null】【必填】:emap动作名</li>
         *     <li>needAuth【boolean:null】【必填】:是否需要按钮权限</li>
         *     <li>formModel【Array:null】【选填】:弹窗表单的模型，不传则取表格模型，且自动隐藏审核状态列</li>
         *     <li>applyFormSaveCallback【Function:null】【选填】:申请单窗口申请/代申请保存的回调</li>
         *     <li>applyFormSubmitCallback【Function:null】【选填】:申请单窗口申请/代申请提交的回调</li>
         *     <li>afterInit【Function:null】【选填】:组件渲染完成后的回调</li>
         *     <li>onLogFold【Function:[boolean,$ele]】【选填】:日志展开或收起的回调</li>
         *     <li>btns【Array:[]】【选填】:额外的按钮，格式如：</li>
         *     <ul>
         *         <li>order【int:null】【选填】：顺序，不填则排在最后，值越小按钮越靠前，默认的按钮从左向右的order依次为10、20、30、40。。。</li>
         *         <li>其他属性同{@link jwQueryAndTable}的buttons</li>
         *     </ul>
         *     <li>queryAndTableOpts【Object:null】【选填】:jwQueryAndTable 组件覆盖的参数</li>
         * </ul>
         * @param {Object} options 审核记录
         * @param params
         * @param callback
         * @see jwQueryAndTable
         */
        $.fn.jwAuditFlowApply = function (options, params, callback) {
            var instance;
            instance = this.data(componentName);
            if (!instance) {
                return this.each(function () {
                    return $(this).data(componentName, new Plugin(this, options));
                });
            }
            if (options === true) return instance;
            if ($.type(options) === "string") {
                return instance[options](params, callback);
            }
            return this;
        };

        $.fn[componentName].defaults = {
            // 是否需要权限，无需权限
            needAuth: false,
            // 标题，不为空则渲染h2，否则视为无标题
            noTitle: undefined,
            // 渲染的模板，可覆盖默认的
            tpl: "",
            // 渲染jwQueryAndTable前的回调
            beforeTableRender: undefined,
            // 传入的表单模型，为空则取查询表格模型
            formModel: undefined,
            // 申请单窗口申请/代申请保存的回调
            applyFormSaveCallback: undefined,
            // 申请单窗口申请/代申请提交的回调
            applyFormSubmitCallback: undefined,
            // 提交时是否填写提交理由
            hasOpinion: false,
            // 提交理由标题
            opinionTitle: "提交理由",
            // 详情窗口是否全屏显示
            fullscreen: false,
            // 组件渲染完成后的回调
            afterInit: undefined,
            // 详情窗口展示前的回调，可干预展示配置
            beforeWinFormShown: undefined,
            // 缓存详情表单页信息
            winFormCache: true,
            // 审核日志展开或收起的回调
            onLogFold: function (fold, $ele) {}
        };
    })($);

    //endregion

    //region 审核流程-待审核组件
    (function ($) {
        var componentName = "jwAuditFlowAuditing";

        var Plugin;

        Plugin = (function () {
            function Plugin(element, options) {
                this.settings = $.extend({}, $.fn[componentName].defaults, options);
                //将dom jquery对象赋值给插件，方便后续调用
                this.$element = $(element);
                // 初始化组件
                init(this);
            }

            return Plugin;
        })();

        // API接口
        var apis = {
            auditPass: "auditPass",
            auditNoPass: "auditNoPass",
            auditSendBack: "auditSendBack"
        };

        Plugin.prototype = {
            /**
             * 获取jwQueryAndTable对象
             * @return {jQuery}
             */
            getJwQueryAndTable: function () {
                return this.$element.find('[data-x-role="jw-query-and-table"]');
            },
            // 获取页面动作参数信息
            getPageActionInfo: function () {
                return _getPageActionInfo(this);
            },
            /**
             * 刷新表格
             */
            refreshTable: function () {
                this.getJwQueryAndTable().jwQueryAndTable("refreshTable");
            },
            /**
             * 刷新小红点数量，寻找小红点角标方式：
             * 小红点角标的class需要包含[jw-audit-flow-badge]
             * 且有[data-x-page-path="pagePath"]和[data-x-action="action"]两个属性
             */
            refreshRedPoint: function () {
                var settings = this.settings;
                var $t = this.getJwQueryAndTable();
                var totalSize = $t.jwQueryAndTable("getTable").emapdatatable("getTotalRecords");
                // 刷新小红点内数量
                var selector = A.formatStr('.jw-audit-flow-badge[data-x-page-path="{}"][data-x-action="{}"]', settings.pagePath, settings.action);
                _.each($(selector), function (item) {
                    var $badgeEle = $(item);
                    $badgeEle.text(totalSize);
                    var opt = parseInt(totalSize) > 0 ? "removeClass" : "addClass";
                    $badgeEle[opt]("bh-hide");
                });
            },
            /**
             * 申请单详情
             */
            detailApplyForm: function (cs) {
                var _this = this;
                var settings = _this.settings;
                var data = cs.records[0];
                getAuditLogs(_this, data, function (logs) {
                    var btns = [
                        {
                            title: "通过",
                            type: JW_AUDIT_TYPE.auditPass,
                            className: "bh-btn-primary",
                            callback: function (opts) {
                                _this.auditPass(cs, function () {
                                    opts.close();
                                });
                            }
                        }
                    ];
                    if (settings.hasNoPass) {
                        btns.push({
                            title: "不通过",
                            type: JW_AUDIT_TYPE.auditNoPass,
                            className: "bh-btn-danger",
                            callback: function (opts) {
                                _this.auditNoPass(cs, function () {
                                    opts.close();
                                });
                            }
                        });
                    }
                    if (!isHiddenBtn("auditSendBack", settings)) {
                        btns.push({
                            title: "退回草稿",
                            type: JW_AUDIT_TYPE.auditSendBack,
                            className: "bh-btn-warning",
                            callback: function (opts) {
                                _this.auditSendBack(cs, function () {
                                    opts.close();
                                });
                            }
                        });
                    }
                    var createWinFormOpts = {
                        readonly: true,
                        title: "审核详情",
                        formValue: data,
                        logs: logs,
                        btns: btns,
                        fullscreen: settings.fullscreen
                    };
                    // 展示前干预回调
                    settings.beforeWinFormShown && settings.beforeWinFormShown(createWinFormOpts);
                    createWinForm(_this, createWinFormOpts);
                });
            },
            auditPass: function (cs, cb, extParams) {
                var _this = this;
                var fn = function () {
                    createAuditConfirmWin({
                        title: "审核确认",
                        opinionTitle: "通过意见",
                        opinion: "同意",
                        needReview: _this.settings.needReview,
                        callback: function (formValue) {
                            var auditPassFunc = function (params) {
                                _sendRequest(_this, "auditPass", {
                                    data: $.extend(
                                        {},
                                        _getPageActionInfo(_this),
                                        {
                                            querySetting: cs.querySetting,
                                            __opinion: formValue.opinion
                                        },
                                        params,
                                        extParams
                                    ),
                                    successMsg: "",
                                    showLoading: true,
                                    success: function (countRes) {
                                        cb && cb();
                                        if (!countRes) {
                                            // 无计数返回值，那么可能是自定义逻辑，只显示操作成功
                                            A.msg("操作成功");
                                        } else if (countRes.successCount) {
                                            // 有成功数量
                                            countTips(countRes, "批量通过", cs.isSingle);
                                        } else {
                                            A.msg(countRes.msg);
                                        }
                                        _this.refreshTable();
                                    }
                                });
                            };
                            if (_this.settings.needQrsign) {
                                // 需要扫码签名后通过
                                doQrsign(function (token) {
                                    auditPassFunc({
                                        qrsignToken: token
                                    });
                                });
                            } else {
                                // 不需要扫码签名，直接通过
                                auditPassFunc();
                            }
                        }
                    });
                };
                if (_this.isAuditByQuerySetting(cs)) {
                    A.confirm("是否批量通过当前搜索条件下所有数据？", fn);
                } else {
                    fn();
                }
            },
            auditNoPass: function (cs, cb, extParams) {
                var _this = this;
                var fn = function () {
                    createAuditConfirmWin({
                        title: "审核确认",
                        opinionTitle: "不通过意见",
                        opinion: "",
                        needReview: _this.settings.needReview,
                        callback: function (formValue) {
                            _sendRequest(_this, "auditNoPass", {
                                data: $.extend(
                                    {},
                                    _getPageActionInfo(_this),
                                    {
                                        querySetting: cs.querySetting,
                                        __opinion: formValue.opinion
                                    },
                                    extParams
                                ),
                                successMsg: "",
                                showLoading: true,
                                success: function (countRes) {
                                    cb && cb();
                                    countTips(countRes, "批量不通过", cs.isSingle);
                                    _this.refreshTable();
                                }
                            });
                        }
                    });
                };
                if (_this.isAuditByQuerySetting(cs)) {
                    A.confirm("是否批量不通过当前搜索条件下所有数据？", fn);
                } else {
                    fn();
                }
            },
            auditSendBack: function (cs, cb, extParams) {
                var _this = this;
                var fn = function () {
                    createAuditConfirmWin({
                        title: "审核确认",
                        opinionTitle: "退回意见",
                        opinion: "",
                        needReview: _this.settings.needReview,
                        callback: function (formValue) {
                            _sendRequest(_this, "auditSendBack", {
                                data: $.extend(
                                    {},
                                    _getPageActionInfo(_this),
                                    {
                                        querySetting: cs.querySetting,
                                        __opinion: formValue.opinion
                                    },
                                    extParams
                                ),
                                successMsg: "",
                                showLoading: true,
                                success: function (countRes) {
                                    cb && cb();
                                    if (!countRes) {
                                        // 无计数返回值，那么可能是自定义逻辑，只显示操作成功
                                        A.msg("操作成功");
                                    } else if (countRes.successCount) {
                                        // 有成功数量
                                        countTips(countRes, "批量退回", cs.isSingle);
                                    } else {
                                        A.msg(countRes.msg);
                                    }
                                    _this.refreshTable();
                                }
                            });
                        }
                    });
                };
                if (_this.isAuditByQuerySetting(cs)) {
                    A.confirm("是否退回当前搜索条件下所有数据？", fn);
                } else {
                    fn();
                }
            },
            // 是否根据搜索条件批量审核
            isAuditByQuerySetting: function (cs) {
                return !cs.isSingle && !cs.isChecked;
            }
        };

        function init(instance) {
            var settings = instance.settings;
            // 基础参数检查
            baseOptionsCheck(settings);
            var title = settings.title;
            // 创建默认按钮
            var btns = createBtns(instance);
            // 混合传入的按钮
            if (!_.isEmpty(settings.btns)) {
                btns = mergeAndSortBtns(btns, settings.btns);
            }
            // 初始化表格
            var appConfig = require("configUtils");
            var layoutView = Hogan.compile(settings.tpl || getTemplate("auditing-layout.html"));
            instance.$element.html(
                layoutView.render({
                    title: title,
                    noTitle: settings.noTitle,
                    autoHeight: appConfig && appConfig.LAYOUT_FLEX && _JW_INIT_CONFIG.jwTableHeightAuto
                }),
                true
            );
            var tableOptions = $.extend(
                true,
                {},
                {
                    pagePath: settings.pagePath,
                    action: settings.action,
                    hasExport: true,
                    fileName: _.trim(title),
                    buttons: btns,
                    params: {
                        __isAuditing: "1"
                    }
                },
                settings.queryAndTableOpts
            );
            var renderedFn = _.debounce(function () {
                instance.refreshRedPoint();
            }, 30);
            var $table = instance.getJwQueryAndTable();
            // 渲染前的回调
            settings.beforeTableRender && settings.beforeTableRender($table, tableOptions);
            // 增加重置小红点数量的回调方法
            var emapTableOpts = tableOptions.emapTable || {};
            var oldRendered = emapTableOpts.rendered;
            emapTableOpts.rendered = function () {
                oldRendered && oldRendered();
                renderedFn();
            };
            tableOptions.emapTable = emapTableOpts;

            $table.jwQueryAndTable(tableOptions);

            // 消息跳转 打开详情
            if (IS_DETAIL && urlParams.bizKey && urlParams.type === "auditing" && !READ_DETAIL[urlParams.type + tableOptions.action]) {
                var url = WIS_EMAP_SERV.getAbsPath(tableOptions.pagePath);
                url = WIS_EMAP_SERV.joinActionIdToDoUrl(url, tableOptions.action);
                var requestParams = _.cloneDeep(tableOptions.params);

                var emapTableOptions = $table.jwQueryAndTable("getOptions").emapTable;
                var pk = emapTableOptions.pk;

                var queryOption = { name: pk, builder: "m_value_equal", linkOpt: "AND", value: urlParams.bizKey };

                if (requestParams.querySetting) {
                    var querySetting = JSON.parse(requestParams.querySetting);
                    querySetting.push(queryOption);
                    requestParams.querySetting = JSON.stringify(querySetting);
                } else {
                    requestParams.querySetting = JSON.stringify([queryOption]);
                }

                $.ajax({
                    url: url,
                    data: requestParams,
                    type: "post"
                }).done(function (res) {
                    if (res.datas && res.datas[tableOptions.action] && res.datas[tableOptions.action].rows && res.datas[tableOptions.action].rows.length === 1) {
                        var records = res.datas[tableOptions.action].rows;
                        var findDetailButton = tableOptions.buttons.find(function (btn) {
                            return btn.canSingle && !btn.canBatch && btn.type && btn.type === "detail";
                        });
                        if (!!findDetailButton && findDetailButton.callback && $.type(findDetailButton.callback) === "function") {
                            findDetailButton.callback({ records: records, isSingle: true, isChecked: true, hasRecord: true, querySetting: JSON.stringify([queryOption]) });
                        }
                    }
                });
                // 防止在切换审核tab时 再次打开详情弹窗
                READ_DETAIL[urlParams.type + tableOptions.action] = true;
            }
            setSpecialFieldNameFromTable(settings, $table);
            settings.afterInit && settings.afterInit(instance);
        }

        function createBtns(instance) {
            var order = 0;
            var singleAudit = instance.settings.singleAudit;
            var btns = [
                {
                    order: order + ORDER_INTERVAL,
                    text: "详情",
                    type: JW_AUDIT_TYPE.detail,
                    canBatch: false,
                    canSingle: true,
                    callback: function (cs) {
                        instance.detailApplyForm(cs);
                    }
                }
            ];
            if (instance.settings.hasNoPass) {
                btns.push({
                    order: (order += ORDER_INTERVAL),
                    text: "不通过",
                    canSingle: singleAudit,
                    type: JW_AUDIT_TYPE.auditNoPass,
                    className: "bh-btn-danger",
                    callback: function (cs) {
                        instance.auditNoPass(cs);
                    }
                });
            }
            btns.push({
                order: (order += ORDER_INTERVAL),
                text: "通过",
                canSingle: singleAudit,
                type: JW_AUDIT_TYPE.auditPass,
                className: "bh-btn-primary",
                callback: function (cs) {
                    instance.auditPass(cs);
                }
            });
            if (!isHiddenBtn("auditSendBack", instance.settings)) {
                btns.push({
                    order: (order += ORDER_INTERVAL),
                    text: "退回草稿",
                    className: "bh-btn-warning",
                    canSingle: singleAudit,
                    type: JW_AUDIT_TYPE.auditSendBack,
                    callback: function (cs) {
                        instance.auditSendBack(cs);
                    }
                });
            }
            return btns;
        }

        /**
         * 发送请求
         * @param instance
         * @param action
         * @param opts
         * @private
         */
        function _sendRequest(instance, action, opts) {
            var settings = instance.settings;
            return sendRequest(settings.apiPrefix, apis[action], opts);
        }

        /**
         * 获取页面模型动作组装的参数
         * @private
         */
        function _getPageActionInfo(instance) {
            var settings = instance.settings;
            var pageName = settings.pagePath.split("/").pop();
            if (/\.do$/.test(pageName)) {
                pageName = pageName.substring(0, pageName.length - 3);
            }
            var _pagePath = settings.pagePath;
            if (_pagePath.charAt(0) === "/") {
                _pagePath = _pagePath.substr(1);
            }
            var module = _pagePath.split("/").shift();

            var action = settings.action;
            return {
                app: _JW_INIT_CONFIG.appname,
                module: module,
                page: pageName,
                action: action,
                __isAuditing: "1"
            };
        }

        /**
         * 教务标准审核流程待审核组件
         * <ul>
         *     <li>name【string:null】【必填】:申请记录标识名</li>
         *     <li>title【string:null】【必填】:申请记录标题</li>
         *     <li>pagePath【string:null】【必填】:请求表格数据页面地址</li>
         *     <li>action【string:null】【必填】:emap动作名</li>
         *     <li>needAuth【boolean:null】【必填】:是否需要按钮权限</li>
         *     <li>needQrsign【boolean:null】【必填】:审核通过是否需要扫码签名</li>
         *     <li>formModel【Array:null】【选填】:弹窗表单的模型，不传则取表格模型，且自动隐藏审核状态列</li>
         *     <li>winRender【Function($container):null】【选填】:详情窗口渲染的函数，有此函数则渲染的表单会隐藏</li>
         *     <li>hasNoPass【boolean:null】【选填】:是否有不通过操作，默认没有</li>
         *     <li>afterInit【Function:null】【选填】:组件渲染完成后的回调</li>
         *     <li>onLogFold【Function:[boolean,$ele]】【选填】:日志展开或收起的回调</li>
         *     <li>singleAudit【Boolean:false】【选填】:每条数据上是否显示通过/退回草稿按钮，默认不显示</li>
         *     <li>btns【Array:[]】【选填】:额外的按钮，格式如：</li>
         *     <ul>
         *         <li>order【int:null】【选填】：顺序，不填则排在最后，值越小按钮越靠前，默认的按钮从左向右的order依次为10、20、30、40。。。</li>
         *         <li>其他属性同{@link jwQueryAndTable}的buttons</li>
         *     </ul>
         *     <li>queryAndTableOpts【Object:null】【选填】:jwQueryAndTable 组件覆盖的参数</li>
         * </ul>
         * @param {Object} options 审核记录
         * @param params
         * @param callback
         * @see jwQueryAndTable
         */
        $.fn.jwAuditFlowAuditing = function (options, params, callback) {
            var instance;
            instance = this.data(componentName);
            if (!instance) {
                return this.each(function () {
                    return $(this).data(componentName, new Plugin(this, options));
                });
            }
            if (options === true) return instance;
            if ($.type(options) === "string") {
                return instance[options](params, callback);
            }
            return this;
        };

        $.fn[componentName].defaults = {
            // 是否需要权限，无需权限
            needAuth: false,
            // 标题，不为空则渲染h2，否则视为无标题
            noTitle: undefined,
            // 渲染的模板，可覆盖默认的
            tpl: "",
            // 每条数据上是否显示通过/退回草稿按钮
            singleAudit: false,
            // 渲染jwQueryAndTable前的回调
            beforeTableRender: undefined,
            // 传入的详情表单模型，为空则取查询表格模型
            formModel: undefined,
            // 详情窗口渲染的函数，有此函数则渲染的表单会隐藏
            winRender: undefined,
            // 详情窗口是否全屏显示
            fullscreen: false,
            // 是否有不通过操作
            hasNoPass: false,
            // 审核通过是否需要扫码签名
            needQrsign: false,
            // 组件渲染完成后的回调
            afterInit: undefined,
            // 缓存详情表单页信息
            winFormCache: true,
            // 审核日志展开或收起的回调
            onLogFold: function (fold, $ele) {},
            // 详情窗口展示前的回调，可干预展示配置
            beforeWinFormShown: undefined,
            // 详情窗口展示后的回调
            afterWinFormShown: undefined,
            // 详情窗口关闭后的回调
            afterWinFormClosed: undefined
        };
    })($);

    //endregion

    //region 审核流程-已审核组件
    (function ($) {
        var componentName = "jwAuditFlowAudited";

        var Plugin;

        Plugin = (function () {
            function Plugin(element, options) {
                this.settings = $.extend({}, $.fn[componentName].defaults, options);
                //将dom jquery对象赋值给插件，方便后续调用
                this.$element = $(element);
                // 初始化组件
                init(this);
            }

            return Plugin;
        })();

        // API接口
        var apis = {
            auditRepulse: "auditRepulse",
            auditRollback: "auditRollback",
            canAuditRepulse: "canAuditRepulse"
        };

        Plugin.prototype = {
            /**
             * 获取jwQueryAndTable对象
             * @return {jQuery}
             */
            getJwQueryAndTable: function () {
                return this.$element.find('[data-x-role="jw-query-and-table"]');
            },
            // 获取页面动作参数信息
            getPageActionInfo: function () {
                return _getPageActionInfo(this);
            },
            /**
             * 刷新表格
             */
            refreshTable: function () {
                var settings = this.settings;
                this.getJwQueryAndTable().jwQueryAndTable("refreshTable");
                settings.tableReload && settings.tableReload();
            },
            /**
             * 申请单详情
             */
            detailApplyForm: function (cs) {
                var _this = this;
                var data = cs.records[0];
                var settings = this.settings;
                getAuditLogs(_this, data, function (logs) {
                    var createWinFormOpts = {
                        readonly: true,
                        title: "审核详情",
                        formValue: data,
                        logs: logs,
                        fullscreen: settings.fullscreen
                    };
                    settings.beforeWinFormShown && settings.beforeWinFormShown(createWinFormOpts);
                    createWinForm(_this, createWinFormOpts);
                });
            },
            auditRollback: function (cs, cb, extParams) {
                var _this = this;
                var fn = function () {
                    createAuditConfirmWin({
                        title: "撤回审核确认",
                        opinionTitle: "撤回审核原因",
                        opinion: "",
                        needReview: _this.settings.needReview,
                        callback: function (formValue) {
                            _sendRequest(_this, "auditRollback", {
                                data: $.extend(
                                    {},
                                    _getPageActionInfo(_this),
                                    {
                                        querySetting: cs.querySetting,
                                        __opinion: formValue.opinion
                                    },
                                    extParams
                                ),
                                successMsg: "",
                                showLoading: true,
                                success: function (countRes) {
                                    cb && cb();
                                    countTips(countRes, "批量撤回", cs.isSingle);
                                    _this.refreshTable();
                                }
                            });
                        }
                    });
                };
                if (_this.isAuditByQuerySetting(cs)) {
                    A.confirm("是否批量撤回审核当前搜索条件下所有数据？", fn);
                } else {
                    fn();
                }
            },
            auditRepulse: function (cs, cb, extParams, opts) {
                opts = opts || {};
                var _this = this;
                var fn = function () {
                    createAuditConfirmWin({
                        title: "办结退回确认",
                        opinionTitle: "办结退回原因",
                        opinion: "",
                        needReview: _this.settings.needReview,
                        callback: function (formValue) {
                            _sendRequest(_this, "auditRepulse", {
                                data: $.extend(
                                    {},
                                    _getPageActionInfo(_this),
                                    {
                                        querySetting: cs.querySetting,
                                        __opinion: formValue.opinion
                                    },
                                    extParams
                                ),
                                successMsg: "",
                                showLoading: true,
                                success: function (countRes) {
                                    cb && cb();
                                    countTips(countRes, "办结退回", cs.isSingle, opts.showCount);
                                    _this.refreshTable();
                                }
                            });
                        }
                    });
                };
                if (_this.isAuditByQuerySetting(cs)) {
                    A.confirm("是否批量办结退回当前搜索条件下所有数据？", fn);
                } else {
                    fn();
                }
            },
            // 是否根据搜索条件批量审核
            isAuditByQuerySetting: function (cs) {
                return !cs.isSingle && !cs.isChecked;
            }
        };

        function init(instance) {
            var settings = instance.settings;
            // 基础参数检查
            baseOptionsCheck(settings);
            var title = settings.title;
            // 创建默认按钮
            var btns = createBtns(instance);
            // 混合传入的按钮
            if (!_.isEmpty(settings.btns)) {
                btns = mergeAndSortBtns(btns, settings.btns);
            }
            // 初始化表格
            var appConfig = require("configUtils");
            // 判断是否开启参数
           
            var layoutView = Hogan.compile(settings.tpl || getTemplate("audited-layout.html"));
            instance.$element.html(
                layoutView.render({
                    title: title,
                    noTitle: settings.noTitle,
                    autoHeight: appConfig && appConfig.LAYOUT_FLEX && _JW_INIT_CONFIG.jwTableHeightAuto
                }),
                true
            );
            var tableOptions = $.extend(
                true,
                {},
                {
                    pagePath: settings.pagePath,
                    action: settings.action,
                    hasExport: true,
                    fileName: _.trim(title),
                    buttons: btns,
                    params: {
                        __isAudited: "1"
                    }
                },
                settings.queryAndTableOpts
            );
            var $table = instance.getJwQueryAndTable();
            // 渲染前的回调
            settings.beforeTableRender && settings.beforeTableRender($table, tableOptions);
            $table.jwQueryAndTable(tableOptions);

            if (IS_DETAIL && urlParams.bizKey && (urlParams.type === "audited" || urlParams.isOther === '1') && !READ_DETAIL[urlParams.type + tableOptions.action]) {
                var url = WIS_EMAP_SERV.getAbsPath(tableOptions.pagePath);
                url = WIS_EMAP_SERV.joinActionIdToDoUrl(url, tableOptions.action);
                var requestParams = _.cloneDeep(tableOptions.params);

                var emapTableOptions = $table.jwQueryAndTable("getOptions").emapTable;
                var pk = emapTableOptions.pk;

                var queryOption = { name: pk, builder: "m_value_equal", linkOpt: "AND", value: urlParams.bizKey };

                if (requestParams.querySetting) {
                    var querySetting = JSON.parse(requestParams.querySetting);
                    querySetting.push(queryOption);
                    requestParams.querySetting = JSON.stringify(querySetting);
                } else {
                    requestParams.querySetting = JSON.stringify([queryOption]);
                }
                $.ajax({
                    url: url,
                    data: requestParams,
                    type: "post"
                }).done(function (res) {
                    if (res.datas && res.datas[tableOptions.action] && res.datas[tableOptions.action].rows && res.datas[tableOptions.action].rows.length === 1) {
                        var records = res.datas[tableOptions.action].rows;
                        var findDetailButton = tableOptions.buttons.find(function (btn) {
                            return btn.canSingle && !btn.canBatch && btn.type && btn.type === "detail";
                        });
                        if (!!findDetailButton && findDetailButton.callback && $.type(findDetailButton.callback) === "function") {
                            findDetailButton.callback({ records: records, isSingle: true, isChecked: true, hasRecord: true, querySetting: JSON.stringify([queryOption]) });
                        }
                    }
                });
                READ_DETAIL[urlParams.type + tableOptions.action] = true;
            }

            setSpecialFieldNameFromTable(settings, $table);
            settings.afterInit && settings.afterInit(instance);
        }

        function createBtns(instance) {
            var order = 0;

            var btns = [
                {
                    order: (order += ORDER_INTERVAL),
                    text: "详情",
                    type: JW_AUDIT_TYPE.detail,
                    canBatch: false,
                    canSingle: true,
                    callback: function (cs) {
                        instance.detailApplyForm(cs);
                    }
                }
            ];
            // 是否可办结退回
            var canAuditRepulse = _sendRequest(instance, "canAuditRepulse", {
                async: false,
                successMsg: ""
            });
            var auditRollbackBtn = {
                order: (order += ORDER_INTERVAL),
                text: "撤回审核",
                type: JW_AUDIT_TYPE.auditRollback,
                className: "bh-btn-warning",
                canSingle: true,
                callback: function (cs) {
                    instance.auditRollback(cs);
                },
                beforeRender: function (options, rowData) {
                    return rowData.__CAN_AUDIT_ROLLBACK_;
                }
            };
            var settings = instance.settings;
            var auditRepulseBtn = {
                order: (order += ORDER_INTERVAL),
                text: "办结退回",
                type: JW_AUDIT_TYPE.auditRepulse,
                className: "bh-btn-primary",
                canSingle: true,
                callback: function (cs) {
                    instance.auditRepulse(cs);
                },
                beforeRender: function (options, rowData) {
                    return rowData.__CAN_REPULSE_;
                }
            };
            if (_.isBoolean(canAuditRepulse)) {
                // 是否可办结退回，返回是布尔类型，那么表示此为同表单实例，办结退回按钮和撤回审核按钮互斥
                if (canAuditRepulse) {
                    if (!isHiddenBtn(auditRepulseBtn.type, settings)) {
                        btns.push(auditRepulseBtn);
                    }
                } else {
                    // 不可办结退回，那么会有撤回审核按钮
                    if (!isHiddenBtn(auditRollbackBtn.type, settings)) {
                        btns.push(auditRollbackBtn);
                    }
                }
            } else {
                var auditRepulseOption = canAuditRepulse;
                // 同表多实例下，会同时存在此用户组既有办结退回按钮，又有撤回审核按钮
                if (auditRepulseOption.canAuditRollback) {
                    // 可撤回审核，有撤回审核按钮
                    if (!isHiddenBtn(auditRollbackBtn.type, settings)) {
                        btns.push(auditRollbackBtn);
                    }
                }
                if (auditRepulseOption.canAuditRepulse) {
                    if (!isHiddenBtn(auditRepulseBtn.type, settings)) {
                        // 可办结退回，有办结退回按钮
                        btns.push(auditRepulseBtn);
                    }
                }
            }
            return btns;
        }

        /**
         * 发送请求
         * @param instance
         * @param action
         * @param opts
         * @private
         */
        function _sendRequest(instance, action, opts) {
            var settings = instance.settings;
            return sendRequest(settings.apiPrefix, apis[action], opts);
        }

        /**
         * 获取页面模型动作组装的参数
         * @private
         */
        function _getPageActionInfo(instance) {
            var settings = instance.settings;
            var pageName = settings.pagePath.split("/").pop();
            if (/\.do$/.test(pageName)) {
                pageName = pageName.substring(0, pageName.length - 3);
            }
            var _pagePath = settings.pagePath;
            if (_pagePath.charAt(0) === "/") {
                _pagePath = _pagePath.substr(1);
            }
            var module = _pagePath.split("/").shift();

            var action = settings.action;
            return {
                app: _JW_INIT_CONFIG.appname,
                module: module,
                page: pageName,
                action: action,
                __isAudited: "1"
            };
        }

        /**
         * 教务标准审核流程已审核组件
         * <ul>
         *     <li>name【string:null】【必填】:申请记录标识名</li>
         *     <li>title【string:null】【必填】:申请记录标题</li>
         *     <li>pagePath【string:null】【必填】:请求表格数据页面地址</li>
         *     <li>beforeTableRender【$table, tableOptions】渲染jwQueryAndTable前的回调</li>
         *     <li>action【string:null】【必填】:emap动作名</li>
         *     <li>needAuth【boolean:null】【必填】:是否需要按钮权限</li>
         *     <li>formModel【Array:null】【选填】:弹窗表单的模型，不传则取表格模型，且自动隐藏审核状态列</li>
         *     <li>winRender【Function($container):null】【选填】:详情窗口渲染的函数，有此函数则渲染的表单会隐藏</li>
         *     <li>afterInit【Function:null】【选填】:组件渲染完成后的回调</li>
         *     <li>onLogFold【Function:[boolean,$ele]】【选填】:日志展开或收起的回调</li>
         *     <li>btns【Array:[]】【选填】:额外的按钮，格式如：</li>
         *     <ul>
         *         <li>order【int:null】【选填】：顺序，不填则排在最后，值越小按钮越靠前，默认的按钮从左向右的order依次为10、20、30、40。。。</li>
         *         <li>其他属性同{@link jwQueryAndTable}的buttons</li>
         *     </ul>
         *     <li>queryAndTableOpts【Object:null】【选填】:jwQueryAndTable 组件覆盖的参数</li>
         * </ul>
         * @param {Object} options 审核记录
         * @param params
         * @param callback
         * @see jwQueryAndTable
         */
        $.fn.jwAuditFlowAudited = function (options, params, callback) {
            var instance;
            instance = this.data(componentName);
            if (!instance) {
                return this.each(function () {
                    return $(this).data(componentName, new Plugin(this, options));
                });
            }
            if (options === true) return instance;
            if ($.type(options) === "string") {
                return instance[options](params, callback);
            }
            return this;
        };

        $.fn[componentName].defaults = {
            // 是否需要权限，无需权限
            needAuth: false,
            // 标题，不为空则渲染h2，否则视为无标题
            noTitle: undefined,
            // 渲染的模板，可覆盖默认的
            tpl: "",
            // 渲染jwQueryAndTable前的回调
            beforeTableRender: undefined,
            // 传入的详情表单模型，为空则取查询表格模型
            formModel: undefined,
            // 详情窗口渲染的函数，有此函数则渲染的表单会隐藏
            winRender: undefined,
            // 详情窗口是否全屏显示
            fullscreen: false,
            // 表格重载时的回调
            tableReload: undefined,
            // 组件渲染完成后的回调
            afterInit: undefined,
            // 缓存详情表单页信息
            winFormCache: true,
            // 审核日志展开或收起的回调
            onLogFold: function (fold, $ele) {},
            // 详情窗口展示前的回调，可干预展示配置
            beforeWinFormShown: undefined,
            // 详情窗口展示后的回调
            afterWinFormShown: undefined,
            // 详情窗口关闭后的回调
            afterWinFormClosed: undefined
        };
    })($);

    //endregion

    // region 审核日志组件

    (function ($) {
        var componentName = "jwAuditFlowLogs";

        /**
         * @module 模块
         * @alias 审核日志组件
         * @description 自定义组件介绍
         */
        var Plugin;

        Plugin = (function () {
            function Plugin(element, options) {
                this.settings = $.extend({}, $.fn[componentName].defaults, options);
                //将dom jquery对象赋值给插件，方便后续调用
                this.$element = $(element);
                var _this = this;
                A.loadIView(function () {
                    // 初始化组件
                    init(_this);
                });
            }

            return Plugin;
        })();

        /**
         * 自定义组件提供的方法，使用
         * <li>$().componentName('methodName',params) 调用</li>
         */
        Plugin.prototype = {};

        function init(instance) {
            var logs = instance.settings.logs;
            if (_.isEmpty(logs)) {
                console.warn("审核日志为空");
                return;
            }
            var $ele = instance.$element;
            var template = getTemplate("audit-logs.vue");
            var id = BH_UTILS.NewGuid();
            $ele.html(A.formatStr('<div id="{}"></div>', id));
            instance.vm = new Vue({
                el: $("#" + id)[0],
                template: template,
                data: function () {
                    return {
                        logs: logs,
                        fold: instance.settings.fold,
                        hideFold: instance.settings.hideFold,
                        title: instance.settings.title
                    };
                },
                mounted: function () {
                    instance.settings.rendered(this.$refs["container"]);
                },
                computed: {
                    showTimeline: function () {
                        if (!this.fold) {
                            return true;
                        }
                        // 超过10条才收起，否则不收起
                        return _.isEmpty(this.logs) || this.logs.length <= 10;
                    }
                },
                methods: {
                    viewQrsign: function (token) {
                        var url = contextPath + "/sys/jwcommon/qrsign/get/image2/" + token + ".do";
                        $.bhGallery({
                            dataSource: [
                                {
                                    image: url
                                }
                            ],
                            show: 0,
                            // 隐藏缩略图
                            thumbnails: false,
                            // 隐藏数量显示
                            showCounter: false,
                            extend: function () {
                                this.bind("image", function (e) {
                                    // 在图片加载完成后执行的代码
                                    var $img = $(e.imageTarget);
                                    var $gallery = $img.closest(".bh-gallery");
                                    // 隐藏左右切换图片按钮
                                    $gallery.find(".galleria-image-nav").hide();
                                    // 背景图设置为白色
                                    $img.css({
                                        background: "#fff"
                                    });
                                });
                            }
                        });
                    },
                    toggleFold: function () {
                        this.fold = !this.fold;
                        if (this.fold) {
                            instance.settings.onFold(instance);
                        } else {
                            instance.settings.onUnfold(instance);
                        }
                    },
                    getLogStyle: function (log) {
                        if (log.virtual || !log.tagType) {
                            // 虚拟日志或无标签名，直接返回
                            return {};
                        }
                        return {
                            color: "#fff"
                        };
                    },
                    getLogClass: function (log) {
                        var classObj = {};
                        if (log.tagType) {
                            classObj[A.formatStr("bh-bg-{}", log.tagType)] = true;
                            classObj[A.formatStr("bh-bColor-{}", log.tagType)] = true;
                        } else {
                            classObj["bh-bColor-grey-3"] = true;
                        }
                        if (log.virtual) {
                            classObj["bh-color-grey-3"] = true;
                        }
                        return classObj;
                    }
                }
            });
        }

        // 这里定义一些组件内部的函数
        // function internalMethod(){}

        /**
         * 自定义组件定义处，可使用 $().componentName({}) 调用
         * @param options 选项
         * @param params 当是调用组件方法时（options为string），该值为该方法的参数
         * @param callback 自定义组件提供的方法的第二个参数，一般没有
         */
        $.fn.jwAuditFlowLogs = function (options, params, callback) {
            var instance;
            instance = this.data(componentName);
            if (!instance || $.type(options) === "object") {
                return this.each(function () {
                    return $(this).data(componentName, new Plugin(this, options));
                });
            }
            if (options === true) return instance;
            if ($.type(options) === "string") {
                return instance[options](params, callback);
            }
            return this;
        };

        $.fn[componentName].defaults = {
            // 日志数据
            logs: [],
            // 日志显示标题
            title: "流程日志",
            // 隐藏展开/收起按钮
            hideFold: false,
            // 默认展开
            fold: false,
            // 收起的回调
            onFold: function () {},
            // 展开的回调
            onUnfold: function () {},
            // 渲染完成后的回调
            rendered: function () {}
        };
    })($);

    // endregion

    // 最低优先级
    var LOWEST_PRECEDENCE = 0x7fffffff;

    /**
     * 合并按钮并排序
     * @param btns 合并的按钮数组
     * @param mergedBtns 被合并的按钮数组
     * @return 合并的按钮数组
     */
    function mergeAndSortBtns(btns, mergedBtns) {
        _.each(mergedBtns, function (btn) {
            // 没有order则赋值一个默认的最低优先级
            btn.order = _.isNumber(btn.order) ? btn.order : LOWEST_PRECEDENCE;
        });
        btns = btns.concat(mergedBtns);
        // 根据order排序并返回
        return _.sortBy(btns, function (o) {
            return o.order;
        });
    }

    /**
     * 从表格模型中设置特殊字段名
     * @param settings
     * @param $table
     */
    function setSpecialFieldNameFromTable(settings, $table) {
        var options = $table.jwQueryAndTable("getOptions");
        // 从表格组件的items中遍历获取包含[isAuditStatusFieldName=true]的作为审核状态字段名
        // 审核状态字段，默认为SHZT
        var auditStatusFieldName = "SHZT";
        // 申请人ID字段，默认为SQR
        var applyUserIdFieldName = "SQR";
        _.each(options.emapTable.datamodel, function (item) {
            if (item.isAuditStatusFieldName) {
                auditStatusFieldName = item.name;
            } else if (item.isApplyUserIdFieldName) {
                applyUserIdFieldName = item.name;
            }
        });
        settings.auditStatusFieldName = auditStatusFieldName;
        settings.applyUserIdFieldName = applyUserIdFieldName;
    }

    function getAuditLogs(instance, data, cb) {
        var options = instance.getJwQueryAndTable().jwQueryAndTable("getOptions");
        var pk = data[options.emapTable.pk];
        Assert.notNull(pk, "业务主键不得为空");
        // 获取审核日志
        sendRequest(instance.settings.apiPrefix, "getAuditLogs", {
            successMsg: "",
            data: {
                bizKey: pk
            },
            success: function (logs) {
                cb && cb(logs);
            }
        });
    }

    var templateCache = {};

    function getTemplate(path) {
        var cache = templateCache[path];
        if (cache) {
            return cache;
        }
        var utils = require("utils");
        var appVersion = utils.getConfig("APP_VERSION") || utils.getConfig("STATIC_TIMESTAMP") || "30000";
        var url = BASE_PATH + path + "?av=" + appVersion;
        var template = "";
        $.ajax({
            url: url,
            dataType: "text",
            async: false
        }).done(function (res) {
            template = res;
        });
        if ($.i18n) {
            template = utils.i18n(template);
        }
        templateCache[path] = template;
        return template;
    }

    /**
     * 基础设置参数检查
     * @param settings
     */
    function baseOptionsCheck(settings) {
        var name = settings.name;
        var title = settings.title;
        var pagePath = settings.pagePath;
        var action = settings.action;
        var apiPrefix = settings.apiPrefix;
        Assert.notNull(name, "标识[name]不得为空");
        Assert.notNull(title, "标题[title]不得为空");
        Assert.notNull(pagePath, "[pagePath]不得为空");
        Assert.notNull(action, "[action]不得为空");
        Assert.notNull(apiPrefix, "API前缀[apiPrefix]不得为空");
    }

    function sendRequest(apiPrefix, action, opts) {
        var url = apiPrefix + "/" + action + ".do";
        return $.jwAjax(
            $.extend(
                {
                    url: url
                },
                opts
            )
        );
    }

    function doQrsign(cb) {
        var token = BH_UTILS.NewGuid().replace(/-/g, "");
        JWP.loadQrSign(null, {
            token: token,
            timeout: 120,
            callback: function (result, params) {
                cb(token);
            }
        });
    }

    var tipsWinVM;

    /**
     * 成功和失败数提示
     * @param countRes
     * @param actionName 动作名称
     * @param isSingle 是否是单条操作
     * @param showCount 为true则强制使用数量弹窗，无论是否是单条数据审核
     */
    function countTips(countRes, actionName, isSingle, showCount) {
        if (isSingle && !showCount) {
            if (countRes.successCount) {
                A.msg("操作成功");
            } else {
                A.warn(countRes.failCounts[0].failMsg);
            }
            return;
        }
        if (tipsWinVM) {
            tipsWinVM.shows(countRes, actionName);
            return;
        }
        A.loadIView(function () {
            var id = BH_UTILS.NewGuid();
            $("body").append(A.formatStr('<div id="{}"></div>', id));
            tipsWinVM = new Vue({
                el: $("#" + id)[0],
                template: getTemplate("count-tips.vue"),
                data: function () {
                    return {
                        show: false,
                        countRes: null,
                        actionName: ""
                    };
                },
                mounted: function () {
                    this.shows(countRes, actionName);
                },
                methods: {
                    shows: function (countRes, actionName) {
                        this.countRes = countRes;
                        this.actionName = actionName;
                        this.show = true;
                    },
                    close: function () {
                        this.show = false;
                        this.countRes = null;
                        this.actionName = "";
                    }
                }
            });
        });
    }

    /**
     * 按钮是否配置了隐藏
     * @param btn
     * @param instance
     * @returns {boolean}
     */
    function isHiddenBtn(btnType, settings) {
        var hideBtns = settings.hideBtns;
        if (_.isEmpty(hideBtns)) {
            return false;
        }
        return _.includes(hideBtns, btnType);
    }

    /**
     * 创建表单窗口
     * @param instance 实例
     * @param options 选项
     */
    function createWinForm(instance, options) {
        var winFormKey = options.readonly ? "_readonlyWinFormVM" : "_winFormVM";
        var winFormVM = instance[winFormKey];
        if (instance.settings.winFormCache && winFormVM) {
            // 缓存表单窗口
            winFormVM.shows(options);
            return;
        }
        // 初始化并赋值
        A.loadIView(function () {
            var id = BH_UTILS.NewGuid();
            $("body").append(A.formatStr('<div id="{}"></div>', id));
            instance[winFormKey] = new Vue({
                el: $("#" + id)[0],
                template: getTemplate("win-form.vue"),
                data: function () {
                    var settings = _.cloneDeep(instance.settings);
                    var model = settings.formModel;
                    if (_.isEmpty(model)) {
                        // 获取动作的模型
                        model = _.cloneDeep(instance.getJwQueryAndTable().jwQueryAndTable("getOptions").emapTable.datamodel);
                        WIS_EMAP_SERV.convertModel(model, "form");
                        // 高度比例，根据model显示的items自动计算一次
                        var showItemCount = 0;
                        _.each(model, function (item) {
                            if (item.name === settings.auditStatusFieldName) {
                                // 审核状态字段默认隐藏
                                item.hidden = true;
                            }
                            if (!item.hidden) {
                                showItemCount++;
                            }
                        });
                    } else {
                        showItemCount = _.filter(model, function (item) {
                            return !item.hidden;
                        }).length;
                    }
                    // 最小0.4，最大0.6
                    showItemCount = Math.max(0.4, (showItemCount || 2) / 14);
                    var heightRatio = Math.min(showItemCount, 0.6);
                    var height = window.innerHeight * heightRatio;
                    height = height < 400 ? 400 : height;

                    var width = window.innerWidth * 0.6;
                    width = width < 800 ? 800 : width;
                    return {
                        title: "",
                        $form: null,
                        settings: settings,
                        model: model,
                        logs: [],
                        // 日志展开/收起，展开为false
                        logFold: false,
                        btns: [],
                        show: false,
                        loading: false,
                        minHeight: height + "px",
                        width: width + "px",
                        fullscreen: options.fullscreen
                    };
                },
                computed: {
                    hasLogs: function () {
                        return !_.isEmpty(this.logs);
                    },
                    formWidth: function () {
                        if (this.hasLogs) {
                            if (this.logFold) {
                                if (_.isNumber(this.settings.logFoldFormWidth)) {
                                    // 如果自己传了日志收起时的表单宽度，那么以传入的为准
                                    return this.settings.logFoldFormWidth + "%";
                                }
                                return "85%";
                            }
                            if (_.isNumber(this.settings.logExpandFormWidth)) {
                                // 如果自己传了日志展开时的表单宽度，那么以传入的为准
                                return this.settings.logExpandFormWidth + "%";
                            }
                            return "66.67%";
                        } else {
                            return "100%";
                        }
                    },
                    logsWidth: function () {
                        if (this.logFold) {
                            if (_.isNumber(this.settings.logFoldFormWidth)) {
                                // 如果自己传了日志收起时的表单宽度，那么以传入的为准
                                return 100 - this.settings.logFoldFormWidth + "%";
                            }
                            // 日志收起
                            return "15%";
                        }
                        if (_.isNumber(this.settings.logExpandFormWidth)) {
                            // 如果自己传了日志展开时的表单宽度，那么以传入的为准
                            return 100 - this.settings.logExpandFormWidth + "%";
                        }
                        return "33.33%";
                    },
                    hasCustomRender: function () {
                        return _.isFunction(this.settings.winRender);
                    }
                },
                mounted: function () {
                    this._initForm();
                    this.shows(options);
                },
                methods: {
                    changeVisible: function (show) {
                        if (!show) {
                            var that = this;
                            // 避免在消失动画进行中执行清理操作，导致展示出现问题
                            setTimeout(function () {
                                that.clear();
                            }, 200);
                        }
                    },
                    clear: function () {
                        this.loading = false;
                        this.fullscreen = false;
                        this.title = "";
                        this.btns = [];
                        this.logs = [];
                        // 日志默认展开
                        this.logFold = false;
                        this.$form.emapForm("clear");
                    },
                    shows: function (opts) {
                        this.title = opts.title;
                        this.fullscreen = !!opts.fullscreen;
                        this.btns = opts.btns || [];
                        this.logs = opts.logs;
                        var formValue = opts.formValue;
                        this.$form.emapForm("setValue", formValue);
                        if (this.hasCustomRender) {
                            this.$otherRender.removeClass("bh-hide");
                            this.$otherRender.html("<section></section>");
                            this.$form.addClass("bh-hide");
                            this.settings.winRender({
                                $container: this.$otherRender.find("section"),
                                formValue: formValue,
                                $form: this.$form
                            });
                        } else {
                            this.$otherRender.addClass("bh-hide");
                            this.$form.removeClass("bh-hide");
                        }
                        this.reloadLogs();
                        opts.afterFormInit && opts.afterFormInit(this.$form);
                        this.show = true;
                        this.settings.afterWinFormShown && this.$nextTick(this.settings.afterWinFormShown);
                    },
                    reloadLogs: function () {
                        // 存在日志，渲染日志
                        var $logContainer = $(this.$refs["logs"]);
                        var _this = this;
                        if (this.hasLogs) {
                            $logContainer.removeClass("bh-hide");
                            $logContainer.jwAuditFlowLogs({
                                /*width: this.logsWidth,
                                height: this.minHeight,
                                hideFold: true,*/
                                logs: _this.logs,
                                onFold: function () {
                                    _this.logFold = true;
                                    var $renderContainer = $(_this.$refs["render-container"]);
                                    instance.settings.onLogFold && instance.settings.onLogFold(_this.logFold, $renderContainer, instance);
                                },
                                onUnfold: function () {
                                    _this.logFold = false;
                                    var $renderContainer = $(_this.$refs["render-container"]);
                                    instance.settings.onLogFold && instance.settings.onLogFold(_this.logFold, $renderContainer, instance);
                                }
                            });
                        } else {
                            // 否则隐藏
                            $logContainer.addClass("bh-hide");
                        }
                    },
                    close: function () {
                        this.show = false;
                        this.settings.afterWinFormClosed && this.$nextTick(this.settings.afterWinFormClosed);
                    },
                    btnClick: function (btn) {
                        btn.callback({
                            validateForm: this._validateForm,
                            $form: this.$form,
                            formValue: this.$form.emapForm("getValue"),
                            vm: this,
                            loadingStart: this.loadingStart,
                            loadingEnd: this.loadingEnd,
                            close: this.close
                        });
                    },
                    loadingStart: function () {
                        this.loading = true;
                    },
                    loadingEnd: function () {
                        this.loading = false;
                    },
                    _validateForm: function () {
                        if (this.hasCustomRender) {
                            return true;
                        }
                        return this.$form.bhValidate("validate");
                    },
                    // 初始化表单
                    _initForm: function () {
                        var $form = $(this.$refs["form"]);
                        A.initEmapForm(
                            $form,
                            this.model,
                            null,
                            {
                                readonly: !!options.readonly,
                                mode: "t",
                                cols: 2
                            },
                            this.settings.formOpt
                        );
                        this.$form = $form;
                        this.$otherRender = $(this.$refs["other-render"]);
                    }
                }
            });
        });
    }

    var auditConfirmWinVM;

    function createAuditConfirmWin(options) {
        if(options.needReview === undefined) {
            options.needReview = true;
        }

        if(!options.needReview) {
            BH_UTILS.bhDialogSuccess({
                title: options.title,
                content: "是否确认继续？",
                callback: function () {
                    options.callback && options.callback({option: ""});
                }
            });
            return
        }
        if (auditConfirmWinVM) {
            auditConfirmWinVM.shows(options);
            return;
        }
        A.loadIView(function () {
            var id = BH_UTILS.NewGuid();
            $("body").append(A.formatStr('<div id="{}"></div>', id));
            auditConfirmWinVM = new Vue({
                el: $("#" + id)[0],
                template: getTemplate("audit-confirm-win.vue"),
                data: function () {
                    return {
                        show: false,
                        title: "",
                        opinionTitle: "",
                        callback: undefined,
                        width: 400,
                        height: 600
                    };
                },
                mounted: function () {
                    this.shows(options);
                },
                methods: {
                    shows: function (opts) {
                        this.show = true;
                        this.setValue(opts);
                        var $formContainer = $(this.$refs["form-container"]);
                        $formContainer.html('<div data-x-role="form"></div>');
                        var $form = $formContainer.find('[data-x-role="form"]');
                        var model = this.getModel();
                        A.initEmapForm($form, model, null, {
                            mode: "v"
                        });
                        $form.find(".bh-txt-input__txtarea").css({
                            padding: "2px"
                        });
                        $form.emapForm("setValue", {
                            opinion: opts.opinion
                        });
                        this.$form = $form;
                    },
                    confirm: function () {
                        var $form = this.$form;
                        if (!$form.bhValidate("validate")) {
                            return;
                        }
                        this.show = false;
                        this.callback($form.emapForm("getValue"));
                    },
                    setValue: function (opts) {
                        this.title = opts.title;
                        this.opinionTitle = opts.opinionTitle;
                        this.callback = opts.callback;
                    },
                    getModel: function () {
                        var model = [
                            {
                                caption: this.opinionTitle,
                                dataSize: 300,
                                xtype: "textarea",
                                dataType: "String",
                                name: "opinion",
                                required: true
                            }
                        ];
                        WIS_EMAP_SERV.convertModel(model, "form");
                        return model;
                    }
                }
            });
        });
    }

    function getQueryParams(url) {
        var queryString = url.split("?")[1];
        if (!queryString) {
            return {};
        }

        var params = {};
        var pairs = queryString.split("&");

        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split("=");
            var key = decodeURIComponent(pair[0]);
            var value = decodeURIComponent(pair[1] || "");
            params[key] = value;
        }

        return params;
    }

    function getDefaultTabId(tabs) {
        if (!urlParams.type) {
            return "";
        }
        var defaultTabId = "";
        if (urlParams.isOther === "1") {
            tabs.forEach(function (tab) {
                if (tab.type === "audited") {
                    defaultTabId = tab.authId;
                }
            });
        }
        var flowCodeable = tabs.every(function (tab) {
            return tab.flowCode;
        });
        if (flowCodeable && urlParams.flowCode) {
            var defaultTabs = [];
            tabs.forEach(function (tab) {
                if (urlParams.flowCode === tab.flowCode) {
                    // defaultTabId = tab.authId;
                    defaultTabs.push(tab);
                }
            });

            if (defaultTabs.length === 1) {
                defaultTabId = defaultTabs[0].authId;
            } else if (defaultTabs.length > 1) {
                defaultTabs.forEach(function (tab) {
                    if (tab.type === urlParams.type) {
                        defaultTabId = tab.authId;
                    }
                });
            }
        } else {
            tabs.forEach(function (tab) {
                if (tab.type === urlParams.type) {
                    defaultTabId = tab.authId;
                }
            });
        }
        return defaultTabId;
    }

    var urlParams = getQueryParams(window.location.search);

    var IS_DETAIL = urlParams.type ? true : false;

    var READ_DETAIL = {};
})(window, jQuery);
