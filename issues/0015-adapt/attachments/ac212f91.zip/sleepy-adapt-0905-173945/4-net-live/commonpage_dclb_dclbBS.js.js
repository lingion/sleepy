METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwpubapp/public/commonpage_dclb/dclbBS.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (913 字符) --------
define(function(require) {

    var utils = require('utils');

    var bs = {
        api: {
            dcwjlb: window.context_path + "/sys/jwpubapp/modules/gg/cxdcdwjlb.do",
            downloadUrl: window.context_path + "/sys/jwpubapp/export/getAttachment.do"
        },

        queryDcwjlb: function(param) {
            return utils.fetch({
                url: bs.api.dcwjlb,
                data: param,

                /***parser用于对接口返回的数据做进一步处理***/
                parser: function(res) {

                }
            });
        },

        downLoadFile: function(param) {
            return utils.fetch({
                url: bs.api.downloadUrl,
                data: param,

                /***parser用于对接口返回的数据做进一步处理***/
                parser: function(res) {

                }
            });
        }
    };

    return bs;
});