METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/common/jquery.binding.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (1130 字符) --------
/**
 * jQuery plugin for Sortable
 * @author	RubaXa   <trash@rubaxa.org>
 * @license MIT
 */
(function (factory) {
	"use strict";
	factory(jQuery);
})(function ($) {
	"use strict";

	/* CODE */


	/**
	 * jQuery plugin for Sortable
	 * @param   {Object|String} options
	 * @param   {..*}           [args]
	 * @returns {jQuery|*}
	 */
	$.fn.sortable = function (options) {
		var retVal,
			args = arguments;

		this.each(function () {
			var $el = $(this),
				sortable = $el.data('sortable');

			if (!sortable && (options instanceof Object || !options)) {
				sortable = new Sortable(this, options);
				$el.data('sortable', sortable);
			}

			if (sortable) {
				if (options === 'widget') {
					retVal = sortable;
				}
				else if (options === 'destroy') {
					sortable.destroy();
					$el.removeData('sortable');
				}
				else if (typeof sortable[options] === 'function') {
					retVal = sortable[options].apply(sortable, [].slice.call(args, 1));
				}
				else if (options in sortable.options) {
					retVal = sortable.option.apply(sortable, args);
				}
			}
		});

		return (retVal === void 0) ? this : retVal;
	};
});
