METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwpubapp/boot/js/boot_before.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (2053 字符) --------
/**
 * 在appcore.js加载之前加载的一些脚本
 * 由于appcore.js中定义了require.js
 * 直接加载很多js会报错
 */
;(function (window) {

    var TRUE_ARRAY = [ "true", "yes", "y", "t", "ok", "1", "on", "是", "对", "真" ]

    var _JW_INIT_CONFIG = window._JW_INIT_CONFIG || {};

    var DEBUG = _JW_INIT_CONFIG.DEBUG || false;

    var localDebug = localStorage.getItem('_JW_DEBUG');
    if (_.isString(localDebug)) {
        // 可在localStorage中手动设置一个参数，控制是否启用debug模式
        DEBUG = _JW_INIT_CONFIG.DEBUG = _.includes(TRUE_ARRAY,localDebug);
    }

    var APP_VERSION = _JW_INIT_CONFIG.APP_VERSION + '';
    var contextPath = window.contextPath = _JW_INIT_CONFIG.contextPath;

    // 调整WIS_CONFIG的加载顺序，放在最前
    window.WIS_CONFIG = {
        ROOT_PATH: _JW_INIT_CONFIG.ROOT_PATH,
        PATH: _JW_INIT_CONFIG.path,
        APPID: _JW_INIT_CONFIG.appId,
        APPNAME: _JW_INIT_CONFIG.appname
    };

    var RESOURCE_CONFIG = {
        COMMON_JS: [
            _getMin('jwpubapp/public/script/zeroPlugin/dist/zero-plugin') + '.js',
            'jwpubapp/public/script/zeroImporter2/zeroImporter2.js',
            'jwcommon/public/lib/jquery.cookie.js'
        ]
    };

    function _init() {
        _initJs();
    }

    function _initJs() {
        // 加载本业务线通用的js
        var commonJs = RESOURCE_CONFIG.COMMON_JS;
        for (var j = 0; j < commonJs.length; j++) {
            _createScript(contextPath + '/sys/' + commonJs[j]);
        }
    }

    _init();

    function _createScript(url) {
        /*var script = document.createElement('script');
        script.type = 'text/javascript';
        document.getElementsByTagName('head')[0].appendChild(script);*/
        var src = url + '?av=' + APP_VERSION;
        document.write('<script type="text/javascript" src="' + src + '"></script>');
    }

    function _getMin(path, suffix) {
        suffix = suffix || '.';
        return DEBUG ? path : path + suffix + 'min';
    }
})(window);