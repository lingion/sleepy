METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/public/commonpage/dyktyrgz/dyktyrgzBS.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (577 字符) --------
define(function(require) {
	var utils = require('utils');
	var bs = {
		api: {
			//查询进度
			cxzxjd: 'modules/xskcb/EMAP_SAPP_PROGRESS_QUERY.do'
        },
        queryZxjd: function(key) {
            return utils.fetch({
                url: WIS_EMAP_SERV.getAbsPath(bs.api.cxzxjd),
                data: {
                    KEY: key
                },

                /***parser用于对接口返回的数据做进一步处理***/
                parser: function(res) {

                }
            });
        }
  };

  return bs;
});
