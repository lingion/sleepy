METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/public/commonpage/kbck/printkb/printkbBS.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (377 字符) --------
define(function(require) {
	var utils = require('utils');

	var bs = {
		api : {
			// 报表权限写入Url
			bbqxxrUrl : "modules/xskcb/bbqxxr.do"
		},

		addFRreport : function(param,printUrl) {
			return utils.fetch({
				url : WIS_EMAP_SERV.getAbsPath(printUrl),
				data : param,
				parser : function(res) {

				}
			});
		}
	};

	return bs;
});
