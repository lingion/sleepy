METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/public/commonpage/zttk/zttkBS.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (161 字符) --------
define(function(require, exports, module) {
	
	var bs = {
		api: {
			pageModel : '/modules/jshkcb.do',
			cxztdkjl : 'cxztdkjl'
		}
	};
	return bs;
});