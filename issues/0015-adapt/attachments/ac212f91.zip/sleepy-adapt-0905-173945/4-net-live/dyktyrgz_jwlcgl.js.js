METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/public/commonpage/dyktyrgz/jwlcgl.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (8055 字符) --------
/*
 * 对外开放接口：
 * 1 getLcsl:function(LCDM) 获取当前流程的最新的关联实例
 * 2 getNextLcStatus:function(SLDM,DQZTDM) 根据流程实例和当前状态获取下一步状态值
 * 3 getUserLcStatus:function(JSDM,LCDM) 根据角色代码和流程代码获取相关的状态节点
 * 4 getCurJSDMByAppid(APPID) 获取APP当前登陆用户的角色代码JSDM
 * 5* getCurJSDM() 如果config.js配置了APP_ID,可用此函数代替getCurJSDMByAppid
 * 6 getRZLB(ROLEID),其中ROLEID可通过getCurJSDM()返回对象中得到
 * 使用说明：
 * LCDM:流程代码，新开课申请流程固定为XKKSQLC
 * SLDM:实例代码，可通过getLcsl获取
 * DQZTDM：申请单当前状态值
 * XBZTDM:申请单下步状态值
 * 
 * 1 新开课申请单中需增加SLDM和DQZTDM两个字段
 * 2 提交新开课申请单时,初始值SLDM=getLcsl('XKKSQLC'),DQZTDM=getNextLcStatus(SLDM,0);
 * 3 查看已申请单子时，获取角色代码JSDM,调用getUserLcStatus(JSDM,'XKKSQLC')，得到这个用户角色能有权限操作的状态。
 *   将符合此状态的申请单显示并给以审核权限
 * 4 但角色有审核权限对单子进行审批时，点击通过，调用getNextLcStatus(JSDM,DQZTDM)，获取XBZTDM，并将XBZTDM更新至数据表
 *   点击不通过，传递当前状态的负数为参，调用getNextLcStatus(JSDM,-DQZTDM)，获取XBZTDM，并将XBZTDM更新至数据表
 * 
 * */


define(function(require, exports, module) {
	var cfg=require("../../../config.js");
	var jwlcgl={
			initialize:function(){
	        	var path=window.location.href;
	            var end = path.indexOf('/sys/');
	            var context_path = path.substring(0, end);
	            this.app_context_path=context_path;
	            this.app_id=cfg.APP_ID;
			},
			app_context_path:null,
			app_id:null,
			/*为新申请单建立流程实例*/
			createLCSL:function(LCDM){
				var SLDM=this.genLCSL(LCDM);
				var ret=this.getLcStatusList(LCDM);
				var nodeArray=ret.datas.T_GG_ZTJ_LC2ZT_QUERY.rows;
				var slobj = [];
				var dqztdm = 0;
				var endztdm =99;
				var px =1;
				for(var i=0;i<nodeArray.length;i++)
				{
					var lcsl = {};
					lcsl.LCDM=LCDM;
					lcsl.SLDM=SLDM;
					lcsl.DQZTDM=dqztdm;
					lcsl.XBZTDM=nodeArray[i].ZTDM;
					lcsl.PX=px;
					slobj.push(lcsl);
					dqztdm = nodeArray[i].ZTDM;
					px=px+1;
				}
				var lctmp = {};
				lctmp.LCDM=LCDM;
				lctmp.SLDM=SLDM;
				lctmp.DQZTDM=dqztdm;
				lctmp.XBZTDM=endztdm;
				lctmp.PX=px;
				slobj.push(lctmp);
				var callback =function(){
					var addurl = this.getContextPath()+"/sys/stateapp/*default/showprocess/T_GG_ZTJ_LCSL_ADD.do";
					var addparams={"T_GG_ZTJ_LCSL_ADD":JSON.stringify(slobj)};
					var msg=function(){
					};
					this.ajaxaction(addurl,addparams,msg);
					return;
				};
				var url = this.getContextPath()+"/sys/stateapp/*default/showprocess/scsl.do";
				var delp = {'LCDM':LCDM};
				if(SLDM){
					delp.SLDM=SLDM;	
				}
				this.ajaxaction(url, {"scsl":JSON.stringify(delp)},callback);
			},
			/*根据流程代码获取此流程所有节点*/
			getLcStatusList:function(LCDM){
		    	var d=this.ajaxaction(this.getContextPath()+"/sys/stateapp/*default/shlc/T_GG_ZTJ_LC2ZT_QUERY.do",{'LCDM':LCDM});
		    	return d;			
			},
			getNextLcStatus:function(SLDM,DQZTDM){
				if(DQZTDM<0)
				{
					return {'DQZTDM':DQZTDM,'XBZTDM':-99,'XBZTDM_DISPLAY':'未通过','SLDM':SLDM};
				}
		    	var d=this.ajaxaction(this.getContextPath()+"/sys/stateapp/*default/shlc/gjdqztcxxygzt.do",{'SLDM':SLDM,'DQZTDM':DQZTDM});
		    	return d.datas.gjdqztcxxygzt.rows[0];
			},
			getlcstatebyrole:function(roleid,lcdm,sl){
				var url = this.getContextPath()+"/sys/stateapp/*default/showprocess/gjlcsljshddqzt.do";
				var params = {LCDM:lcdm,JSDM:roleid};
				if(sl){
					params.SLDM=sl;
				}
				var rd = this.ajaxaction(url,  {LCDM:lcdm,JSDM:roleid,SLDM:sl});
				console.log(rd);
//				var state = "";
//				for(var i =0;i<rd.length;i++){
//					state = rd[i].DQZTDM;
//					break;
//				}
//				if(state == "")state = "-9";
//				return state;
			},
			getUserLcStatus:function(JSDM,LCDM)
			{
				
				var rd = this.ajaxaction(this.getContextPath()+"/sys/stateapp/*default/shlc/T_GG_ZTJ_ZTQX_QUERY.do",  {'LCDM':LCDM,'JSDM':JSDM});
				return rd.datas.T_GG_ZTJ_ZTQX_QUERY.rows;
				
			},
			getLcsl:function(LCDM){
				var rd = this.ajaxaction(this.getContextPath()+"/sys/stateapp/*default/shlc/gjlcdmhqzxdsl.do",  {'LCDM':LCDM});
				return rd.datas.gjlcdmhqzxdsl.rows[0];
 
			},
			genLCSL:function(LCDM)
	        {
	            var myDate = new Date();
	            return(LCDM+""+myDate.getFullYear()+""+(myDate.getMonth()+1)+""+myDate.getDate()+""+myDate.getHours()+""
	            		+myDate.getMinutes()+""+myDate.getSeconds()+""+myDate.getMilliseconds());
	        },
	        getCurJSDM:function()
	        {
	        	
	        	var temp=this.ajaxaction((this.getContextPath()+"/sys/funauthapp/api/getUserAppGroups/"+this.app_id+".do"));
	            //var temp=[{"id":"27735d15-8439-47a0-94ac-fad2bec4729a","text":"AAAAA","active":true},{"id":"20160630170619339","text":"教务教师组"},{"id":"20160630170705403","text":"教务学生组"},{"id":"20160630170532763","text":"院系组"}];
	            var ret=null;
	            for(var i=0;i<temp.length;i++)
	            {
	            
	            	if(temp[i].active==true)
            		{
	            	   console.log(temp[i]);
	            	   ret=(temp[i]);
	            	   break;
            		}

	            }
	        	return ret;
	        },
	        getCurJSDMByAppid:function(appid)
	        {
	        	
	        	var temp=this.ajaxaction((this.getContextPath()+"/sys/funauthapp/api/getUserAppGroups/"+appid+".do"));
	            //var temp=[{"id":"27735d15-8439-47a0-94ac-fad2bec4729a","text":"AAAAA","active":true},{"id":"20160630170619339","text":"教务教师组"},{"id":"20160630170705403","text":"教务学生组"},{"id":"20160630170532763","text":"院系组"}];
	            var ret=null;
	            for(var i=0;i<temp.length;i++)
	            {
	            
	            	if(temp[i].active==true)
            		{
	            	   console.log(temp[i]);
	            	   ret=null;
	            	   break;
            		}

	            }
	        	return ret;
	        },
	        getContextPath:function(){
	            return this.app_context_path;
	        },
	        getRZLB:function(ROLEID){
	        	var ret='';
	        	var temp=this.ajaxaction(this.getContextPath()+'/sys/funauthapp/*default/qxgl/EMAP_SAPP_ROLE_RELATION_QUERY.do',{'ROLEID':ROLEID});	
	        	if(temp!=null && temp.datas!=null && temp.datas.EMAP_SAPP_ROLE_RELATION_QUERY.rows.length>0)
	        	{
	        		ret=temp.datas.EMAP_SAPP_ROLE_RELATION_QUERY.rows[0].CONTAINSROLES;
	        	}
	        	return ret;
	        },
	        ajaxaction:function(url,params,callback,callBackAll){
	        	var ret = {};
	        	$.ajax({
	        		url:url.slice(-3)==".do"?url:url+".do",
	        		type:'post',
	        		dataType:'json',
	        		data:params,
	        		async:false,
	        		error: function(XMLHttpRequest, textStatus, errorThrown) {
	        			if(callback!=undefined){
	        				console.log('ajaxaction系统异常，请联系管理员！');
	        			}
	                 },
	        		success:function(data){
	        			if(callBackAll && callBackAll===true){
	        				callback(data);
	        			}else{
	        				if(callback!=undefined){
	        					if(data.code==0){
	        						callback(data);
	        					}else{
	        						console.log('系统异常，请联系管理员！');
	        						return;
	        					}
	        				}else{
	        					ret = data;
	        				}
	        			}
	        		}
	        	});
	        	return ret;
	        }
	};
	jwlcgl.initialize();
	return jwlcgl;
});