METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/goldenfinger/goldenfingerPlugins.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (120155 字符) --------
(function () {
    var olModel;
    var olModelUtil;
    var utils;
    var zdbj;
    var zdxzzdy;
    var jsPathToGoldenFinger = "../../jwcommon/public/script/goldenfinger/ympz/js/";

    //初始化插件
    if (!window.GoldenFingerPlugins) {
        var GoldenFingerTool = function () {
            this.plugins = {};
            //设置默认方法
            this.plugins["default"] = {
                init: function (dom, item) {
                    try {
                        this.doInit(dom, item);
                    } catch (e) {
                        dom.remove();
                    }
                },
                doInit: function (dom, item) {
                    dom.append(item.buttonHtml);
                },
                onClick: function (e) {
                    var self = this;
                    var $target = $(e.currentTarget).children(".goldenfinger-btn");
                    var goldenfingerId = $target.attr("goldenfinger-id");
                    var url = WIS_CONFIG.ROOT_PATH + "/sys/jwcommon/goldenFinger/executeGoldenFinger/" + WIS_CONFIG.APPNAME + "/" + goldenfingerId + ".do";
                    $.post(url, { app: WIS_CONFIG.APPNAME }, function (res) {
                        if (res.code != 0) {
                            $.bhTip({
                                state: "danger",
                                content: "网络异常!"
                            });
                            return;
                        }
                        if (res.datas.code == 1) {
                            self.successCallBack(res);
                        } else {
                            $.bhTip({ state: "warning", content: res.datas.message });
                        }
                    });
                },
                successCallBack: function (res) {
                    $.bhTip({
                        state: "success",
                        content: res.datas.message
                    });
                }
            };
        };
        GoldenFingerTool.prototype = {
            register: function (name, func) {
                var self = this;
                if (!func) {
                    func = self.plugins["default"];
                }
                if (!func.init) {
                    func.init = self.plugins["default"].init;
                }
                if (!func.doInit) {
                    func.doInit = self.plugins["default"].doInit;
                }
                if (!func.onClick) {
                    func.onClick = self.plugins["default"]["onClick"];
                }
                if (!func.successCallBack) {
                    func.successCallBack = self.plugins["default"]["successCallBack"];
                }
                this.plugins[name] = func;
            },
            get: function (name) {
                var func = this.plugins[name];
                if (!func) {
                    func = this.plugins["default"];
                }
                return func;
            }
        };
        window.GoldenFingerPlugins = new GoldenFingerTool();
    }
    //显示表格信息
    GoldenFingerPlugins.register("showGridInfo", {
        /**
         * 展示表格信息
         * */
        onClick: function () {
            $('[emap-role="datatable"]').each(function () {
                var jobj = $(this);
                var emap = jobj.attr("emap");
                if (!emap) {
                    $.bhTip({
                        content: "此页面不存在emap表格!",
                        state: "warning"
                    });
                }
                var emapInfo = JSON.parse(emap);
                jobj.addClass("zet_grid_selected");

                var jobjId = "toolTip-" + jobj.attr("id");
                var pageUrl = emapInfo["emap-pagePath"].replace(".do", "");
                //如果第一个位置上没有 / 则补上
                if (pageUrl.indexOf("/") != 0) {
                    pageUrl = "/" + pageUrl;
                }
                if (pageUrl.lastIndexOf("/") != pageUrl.length - 1) {
                    pageUrl = pageUrl + "/";
                }
                var action = emapInfo["emap-action"];
                if (action.indexOf("/") > -1) {
                    pageUrl = pageUrl + "/" + action + ".do";
                } else {
                    pageUrl = pageUrl + action + ".do";
                }
                var content = '<div id="' + jobjId + '"> EPG地址：' + emapInfo["emap-pagePath"] + "<br>动作名：" + emapInfo["emap-action"] + "<br>";
                content += "查询地址：" + pageUrl + "<br>模型名：" + emapInfo["emap-model-name"] + " </div>";
                var btnContent =
                    '<div style="margin:4px 0;"><input role-action="zet_查看原始SQL" role-id="' +
                    jobj.attr("id") +
                    '" role-emapaction="' +
                    emapInfo["emap-action"] +
                    '" role-url="' +
                    pageUrl +
                    '" value="查看原始SQL" type="button" class="bh-btn bh-btn-danger"/></div>';
                jobj.jqxTooltip({
                    content: content + btnContent,
                    position: "top",
                    name: "movieTooltip",
                    autoHide: true,
                    closeOnClick: true
                });
                $('[role-action="zet_查看原始SQL"]')
                    .off("click")
                    .on("click", function (e) {
                        goldenFingerTools.showGridSql(e);
                    });

                /**
                 * 弹出提示对话框
                 */
                function ggf_alert(content, title, okFn) {
                    if (arguments.length === 2 && typeof title === "function") {
                        okFn = title;
                        title = undefined;
                    }

                    BH_UTILS.bhDialogWarning({
                        title: title || BH_UTILS.i18n("text.prompt|提示"),
                        content: content,
                        buttons: [
                            {
                                text: BH_UTILS.i18n("text.gotit|知道了"),
                                callback: function () {
                                    if (typeof okFn === "function") {
                                        okFn();
                                    }
                                }
                            }
                        ]
                    });
                }

                $("#" + jobjId).click(function (e) {
                    ggf_alert(content, "表格模型信息");
                });
            });
        },
        showGridSql: function (e) {
            var taget = $(e.currentTarget);
            var url = taget.attr("role-url");
            var id = taget.attr("role-id");
            var emapaction = taget.attr("role-emapaction");

            var params = {};
            try {
                var obj = $("#" + id).emapdatatable("getCurrentQueryParams");
                for (var p in obj) {
                    if (obj.hasOwnProperty(p)) {
                        params[p] = obj[p];
                    }
                }
            } catch (e) {}
            params["WID"] = "__query_s_q_l," + $.cookie(_cookie_name);
            params["pageSize"] = 1;
            params["pageNumber"] = 1;

            $.post(WIS_EMAP_SERV.getAbsPath(url), params, function (r) {
                var html = '<div style="padding:8px;background:#f1f1f1;">';
                html += '	<div id="zet_orisqlModal" style="white-space:pre-line;margin-bottom:4px;"></div>';
                html += '	<div id="zet_sub1Div" style="background:#f3e3e3;padding:4px;font-weight:bold;margin-bottom:4px;"></div>';
                html += '	<div id="zet_sub2Div" style="background:#f3e3e3;padding:4px;font-weight:bold;"></div>';
                html += "	</div>";
                zeroModal.show({
                    title: "查看原始SQL",
                    content: html,
                    width: "85%",
                    height: "85%",
                    cancel: true,
                    overlayClose: true
                });
                try {
                    var obj = JSON.parse(r.datas[emapaction].extParams.msg);
                    $("#zet_orisqlModal").html(obj.script || "");
                    $("#zet_sub1Div").html("sub1:" + (obj.sub1 || ""));
                    $("#zet_sub2Div").html("sub2:" + (obj.sub2 || ""));
                } catch (e) {
                    $("#zet_orisqlModal").html("无数据显示");
                    $("#zet_sub1Div").html("无数据显示");
                    $("#zet_sub2Div").html("无数据显示");
                }
            });
        }
    });
    //字典管理
    GoldenFingerPlugins.register("dicManageGoldenFingerPlugin", {
        /**
         * 触发点击事件
         * */
        onClick: function (e) {
            this.showDicPop();
        },
        /**
         * 显示查看字典弹窗
         */
        showDicPop: function () {
            var self = this;
            if ($('[role="zet_ckzd"]').length > 0) {
                $('[role="zet_ckzd"]').remove();
                $(".zet_selected").removeClass("zet_selected");
                return;
            }

            $("[data-url]").each(function () {
                var jobj = $(this);
                var tagClass = "zet_tag" + (jobj.height() > 0 ? "" : " zet_tag_noheight");
                var url = jobj.attr("data-url");
                var dic = _getDicByUrl(url);
                if (dic) {
                    jobj.addClass("zet_selected").after(
                        '<div role="zet_ckzd" style="position:relative;z-index:1000;"><div role-action="zet_viewdic" data-dic-url="' +
                            url +
                            '" role-dic="' +
                            dic +
                            '" class="' +
                            tagClass +
                            '">i</div></div>'
                    );
                    $('[role-dic="' + dic + '"]').jqxTooltip({
                        content: "查看字典",
                        position: "top"
                    });
                }
            });

            // 拿到表格dom
            var $tables = $("body").find('div[emap-role="datatable"]:visible');
            if ($tables && $tables.length) {
                for (var i = 0; i < $tables.length; i++) {
                    var $table = $($tables[i]);
                    // 判断表格dom是否存在emap属性
                    var emap = $table.attr("emap");
                    if (emap) {
                        emap = JSON.parse(emap);
                        var model = WIS_EMAP_SERV.getModel(emap["emap-pagePath"], emap["emap-action"], "table");

                        var $columns = $table.find('.jqx-grid-header div[role="columnheader"] span');
                        if ($columns && $columns.length) {
                            for (var c = 0; c < $columns.length; c++) {
                                var $column = $($columns[c]);
                                var name = $column.html();
                                var findColumn = model.find(function (m) {
                                    return m.caption === name;
                                });

                                if (!!findColumn && findColumn.url) {
                                    $column.attr("data-url", findColumn.url);
                                    var tagClass = "zet_tag" + ($column.height() > 0 ? "" : " zet_tag_noheight");
                                    var dic = _getDicByUrl(findColumn.url);
                                    if (dic) {
                                        $column
                                            .parent()
                                            .parent()
                                            .addClass("zet_selected")
                                            .after(
                                                '<div role="zet_ckzd" style="position:relative;z-index:1000;"><div style="right: 2px;top: -26px;" role-action="zet_viewdic" data-dic-url="' +
                                                    findColumn.url +
                                                    '" role-dic="' +
                                                    dic +
                                                    '" class="' +
                                                    tagClass +
                                                    '">i</div></div>'
                                            );
                                        $('[role-dic="' + dic + '"]').jqxTooltip({
                                            content: "查看字典",
                                            position: "top"
                                        });
                                    }
                                }
                            }
                        }
                        // model.forEach(function (m) {

                        // })
                    }
                }
            }

            $('[role-action="zet_viewdic"]')
                .off("click")
                .on("click", function (e) {
                    e.stopPropagation();
                    var url = $(e.currentTarget).data("dic-url");
                    $.post(url, {}, function (res) {
                        self.shoDicDetail(e);
                    });
                });

            //以下均为工具方法
            function _getDicByUrl(url) {
                if (!url || url === "undefined" || url === "null") {
                    return "";
                }
                var urlParams = url.split("/");
                var dic = urlParams[3];
                if (urlParams[4]) {
                    dic += "@" + urlParams[4];
                }
                return dic.replace(".do", "");
            }
        },
        shoDicDetail: function (e) {
            var self = this;
            var dic = $(e.currentTarget).attr("role-dic");
            $.post(WIS_EMAP_SERV.getContextPath() + "/sys/jwcommon/dictionary/viewDicInfo/" + WIS_CONFIG.APPNAME + "/" + dic + ".do", {}, function (res) {
                var info = res.datas;
                var opt = {
                    title: '查看字典详情（<span class="bh-color-warning">' + (info.dicName || "") + (info.actionName || "") + "</span>）",
                    content: '<div id="zet_dicInfoModal"></div>',
                    overlayClose: true,
                    cancel: true,
                    width: "900px"
                };
                if (info.dicCode) {
                    opt.height = "80%";
                    zeroModal.show(opt);

                    var isModel = info.actionName.startsWith("model:");

                    var html = "";
                    html += '<table class="bh-table">';
                    html += "	<tr>";
                    html += '		<td class="bh-bg-info-4" style="width:15%">字典标识</td>';
                    html += '		<td style="width:40%;">' + info.dicCode + "</td>";
                    html += '		<td class="bh-bg-info-4" style="width:15%">所属应用</td>';
                    html += "		<td>" + info.appName + "</td>";
                    html += "	</tr>";
                    html += "	<tr>";
                    html += '		<td class="bh-bg-info-4">字典类型</td>';
                    html += "		<td>" + (info.dicType || "") + "</td>";
                    html += '		<td class="bh-bg-info-4">数据来源</td>';
                    html += "		<td>" + info.actionName + "</td>";
                    html += "	</tr>";
                    html += "	<tr>";
                    html += '		<td class="bh-bg-info-4" title="动态限制条件只在下拉中生效，翻译时不生效！">动态限制条件</td>';
                    html += "		<td>" + (info.selectFilter || "未设置") + "</td>";
                    html += '		<td class="bh-bg-info-4">固定限制条件</td>';
                    html += "		<td>" + (info.fixedFilter || "未设置") + "</td>";
                    html += "	</tr>";
                    html += "	<tr>";
                    html += '		<td class="bh-bg-info-4" >编码字段</td>';
                    html += "		<td>" + (info.keyColumn || "未设置") + "</td>";
                    html += '		<td class="bh-bg-info-4">显示字段</td>';
                    html += "		<td>" + (info.valueColumn || "未设置") + "</td>";
                    html += "	</tr>";
                    html += "	<tr>";
                    html += '		<td class="bh-bg-info-4" >排序字段</td>';
                    html += "		<td>" + (info.orderColumn || "未设置") + "</td>";
                    html += '		<td class="bh-bg-info-4">类别字段</td>';
                    html += "		<td>" + (info.typeColumn || "未设置") + "</td>";
                    html += "	</tr>";
                    html += "</table>";
                    html += '<div id="zet_dicContentDiv" style="margin-top:8px;display:none;">';
                    html += '	<div style="margin-left:-4px;">';
                    html +=
                        '		<a href="javascript:void(0)" role-appName="' + info.appName + '"  role-dic="' + dic + '" role-action="zet_refreshDic" class="bh-btn bh-btn-primary bh-btn-small">刷新缓存</a>';
                    if (isModel) {
                        html += '		<a href="javascript:void(0)" role-appName="' + info.appName + '"  role-dic="' + dic + '" role-action="zet_add" class="bh-btn bh-btn-primary bh-btn-small">新增</a>';
                    }
                    html += "	</div>";
                    html += '	<div id="zet_dicContentGrid" style="margin-top:6px;"></div>';
                    html += "</div>";
                    $("#zet_dicInfoModal").html(html);
                    if (info.dicCode) {
                        $('[role-action="zet_refreshDic"]')
                            .off("click")
                            .on("click", function (e) {
                                var $target = $(e.currentTarget);
                                $.ajax({
                                    url:
                                        WIS_EMAP_SERV.getContextPath() +
                                        "/sys/emapcomponent/clearDicCache.do?app=" +
                                        $target.attr("role-appName") +
                                        "&dic=" +
                                        $target.attr("role-dic").split("@")[0] +
                                        "",
                                    type: "post",
                                    dataType: "json",
                                    async: false,
                                    success: function (data) {
                                        $(".zeromodal-close").trigger("click");
                                        $.bhTip({
                                            content: "操作成功",
                                            state: "success"
                                        });
                                        self.shoDicDetail(e);
                                    }
                                });
                            });
                        $("#zet_dicContentDiv").show();
                        $.each(info.items, function (index, item) {
                            item.order = item.order == "null" ? "未设置" : item.order;
                            item.inUsed = item.inUsed == "null" ? "未设置" : item.inUsed;
                        });
                        var columns = [
                            {
                                property: "value",
                                display: "代码"
                            },
                            {
                                property: "label",
                                display: "名称"
                            },
                            {
                                property: "inUsed",
                                display: "是否使用"
                            },
                            {
                                property: "order",
                                display: "排序"
                            }
                        ];
                        if (isModel) {
                            columns.unshift({
                                display: "操作",
                                view: function (col) {
                                    var html = '<div class="jqx-center-align">';
                                    html +=
                                        '<a href="javascript:void(0)" role-appName="' +
                                        info.appName +
                                        '"  role-dic="' +
                                        dic +
                                        '" role-action="zet_edit" role-dm="' +
                                        col.value +
                                        '" role-mc="' +
                                        col.label +
                                        '" role-px="' +
                                        (col.order == "未设置" ? "" : col.order) +
                                        '">编辑</a>';
                                    html += " | ";
                                    html += '<a href="javascript:void(0)" role-appName="' + info.appName + '"  role-dic="' + dic + '" role-action="zet_delete" role-dm="' + col.value + '">删除</a>';
                                    html += "</div>";
                                    return html;
                                }
                            });
                        }
                        var _grid = new zeroJqxGrid({
                            container: "#zet_dicContentGrid",
                            datas: info.items,
                            columns: columns,
                            pageSize: 10,
                            parseLoadDataFunc: function (data) {
                                var newData = {};
                                newData.pageIndex = 1;
                                newData.pageSize = 10;
                                newData.total = info.items.size;
                                newData.datas = info.items;
                                return newData;
                            },
                            loadDataAppendDataFunc: function () {
                                return {
                                    dicCode: info.dicCode
                                };
                            }
                        });
                        _grid.render();

                        $("#zet_dicContentGrid")
                            .off("click", '[role-action="zet_delete"]')
                            .on("click", '[role-action="zet_delete"]', function (e) {
                                var $target = $(e.currentTarget);
                                var appName = $target.attr("role-appName");
                                var dicCode = $target.attr("role-dic");

                                BH_UTILS.bhDialogWarning({
                                    title: "确认",
                                    content: "确定删除此字典值吗？",
                                    buttons: [
                                        {
                                            text: "确认",
                                            callback: function () {
                                                var typeValue = null;
                                                if (dicCode.indexOf("@") > -1) {
                                                    typeValue = dicCode.split("@")[1];
                                                    dicCode = dicCode.split("@")[0];
                                                }

                                                const param = {
                                                    appName: appName,
                                                    dicId: dicCode,
                                                    DM: $target.attr("role-dm"),
                                                    TYPE: typeValue
                                                };
                                                XGJSUTIL.postSyncCustom(WIS_CONFIG.ROOT_PATH + "/sys/jwcommon/olmodel/deleteDicData.do", param, function (dataSzfz) {
                                                    if (dataSzfz.code == "0") {
                                                        $(".zeromodal-close").trigger("click");
                                                        $.bhTip({
                                                            content: "操作成功",
                                                            state: "success"
                                                        });
                                                        self.shoDicDetail(e);
                                                    } else {
                                                        PUB_FUNC.cPopup({
                                                            title: dataSzfz.msg,
                                                            iconType: "warning"
                                                        });
                                                        return false;
                                                    }
                                                });
                                            }
                                        },
                                        {
                                            text: "取消",
                                            callback: function () {}
                                        }
                                    ]
                                });
                            });

                        $("#zet_dicContentGrid")
                            .off("click", '[role-action="zet_edit"]')
                            .on("click", '[role-action="zet_edit"]', function (e) {
                                self.editDicItem(e, info);
                            });

                        $('[role-action="zet_add"]')
                            .off("click")
                            .on("click", function (e) {
                                self.editDicItem(e, info);
                            });
                    }
                }
            });
        },
        editDicItem: function (e, info) {
            var self = this;
            const defaultValue = {};
            var text = "新增";
            var url = "saveAddDicData";
            if (e.currentTarget.getAttribute("role-dm")) {
                text = "编辑";
                defaultValue.value = e.currentTarget.getAttribute("role-dm");
                defaultValue.label = e.currentTarget.getAttribute("role-mc");
                defaultValue.order = e.currentTarget.getAttribute("role-px");
                url = "saveEditDicData";
            }
            var $dom = $.jwWinForm({
                tpl: '<div class="jwform-window-form" id = "dic-form"></div>',
                title: text,
                pagePath: context_path + "/sys/jwcommon/modules/public.do",
                action: "zdglbd",
                mode: "t",
                cols: 1,
                height: 350,
                width: 500,
                okText: "保存",
                defaultValue: defaultValue,
                callback: function (formValue) {
                    var $validate = $dom.jwForm("validate");
                    if (!$validate) {
                        return false;
                    }
                    var $target = $(e.currentTarget);
                    var dicCode = $target.attr("role-dic");
                    var typeValue = null;
                    if (dicCode.indexOf("@") > -1) {
                        typeValue = dicCode.split("@")[1];
                        dicCode = dicCode.split("@")[0];
                    }
                    var param = {
                        appName: info.appName,
                        dicId: dicCode,
                        DM: formValue.value,
                        TYPE: typeValue,
                        MC: formValue.label,
                        PX: formValue.order
                    };
                    XGJSUTIL.postSyncCustom(WIS_CONFIG.ROOT_PATH + "/sys/jwcommon/olmodel/" + url + ".do", param, function (dataSzfz) {
                        if (dataSzfz.code == "0") {
                            $(".zeromodal-close").trigger("click");
                            $.bhTip({
                                content: "操作成功",
                                state: "success"
                            });
                            self.shoDicDetail(e);
                            return true;
                        } else {
                            PUB_FUNC.cPopup({
                                title: dataSzfz.msg,
                                iconType: "warning"
                            });
                            return false;
                        }
                    });
                }
            });
            if (e.currentTarget.getAttribute("role-dm")) {
                $dom.jwForm("disableItem", ["value"]);
            }
        }
    });
    //金智报表
    GoldenFingerPlugins.register("jzReportGoldenFingerPlugin", {
        onClick: function (e) {
            window.open(WIS_CONFIG.PATH + "/sys/jzreport/config/index.do?appname=" + WIS_CONFIG.APPNAME);
        }
    });
    //录制日志
    GoldenFingerPlugins.register("logSpyGoldenFingerPlugin", {
        doInit: function (dom, item) {
            var self = this;
            dom.css({
                "background-color": "rgba(255, 77, 79, 1)",
                "border-color": "rgba(255, 77, 79, 1)",
                color: "white"
            });
            var startHtml = item.buttonHtml;
            var endHtml = item.buttonHtml.replace("icon-playcircleoutline", "icon-pause").replace(/录制日志/g, "结束录制");
            //有这个cookie代表已经开始记录日志了
            if ($.cookie("_ELR")) {
                dom.append(endHtml);
                dom.css({ "background-color": "rgba(127, 127, 127, 0.8)", "border-color": "rgba(127, 127, 127, 0.8)" });
                dom.attr("data-cur", "0");
            } else {
                dom.append(startHtml);
                dom.attr("data-cur", "1");
            }
        },
        onClick: function (e) {
            var self = this;
            var dom = $(e.currentTarget);
            var attr = dom.attr("data-cur");
            if (attr == "1") {
                this.startRecord().then(function (res) {
                    if (res.code == "0") {
                        self.switchEnd(dom);
                    }
                });
            } else {
                this.endRecord();
                self.switchStart(dom);
            }
        },
        switchStart: function (dom) {
            dom.find(".goldenfinger-icon").find(".iconfont").removeClass("icon-pause");
            dom.find(".goldenfinger-icon").find(".iconfont").addClass("icon-playcircleoutline");
            dom.css({ "background-color": "rgba(255, 77, 79, 1)", "border-color": "rgb(255,77,79)" });
            dom.attr("data-cur", "1");
            dom.find(".goldenfinger-btn span").text("录制日志");
        },
        switchEnd: function (dom) {
            dom.find(".goldenfinger-icon").find(".iconfont").removeClass("icon-playcircleoutline");
            dom.find(".goldenfinger-icon").find(".iconfont").addClass("icon-pause");
            dom.css({ "background-color": "rgba(127, 127, 127, 0.8)", "border-color": "rgba(127, 127, 127, 0.8)" });
            dom.attr("data-cur", "0");
            dom.find(".goldenfinger-btn span").text("结束录制");
        },
        //开始记录日志
        startRecord: function () {
            var self = this;
            var defer = $.Deferred();
            var url = WIS_CONFIG.PATH + "/sys/logview/log/setRecordingConfig.do";
            var u = userId;
            $.ajax({
                url: url,
                type: "post",
                dataType: "text",
                data: { config: "user:" + u },
                async: false,
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    if (XMLHttpRequest.status == 403) {
                        $.bhTip({
                            content: "需要先在应用【logview】用管理员设置允许该用户截取日志",
                            state: "danger"
                        });
                    }
                },
                success: function (data) {
                    $.post(WIS_CONFIG.PATH + "/sys/logview/record/start.do", null, function (res) {
                        defer.resolve(res);
                        if (res.code == "0") {
                            //设置日志记录的过期时间的cookie，防止nginx时间和客户端时间不一致，导致日志还未开始记录就结束了
                            if (!$.cookie("_ELR") && res.datas && res.datas.start) {
                                var ck = res.datas.start.replace("_ELR=", "");
                                var millisecond = new Date().getTime();
                                var expiresTime = new Date(millisecond + 60 * 1000 * 10);
                                $.cookie("_ELR", ck, { expires: expiresTime, path: WIS_CONFIG.PATH });
                            }
                            $.bhTip({
                                content: "开始记录日志...",
                                state: "success"
                            });
                        } else {
                            $.bhTip({
                                content: res.msg,
                                state: "danger"
                            });
                        }
                    });
                }
            });
            return defer;
        },
        //结束日志记录
        endRecord: function () {
            $.post(WIS_CONFIG.PATH + "/sys/logview/record/stop.do", null, function (res) {
                if (res.code == "0") {
                    if (res.datas.stop == "1") {
                        var url = WIS_CONFIG.PATH + "/sys/logview/record/download.do";
                        var exportForm = $(
                            '<form action="' +
                                url +
                                '" method="post">\
                    <input type="hidden" name="ids" value=""/>\
                    </form>'
                        );
                        $(document.body).append(exportForm);
                        exportForm.submit();
                        exportForm.remove();
                    } else {
                        $.bhTip({
                            content: "没有截取到可供下载的日志",
                            state: "danger"
                        });
                    }
                } else {
                    $.bhTip({
                        content: res.msg,
                        state: "danger"
                    });
                }
            });
        }
    });
    //日志sql构建
    GoldenFingerPlugins.register("logSqlBuilderGoldenFingerPlugin", {
        onClick: function () {
            this.initPage();
            this.bindEvent();
        },
        bindEvent: function () {
            $('[data-action="sql_一键转换"]').on("click", function () {
                if (!$(".tk1-form").emapValidate("validate")) {
                    return false;
                }
                var tk1 = $(".tk1-form").emapForm("getValue");
                var doc = parseXML(tk1.XML);
                var elList = $(doc).find("log[fileName='DbServiceImpl.java'],script,log[fileName='CustCommonDaoImpl.java']");
                var sqlList = [];
                $.each(elList, function (i, obj) {
                    var localName = obj.localName;
                    if (localName == "script") {
                        var sql = $(obj).text();
                        var nextNode = $(obj).next();
                        var pArr = $(nextNode).find("parameter");
                        $.each(pArr, function (i, pa) {
                            sql = sql.replace("?", "'" + $(pa).text() + "'");
                        });
                        sqlList.push(sql);
                    } else if (localName == "log") {
                        var msg = $(obj).attr("message");
                        if (msg.startsWith("[sql]")) {
                            var sql = msg.replace("[sql]", "");
                            var nextNode = $(obj).next();
                            var p = nextNode.attr("message").replace("[params]", "");
                            if (p) {
                                var arr = p.split(",");
                                $.each(arr, function (i, pa) {
                                    sql = sql.replace("?", "'" + pa + "'");
                                });
                            }
                            sqlList.push(sql);
                        }
                    }
                });
                var sql = "";
                $.each(sqlList, function (i, sql1) {
                    sql += i + 1 + "、" + sql1.trim() + ";\r\n";
                    sql += "\r\n";
                    //sql += sqlFormatter.format(sql1);
                });
                $(".tk2-form").emapForm("setValue", { XML: sql });
            });

            $('[data-action="sql_关闭"]').on("click", function () {
                $.bhPaperPileDialog.hide();
            });

            $('[data-action="sql_一键复制"]').on("click", function () {
                var tk2 = $(".tk2-form").emapForm("getValue");
                let textarea = document.createElement("textarea");
                textarea.value = tk2.XML;
                document.body.appendChild(textarea);
                textarea.select();
                var isCopy = document.execCommand("copy");
                document.body.removeChild(textarea);
                if (isCopy) {
                    $.bhTip({
                        content: "复制成功！",
                        state: "success"
                    });
                } else {
                    $.bhTip({
                        content: "复制失败！",
                        state: "danger"
                    });
                }
            });

            function parseXML(xmlStr) {
                var parseXML1 = "";

                if (typeof DOMParser == "function") {
                    parseXML1 = function (xmlStr) {
                        return new DOMParser().parseFromString(xmlStr, "text/xml");
                    };
                } else if (typeof window.ActiveXObject != "undefined" && new Window.ActiveXObject("Microsoft.XMLDOM")) {
                    parseXML1 = function (xmlStr) {
                        var xmlDOC = new Window.ActiveXObject("Microsoft.XMLDOM");
                        xmlDOC.async = "false";
                        xmlDOC.loadXML(xmlStr);
                        return xmlDOC;
                    };
                } else {
                    throw new Error("No XML parser found");
                }
                return parseXML1(xmlStr);
            }
        },
        initPage: function () {
            var html = "";
            html += '<article bh-layout-role="single">';
            html += '<h2 class="wuyuheng" style="height:0px"></h2>';
            html += '<div style="position:relative;"><img src="' + WIS_EMAP_SERV.getContextPath() + '/sys/jwcommon/public/images/sql.png"/>';
            html += '<div style= "display: inline-block;position: absolute;bottom: 0px;"><font style="font-size: 34px;font-weight: bolder;">生成器</font></div>';
            html += '<div style= "display: inline-block;position: absolute;bottom: 0px;width: 300px;right: 100px;"><font style="font-size: 12px; color: #ff0000;" class="shuoming"></font></div>';
            html += "</div>";
            html += "<section>";
            html += '<div class="tk1-form"></div>';
            html += '<footer style="padding-left: 16px;text-align:center;">';
            html += '<a href="javascript:void(0);" class="bh-btn bh-btn-primary waves-effect" data-action="sql_一键转换">一键转换</a> ';
            html += '<a href="javascript:void(0);" class="bh-btn bh-btn-primary waves-effect" data-action="sql_关闭">关闭</a> ';
            html += "</footer>";
            html += '<div class="tk2-form"></div>';
            html += '<footer style="padding-left: 16px;text-align:center;">';
            html += '<a href="javascript:void(0);" class="bh-btn bh-btn-primary waves-effect" data-action="sql_一键复制">复制</a> ';
            html += '<span style="position: absolute;right: 25%;cursor: pointer;" data-action="sql_一键复制"></span>';
            html += "</footer>";
            html += "</section>";
            html += "</article>";

            //弹出一个纸质弹框
            $.bhPaperPileDialog.show({
                content: html,
                render: function () {
                    //处理纸质弹框高度
                    $(".wuyuheng").next().css("margin-top", "20px");
                    $(".shuoming").html("说明：把下载下来的日志解压后，把其中的内容拷贝到sql生成器里面，然后点一键转换按钮，即可得到日志中截到的所有sql及对应的条件");
                    var datamodel = [];
                    datamodel.push({
                        caption: "",
                        dataType: "String",
                        xtype: "textarea",
                        name: "XML",
                        required: true
                    });
                    var datamodel1 = [];
                    datamodel1.push({
                        caption: "",
                        dataType: "String",
                        xtype: "textarea",
                        name: "XML",
                        required: false
                    });
                    WIS_EMAP_SERV.convertModel(datamodel, "form");
                    $(".tk1-form").emapForm({
                        data: datamodel,
                        model: "v",
                        readonly: false
                    });
                    $(".tk1-form").find("[name='XML']").parent().css({ "max-height": "350px", "overflow-y": "scroll" });
                    $(".tk1-form").find("[name='XML']").parent().niceScroll();
                    $(".tk2-form").emapForm({
                        data: datamodel1,
                        model: "v",
                        readonly: false
                    });
                },
                close: function () {}
            });
        }
    });
    // 应用异常查看
    GoldenFingerPlugins.register("appExceptionViewGoldenFingerPlugin", {
        onClick: function (e) {
            window.open(WIS_CONFIG.PATH + "/sys/jwcommon/console/index.do?searchAppName=" + WIS_CONFIG.APPNAME + "#/appexlog");
        }
    });
    // 控制台
    GoldenFingerPlugins.register("AAJwConsoleGoldenFingerPlugin", {
        onClick: function (e) {
            window.open(WIS_CONFIG.PATH + "/sys/jwcommon/console/index.do?searchAppName=" + WIS_CONFIG.APPNAME);
        }
    });
    //授权
    GoldenFingerPlugins.register("funcAuthGoldenFingerPlugin", {
        onClick: function (e) {
            window.open(WIS_CONFIG.PATH + "/sys/funauthapp/qxgl.do?appId=" + WIS_CONFIG.APPID + "&appName=" + WIS_CONFIG.APPNAME + "&needFlow=true");
        }
    });
    //授权
    GoldenFingerPlugins.register("openWindowConsoleGoldenFingerPlugin", {
        onClick: function (e) {
            window.open(window.location.href);
        }
    });
    //版本信息
    GoldenFingerPlugins.register("appVersionGoldenFingerPlugin", {
        /**
         * 触发点击事件
         * */
        successCallBack: function (res) {
            this.showVersionInfo(res);
        },
        /**
         * 显示查看字典弹窗
         */
        showVersionInfo: function (res) {
            var appInfo = res.datas.extInfo;
            BH_UTILS.bhWindow(
                "<div id='goldenfinger-appversion'></div>",
                "版本信息",
                [
                    {
                        text: "复制版本号",
                        className: "bh-btn-primary",
                        callback: function () {
                            var content = appInfo.APPNAME + ":" + appInfo.VERSION;
                            $.each(appInfo.dependences, function (index, item) {
                                content += "," + item.name + ":" + item.cversion;
                            });
                            var ele = document.createElement("input"); //创建一个input标签
                            ele.setAttribute("value", content); // 设置改input的value值
                            document.body.appendChild(ele); // 将input添加到body
                            ele.select(); // 获取input的文本内容
                            document.execCommand("copy"); // 执行copy指令
                            document.body.removeChild(ele); // 删除input标签
                            $.bhTip({
                                content: "版本信息已复制到剪切板！",
                                state: "success"
                            });
                            return false;
                        }
                    },
                    {
                        text: "关闭",
                        className: "bh-btn-default",
                        callback: function () {
                            //需要定义一个空函数，以关闭弹窗
                        }
                    }
                ],
                {
                    height: 400,
                    width: 700
                }
            );
            var appInfo = res.datas.extInfo;
            var html = "";
            html += '<table class="bh-table">';
            html += "	<tr>";
            html += '		<td class="bh-bg-info-4" style="width:15%">应用简称</td>';
            html += '		<td style="width:40%;">' + appInfo.APPNAME + "</td>";
            html += '		<td class="bh-bg-info-4" style="width:15%">版本号</td>';
            html += "		<td>" + appInfo.VERSION + "</td>";
            html += "	</tr>";
            html += "	<tr>";
            html += '		<td class="bh-bg-info-4" style="width:15%">是否存在定制</td>';
            html += '		<td style="width:40%;">' + (appInfo.customExist ? "是" : "否") + "</td>";
            html += '		<td class="bh-bg-info-4" style="width:15%">上次更新时间</td>';
            html += "		<td>" + appInfo.lastUpdateTime + "</td>";
            html += "	</tr>";
            html += "</table>";
            html += '<div style="padding-top: 10px;padding-bottom: 8px;font-size: 15px;font-weight: 600;">版本依赖信息</div>';

            html += '<table class="bh-table">';
            html += "	<tr>";
            html += '		<th class="bh-bg-info-4" style="width:40%">依赖应用</th>';
            html += '		<th class="bh-bg-info-4" style="width:30%">要求最低版本号</th>';
            html += '		<th class="bh-bg-info-4" style="width:30%">当前版本号</th>';
            html += "	</tr>";
            $.each(appInfo.dependences, function (index, item) {
                var versionSupport = versionValid(item.version, item.cversion);
                var fontColor = versionSupport ? "" : "color:red";
                html += "	<tr>";
                html += '		<td style="width:40%;">' + item.name + "</td>";
                html += '		<td style="width:30%;">' + item.version + "</td>";
                html += '		<td style="width:30%; ' + fontColor + '">' + item.cversion + "</td>";
                html += "	</tr>";
            });
            html += "</table>";
            $("#goldenfinger-appversion").append(html);

            function versionValid(limit, current) {
                if (limit == current) {
                    return true;
                }
                if (!limit || !current) {
                    return false;
                }
                limit = limit.replaceAll(/[a-zA-Z]/g, "").replaceAll(/[_]/g, ".");
                current = current.replaceAll(/[a-zA-Z]/g, "").replaceAll(/[_]/g, ".");

                currentArr = current.split(".");
                var valid = true;
                $.each(limit.split("."), function (index, item) {
                    if (Number(currentArr[index]) != Number(item)) {
                        if (Number(currentArr[index]) > Number(item)) {
                            valid = true;
                        } else {
                            valid = false;
                        }
                        return false;
                    }
                });
                return valid;
            }
        }
    });
    var isStyled = false;

    //页面配置
    GoldenFingerPlugins.register("pageConfigGoldenFingerPlugin", {
        /**
         * 触发点击事件
         * */
        onClick: function (e) {
            var self = this;
            /** ******页面内事件通过eventMap统一管理******* */
            this.eventMap = {
                ".ic-zd-xsyc": this.qhzdYc, //切换字段显示
                ".ic-zd-xsyc-active": this.qhzdXs, //字段切换隐藏
                ".ic-zd-delete": this.zdDelete,
                ".yypz-ympz-right-zd-add": this.addZd,
                ".yypz-ympz-right-zd-add-custom": this.addZdCustom,
                ".ic-zd-edit": this.editZd,

                ".ympz-right-enlarge": this.enlargeWindow,
                ".ympz-right-narrow": this.narrowWindow,
                '[data-action="页面配置分组隐藏"]': this.groupHide,
                '[data-action="页面配置分组展开"]': this.groupShow
            };

            // 如果打开了上传附件  就关闭
            if (uploadFingerFlag) {
                GoldenFingerPlugins.get("appOperatingManualUploadFingerPlugin").onClick();
            }
            require([jsPathToGoldenFinger + "olModelNew.js", jsPathToGoldenFinger + "olModelUtil.js", "utils", jsPathToGoldenFinger + "editZd.js", jsPathToGoldenFinger + "zdxzzdy.js"], function (
                olM,
                olMUtil,
                ut,
                edzd,
                addzdyzd
            ) {
                olModel = olM;
                olModelUtil = olMUtil;
                utils = ut;
                zdbj = edzd;
                zdxzzdy = addzdyzd;
                zdxzzdy.initialize();
                zdbj.initialize();
                self.bindingEvent();
                self.editPage();
            });
        },
        bindingEvent: function () {
            var self = this;
            for (let selector in this.eventMap) {
                $(document.body).off("click", selector).on("click", selector, self.eventMap[selector].bind(self));
            }
        },
        //页面修改
        editPage: function () {
            var self = this;
            var targets = $("body").contents().find('*[emap]:visible,[emap-role="FQ-filters"],[emap-role="datatable"],[emap-role="button"],.bh-pager');
            // var targets = $("body").contents().find('[emap-role="FQ-filters"]:visible,[emap-role="datatable"]:visible,[emap-role="button"]:visible,[emap-role="form"]:visible');
            targets = targets.filter(function () {
                var $this = $(this);
                var emapValue = $this.attr("emap");
                if (!emapValue || emapValue.trim() === "") {
                    return false;
                }
                var parsedEmap = JSON.parse(emapValue);
                // 检查解析后的对象是否为空对象 {}
                return Object.keys(parsedEmap).length > 0; // 如果不是空对象，则返回 true 以包含该元素
            });
            if (isStyled) {
                this.revover(targets);
                isStyled = false;
                return false;
            }
            if (targets.length <= 0) {
                PUB_FUNC.cPopup({
                    title: "此页面不存在可编辑区域!",
                    iconType: "warning"
                });
                return false;
            }
            //emap元素蒙尘
            targets.css("border", "2px dashed #2f8cf0");
            targets.css("background-color", "#f1f6fe");
            targets.css("cursor", "pointer");
            setTimeout(function () {
                targets.find("*").css("pointer-events", "none");
            }, 0);
            targets.attr("is-edit", "1");
            //绑定事件
            $("body").off("click", '*[emap]:visible,[emap-role="FQ-filters"],[emap-role="datatable"],[emap-role="button"],[emap-role="pager"],.bh-pager');
            $("body").on("click", '*[emap]:visible,[emap-role="FQ-filters"],[emap-role="datatable"],[emap-role="button"],[emap-role="pager"],.bh-pager', function (e) {
                var edirEnable = $(this).attr("is-edit");
                if (isStyled && edirEnable === "1") {
                    var type = $(this).attr("emap-role") || $(this).children().attr("emap-role");

                    // 判断type是不是表格
                    if (type === "datatable") {
                        // 判断表格是否有分页功能
                        var $pager = $(this).find(".jqx-grid-pager .bh-pager");
                        if ($pager && $pager.length) {
                            // 判断点击的坐标是否处于分页功能区域 36为分页功能的高度
                            var containerHeight = $(this).height();
                            var clickY = e.offsetY;
                            if (containerHeight - clickY < 36 && containerHeight - clickY > 0) {
                                type = "pager";
                            }
                        }
                    }
                    self.showAdvanceZd(this, type);
                }
            });

            isStyled = true;
        },
        //恢复
        revover: function (targets) {
            targets.css("border", "");
            targets.css("background-color", "");
            targets.find("*").css("pointer-events", "auto");
            targets.attr("is-edit", "0");
            // targets.off("click").on("click", function () {});
        },
        //展示EMAP元素的Form
        showAdvanceZd: function (target, type) {
            var emap = $(target).attr("emap") || $(target).closest("[emap]").attr("emap");
            var obj = JSON.parse(emap);

            if (!type) {
                $.bhTip({ content: "查找不到类型", state: "danger" });
                return;
            }
            if (!emap) {
                $.bhTip({ content: "查找不到模型", state: "danger" });
                return;
            }
            switch (type) {
                case "advancedQuery":
                    obj.type = "1";
                    obj.title = "高级搜索调整";
                    this.openForm(obj);
                    break;
                case "FQ-filters":
                    obj.type = "1";
                    obj.title = "高级搜索调整";
                    this.openForm(obj);
                    break;
                case "datatable":
                    obj.type = "2";
                    obj.title = "表格字段调整";
                    this.openForm(obj);
                    break;
                case "form":
                    obj.type = "3";
                    obj.title = "表单字段调整";
                    this.openForm(obj);
                    break;
                case "button":
                    this.openButtonForm(target);
                    break;
                case "pager":
                    if ($(target).find(".bh-pager").length) {
                        this.openPager($(target).find(".bh-pager"));
                    } else {
                        this.openPager(target);
                    }

                    break;
                default:
                    break;
            }
        },
        openPager: function (target) {
            function getMaxZIndex() {
                var maxZ = Math.max.apply(
                    null,
                    $.map($("body *"), function (e, n) {
                        if ($(e).css("position") !== "static") {
                            return parseInt($(e).css("z-index")) || 0;
                        }
                    })
                );
                return maxZ >= 0 ? maxZ : 0; // 处理无有效值的情况
            }

            var pagesizeOptions = $(target).data("emap-pager") || ["10", "20", "50", "100"];

            var emapSetting = $(target).attr("emap");
            if (!emapSetting) {
                $.bhTip({ content: "页码暂不支持配置", state: "danger" });
                return;
            }

            emapSetting = JSON.parse(emapSetting);

            if ($.type(emapSetting) !== "object" || !emapSetting.action || !emapSetting.pagePath || !emapSetting.page) {
                $.bhTip({ content: "页码暂不支持配置", state: "danger" });
                return;
            }
            utils.window({
                title: "页码调整",
                content: '<span>最多可配置4个页码<span/><div id="yypz-ympz-right-pager-dialog"></div>',
                height: "340px",
                width: "330px",
                showButtons: true,
                buttons: [
                    {
                        text: "取消",
                        className: "bh-btn-default",
                        callback: function () {}
                    },
                    {
                        text: "保存",
                        className: "bh-btn-primary",
                        callback: function () {
                            var pageSizes = vm.pageSizeList.map(function (size) {
                                return Math.round(Number(size));
                            });
                            var repeat = [];
                            for (var i = 0; i < pageSizes.length; i++) {
                                if (!pageSizes[i]) {
                                    $.bhTip({ content: "请维护页码！", state: "warning" });
                                    return false;
                                }

                                if (repeat.indexOf(pageSizes[i]) !== -1) {
                                    $.bhTip({ content: "页码重复！", state: "warning" });
                                    return false;
                                }
                                repeat.push(pageSizes[i]);
                            }
                            $.jwAjax({
                                url: "/sys/jwcommon/tableconfig/saveTableConfig.do",
                                data: {
                                    PAGE: emapSetting.page,
                                    ACTION: emapSetting.action,
                                    MYSL: pageSizes.join(",")
                                },
                                successMsg: "",
                                success: function () {
                                    PUB_FUNC.confirmDialog("保存成功，是否需要刷新当前页面,如若需刷新页面,请耐心等待？", function () {
                                        location.reload(true);
                                    });
                                    var zIndex = getMaxZIndex();
                                    $(".bh-modal").css("z-index", zIndex);
                                }
                            });
                        }
                    }
                ]
            });
            A.loadElementUI(function (e) {
                require(["text!../../jwcommon/public/script/goldenfinger/ympz/html/pager.vue"], function (tpl) {
                    $("#yypz-ympz-right-pager-dialog").html(tpl);

                    vm = new Vue({
                        el: "#yypz-ympz-right-pager-dialog",
                        data: function () {
                            var pageSizeList = [];
                            pagesizeOptions.forEach(function (num) {
                                pageSizeList.push(Number(num));
                            });
                            return {
                                pageSizeList: pageSizeList
                            };
                        },
                        mounted: function () {},
                        methods: {
                            onAddPageSize: function () {
                                if (this.pageSizeList.length >= 4) {
                                    return;
                                }
                                this.pageSizeList.push(undefined);
                            },
                            onpageSizeChange: function (index, value) {
                                this.$set(this.pageSizeList, index, value);
                            },
                            onDeletePageSize: function (index) {
                                if (this.pageSizeList.length <= 1) {
                                    return;
                                }
                                this.pageSizeList.splice(index, 1);
                            }
                        }
                    });
                });
            });
        },
        openButtonForm: function (target) {
            var self = this;
            var buttons = $(target).data("emap-button");
            if (!buttons) {
                PUB_FUNC.cPopup({
                    title: "对不起，该按钮不支持调整！",
                    iconType: "warning"
                });
                return;
            }

            var emapSetting = $(target).attr("emap");
            if (!emapSetting) {
                console.error("调整按钮无emapSetting");
            }
            emapSetting = JSON.parse(emapSetting);

            if ($.type(emapSetting) !== "object" || !emapSetting.action || !emapSetting.pagePath || !emapSetting.page) {
                console.error("调整按钮无action|pagePath|page");
            }
            var emapParams = $(target).attr("emap-params");

            if (emapParams) {
                emapParams = JSON.parse(emapParams);
            } else {
                emapParams = {};
            }

            var vm = null;
            $.when(
                self.getSQLTest(
                    Object.assign(
                        {},
                        {
                            PAGE: emapSetting.page,
                            ACTION: emapSetting.action,
                            pagePath: emapSetting.pagePath
                        },
                        emapParams
                    )
                ),
                self.getUserGroup({ appId: WIS_CONFIG.APPID })
            ).done(function (sqlResult, userGroups) {
                utils.window({
                    title: "按钮调整",
                    content: '<div id="yypz-ympz-right-buttonPage"></div>',
                    height: "612px",
                    width: "846px",
                    showButtons: true,
                    buttons: [
                        {
                            text: "取消",
                            className: "bh-btn-default",
                            callback: function () {}
                        },
                        {
                            text: "确定保存",
                            className: "bh-btn-primary",
                            callback: function () {
                                var finalyButtons = vm.buttons;
                                var params = [];
                                finalyButtons.forEach(function (item) {
                                    var obj = {};
                                    var keys = Object.keys(item);
                                    keys.forEach(function (k) {
                                        if (_.includes(k, "ext.")) {
                                            obj[k] = item[k];
                                        }
                                    });
                                    params.push(obj);
                                });

                                $.jwAjax({
                                    url: "/sys/jwcommon/tableconfig/saveTableConfig.do",
                                    data: {
                                        PAGE: emapSetting.page,
                                        ACTION: emapSetting.action,
                                        PZNR: params.length ? JSON.stringify(params) : ""
                                    },
                                    successMsg: "",
                                    success: function () {
                                        PUB_FUNC.confirmDialog("保存成功，是否需要刷新当前页面,如若需刷新页面,请耐心等待？", function () {
                                            location.reload(true);
                                        });
                                    }
                                });
                            }
                        }
                    ]
                });

                A.loadElementUI(function (e) {
                    require(["text!../../jwcommon/public/script/goldenfinger/ympz/html/buttonCard.vue"], function (tpl) {
                        $("#yypz-ympz-right-buttonPage").html(tpl);

                        vm = new Vue({
                            el: "#yypz-ympz-right-buttonPage",
                            data: function () {
                                var batchButtons = buttons.filter(function (btn) {
                                    return btn.canBatch;
                                });
                                var singleButtons = buttons.filter(function (btn) {
                                    return btn.canSingle;
                                });
                                return {
                                    buttons: buttons,
                                    batchButtons: batchButtons,
                                    singleButtons: singleButtons
                                };
                            },
                            mounted: function () {},
                            methods: {
                                onSetVisible: function (btn, index, type) {
                                    if (!btn["ext.visible"] || btn["ext.visible"] === "0") {
                                        btn["ext.visible"] = "1";
                                    } else {
                                        btn["ext.visible"] = "0";
                                    }
                                },
                                onSetSetinng: function (btn) {
                                    self.openAdjustDialog.call(this, self, btn, sqlResult, userGroups, emapSetting);
                                },
                                onDeleteButton: function (btn, index) {
                                    var that = this;
                                    BH_UTILS.bhDialogWarning({
                                        title: "提示",
                                        content: "是否确定删除",
                                        buttons: [
                                            {
                                                text: "确定",
                                                callback: function () {
                                                    that.buttons.splice(index, 1);
                                                }
                                            },
                                            {
                                                text: "取消"
                                            }
                                        ]
                                    });
                                    $(".bh-modal").css("z-index", "101000");
                                },
                                onAddButton: function () {
                                    self.addButton.call(this, self, sqlResult, userGroups, emapSetting);
                                }
                            }
                        });
                    });
                });
            });
        },
        getSQLTest: function (params) {
            var match = window.location.href.match(/\/sys\/([^\/?]+)/);
            var appName = "";
            // 检查是否成功匹配
            if (match) {
                appName = match[1];
            }
            var pagePath = params.pagePath;
            if (pagePath && pagePath[0] === "/") {
                pagePath = pagePath.substr(1);
            }
            var module = pagePath.split("/").shift();

            var pageName = pagePath.split("/").pop();
            if (/\.do$/.test(pageName)) {
                pageName = pageName.substring(0, pageName.length - 3);
            }

            params = Object.assign({}, params, {
                app: appName,
                module: module,
                page: pageName,
                action: params.ACTION
            });
            var deferred = $.Deferred();
            $.post(WIS_CONFIG.PATH + "/sys/jwcommon/tableconfig/queryActionSql.do", params, function (res) {
                if (res.code === "0") {
                    deferred.resolve(res.datas);
                }
            });
            return deferred.promise();
        },
        getUserGroup: function (params) {
            var deferred = $.Deferred();
            $.post(WIS_CONFIG.PATH + "/sys/funauthapp/queryGroupAndJs.do", params, function (res) {
                if (res.code === "1") {
                    deferred.resolve(res.datas);
                } else {
                    deferred.reject();
                }
            });
            return deferred.promise();
        },
        buttonAfterFormInit: function ($dom, defaultValue, userGroups, table) {
            $dom.find('div[data-name="FS"]').on("change", function (event) {
                var formValue = $dom.jwForm("getValue");
                if (formValue.FS === "01") {
                    $dom.jwForm("showItem", ["BBDZ", "SQL", "DQBGCSYLB"]);
                    $dom.jwForm("hideItem", ["DZ"]);

                    $("#report-tip").show();
                    $("#url-tip").hide();
                } else {
                    $dom.jwForm("hideItem", ["BBDZ", "SQL", "DQBGCSYLB"]);
                    $dom.jwForm("showItem", ["DZ"]);

                    $("#report-tip").hide();
                    $("#url-tip").show();
                }
            });
            //
            var $DZ = $dom.find('[data-field="DZ"]');
            $DZ.before(
                '<div id="url-tip" class="bh-color-danger bh-mh-16">(内部链接输入：应用名称app/页面名称，例如ttbkapp/ttbksq；外部链接输入：https://www.XX.com，例如https://www.baidu.com)</div>'
            );

            var $BBDZ = $dom.find('[data-field="BBDZ"]');

            $BBDZ.before('<div id="report-tip" class="bh-color-danger bh-mh-16">若是服务器已存在报表，请直接输入目录名，如：kwglapp/ksmd_add.cpt，如果是新开发的报表，请点击按钮上传报表文件。</div>');

            $BBDZ.css("display", "flex");

            $BBDZ
                .find(".bh-form-placeholder")
                .before('<a href="javascript:void(0)" class="bh-btn bh-btn-primary" data-action="选择文件">选择文件</a><input type="file" name="uploadFile" id="chooseFile" style="display:none">');

            $dom.on("click", '[data-action="选择文件"]', function () {
                $dom.find("#chooseFile").trigger("click");
                $dom.find("#chooseFile").bind("change", function (event) {
                    var file = event.target.files[0]; // 获取文件对象
                    if (file) {
                        var formData = new FormData(); // 创建一个 FormData 对象
                        formData.append("uploadFile", file); // 将文件添加到 FormData 对象中

                        $.ajax({
                            url: WIS_EMAP_SERV.getContextPath() + "/sys/jwcommon/tableconfig/uploadReport.do",
                            type: "POST",
                            data: formData,
                            async: false,
                            cache: false,
                            contentType: false,
                            processData: false,
                            success: function (result) {
                                if (result.code === "0") {
                                    $dom.jwForm("setValue", { BBDZ: result.datas });
                                }
                            },
                            error: function (result) {
                                $.bhTip({ state: "danger", content: "上传出错！" });
                                return false;
                            }
                        });
                    }
                });
            });

            if (userGroups && userGroups.length) {
                var $YHZ = $dom.find('[data-name="YHZ"]');
                $YHZ.off("open");
                $YHZ.jqxDropDownList("clear");

                $YHZ.jqxDropDownList({
                    source: userGroups,
                    filterable: true,
                    placeHolder: "请选择...",
                    filterPlaceHolder: "请查找",
                    searchMode: "containsignorecase"
                });

                if (defaultValue && defaultValue.YHZ) {
                    var arr = defaultValue.YHZ.split(",");
                    arr.forEach(function (item) {
                        $YHZ.jqxDropDownList("checkItem", item);
                    });
                }
            }

            var $SQL = $dom.find('[data-field="SQL"]');
            $SQL.find(".bh-form-group").removeClass(" bh-col-md-6");
            $SQL.find(".bh-form-group").addClass(" bh-col-md-12");

            var $DQBGCSYLB = $dom.find('[data-field="DQBGCSYLB"]');
            var bbtable = ToolManager.loadCompiledPage("ympz/html/bbtable");
            if (table && table.length) {
                $DQBGCSYLB.find('[data-name="DQBGCSYLB"]').html(bbtable.render({ datas: table }));
            }
            $DQBGCSYLB.find(".bh-form-group").removeClass(" bh-col-md-6");
            $DQBGCSYLB.find(".bh-form-group").addClass(" bh-col-md-12");
        },
        addButton: function (self, sqlResult, userGroups, emapSetting) {
            var that = this;

            var defaultValue = {
                MC: "",
                SFYC: "0",
                ZT: "bh-btn-default",
                FS: "01",
                DZ: "",
                BBDZ: "",
                SQL: sqlResult.sql,
                CZMS: "01,02"
            };

            if (emapSetting.pagePath === "undefined") {
                defaultValue.CZMS = "01";
            }
            var $win = $.jwWinForm({
                pagePath: context_path + "/sys/jwcommon/public*script*goldenfinger/ympz.do",
                action: "anbjbddz",
                forceInit: true,
                title: "新增",
                height: "800px",
                width: "1000px",
                okText: "保存",
                model: "h",
                defaultValue: defaultValue,
                afterFormInit: function ($dom) {
                    self.buttonAfterFormInit($dom, {}, userGroups, sqlResult.params);
                },
                callback: function (formValue) {
                    var btn = {
                        "ext.id": formValue.MC + "::",
                        "ext.className": formValue.ZT,
                        "ext.mode": formValue.FS,
                        "ext.name": formValue.MC,
                        "ext.type": "2",
                        "ext.url": formValue.DZ,
                        "ext.fineReportUrl": formValue.BBDZ,
                        "ext.userGroup": formValue.YHZ,
                        "ext.visible": formValue.SFYC === 0 ? "1" : "0",
                        "ext.operationMode": formValue.CZMS,
                        text: formValue.MC
                    };
                    var operationMode = formValue.CZMS.split(",");

                    if (_.includes(operationMode, "01")) {
                        btn["ext.id"] += "batch";
                    }

                    if (_.includes(operationMode, "02")) {
                        btn["ext.id"] += "single";
                    }
                    that.buttons.push(btn);
                }
            });
            $win.parent(".content").css({ height: "100%", overflow: "hidden auto" });
            $win.jwForm("showItem", ["BBDZ", "SQL", "DQBGCSYLB"]);
            $win.jwForm("hideItem", ["DZ"]);
            if (emapSetting.pagePath === "undefined") {
                $win.jwForm("disableItem", ["CZMS"]);
            }

            $("#url-tip").hide();
        },
        openAdjustDialog: function (self, btn, sqlResult, userGroups, emapSetting) {
            var extType = btn["ext.type"] || "1";
            var that = this;

            var okfunc = function () {
                if (!$("#yypz-ympz-right-editButton-dialog").jwForm("validate")) {
                    return false;
                }
                var formValue = $("#yypz-ympz-right-editButton-dialog").jwForm("getValue");
                var newBtn = Object.assign({}, btn, {
                    "ext.name": formValue.MC,
                    text: formValue.MC,
                    "ext.visible": formValue.SFYC === 1 ? "0" : "1",
                    "ext.className": formValue.ZT,
                    className: formValue.ZT,
                    "ext.mode": formValue.FS,
                    "ext.url": formValue.DZ,
                    "ext.fineReportUrl": formValue.BBDZ,
                    "ext.userGroup": formValue.YHZ,
                    "ext.operationMode": formValue.CZMS
                });

                var findIndex = that.buttons.findIndex(function (item) {
                    return item["ext.id"] === newBtn["ext.id"];
                });
                that.$set(that.buttons, findIndex, newBtn);
            };

            var $WIN = utils.window({
                title: btn.text,
                content: '<div id="yypz-ympz-right-editButton-dialog"></div>',
                height: "800px",
                width: "1000px",
                showButtons: true,
                buttons:
                    extType === "1"
                        ? [
                              {
                                  text: "取消",
                                  className: "bh-btn-default",
                                  callback: function () {}
                              },

                              {
                                  text: "重置",
                                  className: "bh-btn-default",
                                  callback: function () {
                                      $("#yypz-ympz-right-editButton-dialog").jwForm("setValue", {
                                          MC: btn["origin.name"] || btn.text,
                                          SFYC: "0",
                                          ZT: btn["origin.className"] || btn.className
                                      });
                                      return false;
                                  }
                              },
                              {
                                  text: "保存",
                                  className: "bh-btn-primary",
                                  callback: okfunc
                              }
                          ]
                        : [
                              {
                                  text: "取消",
                                  className: "bh-btn-default",
                                  callback: function () {}
                              },
                              {
                                  text: "保存",
                                  className: "bh-btn-primary",
                                  callback: okfunc
                              }
                          ]
            });
            $WIN.find(".jqx-window-content .content").css({ height: "100%", overflow: "hidden auto" });

            var defaultValue = {
                MC: btn.text,
                SFYC: !btn["ext.visible"] || btn["ext.visible"] === "1" ? "0" : "1",
                ZT: btn.className,
                FS: btn["ext.mode"],
                BBDZ: btn["ext.fineReportUrl"],
                CZMS: btn["ext.operationMode"],
                DZ: btn["ext.url"],
                SQL: sqlResult.sql
                // YHZ: btn["ext.userGroup"]
            };
            $("#yypz-ympz-right-editButton-dialog").jwForm({
                pagePath: context_path + "/sys/jwcommon/public*script*goldenfinger/ympz.do",
                action: "anbjbddz",
                model: "h",
                defaultValue: defaultValue,
                afterFormInit: function ($dom) {
                    self.buttonAfterFormInit($dom, Object.assign({}, defaultValue, { YHZ: btn["ext.userGroup"] }), userGroups, sqlResult.params);
                }
            });
            if (defaultValue.FS === "01") {
                $("#yypz-ympz-right-editButton-dialog").jwForm("showItem", ["BBDZ", "SQL", "DQBGCSYLB"]);
                $("#yypz-ympz-right-editButton-dialog").jwForm("hideItem", ["DZ"]);
                $("#report-tip").show();
                $("#url-tip").hide();
            } else {
                $("#yypz-ympz-right-editButton-dialog").jwForm("hideItem", ["BBDZ", "SQL", "DQBGCSYLB"]);
                $("#yypz-ympz-right-editButton-dialog").jwForm("showItem", ["DZ"]);
                $("#report-tip").hide();
                $("#url-tip").show();
            }

            if (extType === "1") {
                $("#report-tip").hide();
                $("#url-tip").hide();
                $("#yypz-ympz-right-editButton-dialog").jwForm("hideItem", ["FS", "DZ", "YHZ", "CZMS", "BBDZ", "SQL", "DQBGCSYLB"]);
            }

            if (emapSetting.pagePath === "undefined") {
                $("#yypz-ympz-right-editButton-dialog").jwForm("disableItem", ["CZMS"]);
            }
        },
        /** *********************展示模型字段，并处理*********************** **/
        openForm: function (obj) {
            var bhstyle = document.createElement("style");
            bhstyle.innerHTML = ".bh-tip { z-index: 1000003; }";
            this.modelZdList = [];
            var self = this;
            var title = obj.title;
            olModel.initialize(obj["emap-app-name"]);
            self.selectFormType = obj.type;
            self.customModelZdList = [];
            self.selectAppName = obj["emap-app-name"];
            var modelName = obj["emap-model-name"];
            if (!modelName) {
                PUB_FUNC.cPopup({
                    title: "对不起，该组件缺少【emap-model-name】属性，暂不支持调整！",
                    iconType: "warning"
                });
                return;
            }
            if (modelName.endsWith(".searchModel") || modelName.endsWith(".displayModel")) {
                PUB_FUNC.cPopup({
                    title: "对不起，该模型暂不支持调整！",
                    iconType: "warning"
                });
                return;
            }
            if (modelName.endsWith(".custom")) {
                modelName = modelName.split(".")[0];
            }
            if (bhstyle && !document.head.contains(bhstyle)) {
                document.head.appendChild(bhstyle);
            }
            //点击确定后操作
            var okAction = function () {
                self.actionGoToSave(obj);
                if (bhstyle && document.head.contains(bhstyle)) {
                    document.head.removeChild(bhstyle);
                    bhstyle = null;
                }
            };
            var $win = utils.window({
                title: title,
                content: '<div id="yypz-ympz-right-zdpage"></div>',
                height: "612px",
                width: "846px",
                showButtons: true,
                buttons: [
                    {
                        text: "取消",
                        className: "bh-btn-default",
                        callback: function () {
                            if (bhstyle && document.head.contains(bhstyle)) {
                                document.head.removeChild(bhstyle);
                                bhstyle = null;
                            }
                        }
                    },
                    {
                        text: "确定保存",
                        className: "bh-btn-primary",
                        callback: okAction
                    }
                ]
            });
            $win.find(".jqx-window-content .content").css({ height: "100%", overflow: "hidden auto" });
            //查询路径数据
            var param = { appName: obj["emap-app-name"], modelName: modelName };

            XGJSUTIL.postSyncCustom(WIS_CONFIG.ROOT_PATH + "/sys/jwcommon/olmodel/searchAppModel.do", param, function (dataSzfz) {
                if (dataSzfz.code == "0") {
                    var path = dataSzfz.data.PATH;
                    obj.PATH = path;
                    //读取模型
                    dataModelFieldList = {};
                    var model = olModel.getModel(path);
                    var readModel = olModel.readModel(model);

                    //重名字段增添colName以作区分
                    let sameNames = {};
                    readModel.edm.forEach(function (obj, index) {
                        let caption = obj.caption;
                        //caption为null或者空字符串时显示name属性
                        if (caption && caption !== "") {
                            obj.caption_display = caption;
                        } else {
                            obj.caption_display = obj.name;
                        }
                        if (obj.caption_display && sameNames[obj.caption_display]) {
                            let firstIndex = sameNames[obj.caption_display];
                            obj.caption_display += "(" + `${obj.colName ? obj.colName : obj.name}` + ")";
                            if (!readModel.edm[firstIndex].caption_display.includes("(")) {
                                readModel.edm[firstIndex].caption_display += "(" + `${readModel.edm[firstIndex].colName ? readModel.edm[firstIndex].colName : readModel.edm[firstIndex].name}` + ")";
                            }
                        } else {
                            sameNames[obj.caption_display] = index;
                        }
                    });

                    var fileType = path.substr(path.lastIndexOf(".") + 1);
                    //获取字段显示还是隐藏的构造
                    var zd = olModelUtil.buildModelZd(readModel.edm, obj.type, model, fileType);
                    //重新构造字段列表
                    self.addFieldList = olModelUtil.buildDataModelFieldList(zd);
                    //groupName
                    self.groupNameList = olModelUtil.getGroupNameList(zd);
                    //赋值为全局变量
                    self.modelZdList = zd;
                    //渲染卡片
                    var card = ToolManager.loadCompiledPage("ympz/html/zdtzCard");
                    $("#yypz-ympz-right-zdpage").html(
                        card.render({
                            isSs: obj.type == "1" ? true : false,
                            isTable: obj.type == "2" ? true : false,
                            isForm: obj.type == "3" ? true : false,
                            zd: zd,
                            zdCount: zd.length
                        }),
                        true
                    );
                    //绑定事件
                    self.bindZdPageEvent();
                } else {
                    PUB_FUNC.cPopup({
                        title: dataSzfz.msg,
                        iconType: "warning"
                    });
                    return false;
                }
            });
        },
        //字段切换隐藏
        qhzdYc: function (event) {
            //页面操作
            var target = $(event.currentTarget);
            var maiTarget = target.closest(".yypz-ympz-right-zd-nr");
            var textTarget = target.closest(".yypz-ympz-right-zd-nr").children(".yypz-ympz-right-zd-nr-text");
            target.addClass("ic-zd-xsyc-active");
            target.removeClass("ic-zd-xsyc");
            textTarget.addClass("yypz-ympz-right-zd-nr-text-h");
            textTarget.removeClass("yypz-ympz-right-zd-nr-text");
            //字段切换
            var index = maiTarget.attr("data-index");
            var customIndex = maiTarget.attr("data-custom-index");
            if (index) {
                this.modelZdList = olModelUtil.ZdxsycZdChange(this.modelZdList, this.selectFormType, index, "true");
            } else if (customIndex) {
                olModelUtil.ZdxsycZdChange(this.customModelZdList, this.selectFormType, customIndex, "true");
            } else {
                var i = maiTarget.attr("data-mindex");
                var j = maiTarget.attr("data-findex");
                olModelUtil.ZdxsycZdChange(this.addFieldList[i].fieldList, this.selectFormType, j, "true");
            }
            $.bhTip({
                content: "字段隐藏成功！",
                state: "success"
            });
        },
        //字段切换显示
        qhzdXs: function (event) {
            //页面操作
            var target = $(event.currentTarget);
            var maiTarget = target.closest(".yypz-ympz-right-zd-nr");
            var textTarget = target.closest(".yypz-ympz-right-zd-nr").children(".yypz-ympz-right-zd-nr-text-h");
            target.removeClass("ic-zd-xsyc-active");
            target.addClass("ic-zd-xsyc");
            textTarget.addClass("yypz-ympz-right-zd-nr-text");
            textTarget.removeClass("yypz-ympz-right-zd-nr-text-h");

            var index = maiTarget.attr("data-index");
            var customIndex = maiTarget.attr("data-custom-index");
            //字段切换
            if (index) {
                this.modelZdList = olModelUtil.ZdxsycZdChange(this.modelZdList, this.selectFormType, index, "false");
            } else if (customIndex) {
                olModelUtil.ZdxsycZdChange(this.customModelZdList, this.selectFormType, customIndex, "false");
            } else {
                var i = maiTarget.attr("data-mindex");
                var j = maiTarget.attr("data-findex");
                olModelUtil.ZdxsycZdChange(this.addFieldList[i].fieldList, this.selectFormType, j, "false");
            }
            $.bhTip({
                content: "字段显示成功！",
                state: "success"
            });
        },
        //删除字段
        zdDelete: function (event) {
            //页面操作
            var target = $(event.currentTarget).closest(".yypz-ympz-right-zd-nr");
            target.remove();
            //字段加值
            var index = target.attr("data-index");
            var customIndex = target.attr("data-custom-index");
            if (index) {
                this.modelZdList = olModelUtil.zdscChange(this.modelZdList, index);
            } else if (customIndex) {
                this.customModelZdList = olModelUtil.zdscChange(this.customModelZdList, customIndex);
            } else {
                //index为空 说明为新增加 尚未保存到文件的字段
                //将其删除
                var i = target.attr("data-mindex");
                var j = target.attr("data-findex");
                this.addFieldList[i].fieldList[j].isCheck = "";
                this.addFieldList[i].fieldList[j].isNewAddTag = false;
            }
        },
        //绑定事件
        bindZdPageEvent: function () {
            //字段前面拖动排序的tips
            $(".yypz-ympz-right-nr-icon")
                .off("mousemove")
                .on("mousemove", function (event) {
                    $(event.currentTarget).closest(".yypz-ympz-right-zd-nr").children(".yypz-ympz-right-zd-tips").show();
                    $(event.currentTarget).closest(".yypz-ympz-right-sstj-nr").children(".yypz-ympz-right-zd-tips").show();
                });
            $(".yypz-ympz-right-nr-icon")
                .off("mouseout")
                .on("mouseout", function (event) {
                    $(event.currentTarget).closest(".yypz-ympz-right-zd-nr").children(".yypz-ympz-right-zd-tips").hide();
                    $(event.currentTarget).closest(".yypz-ympz-right-sstj-nr").children(".yypz-ympz-right-zd-tips").hide();
                });
            //拖动排序事件
            this.initFakpSort(".yypz-ympz-right-zd-page .bh-row", ".yypz-ympz-right-nr-icon");
        },
        //字段和搜索条件排序
        initFakpSort: function (container, move) {
            var self = this;
            var $rows = $(container);
            $rows.sortable({
                update: function (event, ui) {
                    //更新排序后的操作，
                    //无操作 最后拿一下最新的顺序
                },
                handle: move
            });
        },
        actionGoToSave: function (obj) {
            var self = this;
            //生成扩展模型
            var param = { appName: obj["emap-app-name"], modelPath: obj["PATH"] };
            //添加新的字段

            XGJSUTIL.postSyncCustom(WIS_CONFIG.ROOT_PATH + "/sys/jwcommon/olmodel/extendModel.do", param, function (dataSzfz) {
                if (dataSzfz.code == "0") {
                    var path = dataSzfz.data.PATH;
                    var type = olModel.getSuffix(path);
                    var tableData = self.getFinalZdList();
                    var deleteList = self.getDeleteList();
                    if (type === "edmx") {
                        olModel.saveEdmxNew(tableData, path, deleteList);
                    } else if (type === "epmx") {
                        olModel.saveEpmxNew(tableData, path, deleteList);
                    } else if (type === "edm") {
                        olModel.saveEdmNew(tableData, path, deleteList);
                    }
                } else {
                    PUB_FUNC.cPopup({
                        title: dataSzfz.msg,
                        iconType: "warning"
                    });
                    return false;
                }
            });
        },
        //获取排序后的字段
        getFinalZdList: function () {
            var zds = $(".yypz-ympz-right-zd-nr");
            var zdList = [];
            for (var i = 0; i < zds.length; i++) {
                var target = $(zds[i]);
                var zdIndex = target.attr("data-index");
                var customIndex = target.attr("data-custom-index");
                if (zdIndex) {
                    if (!this.modelZdList[zdIndex].isDelete) {
                        zdList.push(this.modelZdList[zdIndex]);
                    }
                } else if (customIndex) {
                    zdList.push(this.customModelZdList[customIndex]);
                } else {
                    var fi = target.attr("data-mindex");
                    var fj = target.attr("data-findex");
                    var pushzd = this.addFieldList[fi].fieldList[fj];
                    if (!pushzd.attributeExtend) {
                        pushzd.attributeExtend = pushzd.attribute;
                    } else {
                        var exAttr = pushzd.attributeExtend;
                        for (var k = 0; k < pushzd.attribute.length; k++) {
                            var flag = false;
                            for (j = 0; j < exAttr.length; j++) {
                                if (pushzd.attribute[k].name == pushzd.attributeExtend[j].name) {
                                    flag = true;
                                    break;
                                }
                            }
                            if (!flag) {
                                pushzd.attributeExtend.push(pushzd.attribute[k]);
                            }
                        }
                    }
                    if (this.groupNameList.length > 0 && this.groupNameList[this.groupNameList.length - 1]) {
                        pushzd.groupName = this.groupNameList[this.groupNameList.length - 1].gName;
                    }
                    zdList.push(pushzd);
                }
            }
            return zdList;
        },
        //获取deleteList
        getDeleteList: function () {
            var deleteList = [];
            for (var i = 0; i < this.modelZdList.length; i++) {
                if (this.modelZdList[i].isDelete) {
                    deleteList.push(this.modelZdList[i].name);
                }
            }
            return deleteList;
        },
        /** *********************right, 添加模型字段处理*********************** **/
        //添加字段
        addZd: function () {
            var self = this;
            //点击确定后操作
            var okAction = function () {
                self.actionGotoAddZd();
            };
            var cancleAction = function () {
                self.actionGotoCancleAddZd();
            };

            utils.window({
                title: "添加字段",
                content: '<div id="yypz-ympz-right-addzd"></div>',
                height: "529px",
                width: "820px",
                showButtons: true,
                buttons: [
                    {
                        text: "取消",
                        className: "bh-btn-default",
                        callback: cancleAction
                    },
                    {
                        text: "确定",
                        className: "bh-btn-primary",
                        callback: okAction
                    }
                ]
            });
            var card = ToolManager.loadCompiledPage("ympz/html/addZdCard");
            $("#yypz-ympz-right-addzd").html(
                card.render({
                    models: this.addFieldList,
                    show: this.addFieldList.length > 0 ? true : false
                }),
                true
            );
            if (this.addFieldList.length > 0) {
                var card = ToolManager.loadCompiledPage("ympz/html/zdCard");
                $("#ympz-addzd-form-right").html(
                    card.render({
                        field: this.addFieldList[0].fieldList,
                        selectCount: 0,
                        modelIndex: 0
                    }),
                    true
                );
            }
            //调整一下弹框的样式
            $("#yypz-ympz-right-addzd").closest(".jqx-rc-all").addClass("ympz-addzd-window");
            $("#yypz-ympz-right-addzd").closest(".jqx-rc-all").children(".head").addClass("ympz-addzd-window-title");
            $($(".ympz-addzd-form-left-lm")[0]).addClass("ympz-addzd-form-left-lm-active");

            this.bindAddFormEvent();
        },
        bindAddFormEvent: function () {
            var self = this;
            //全选
            self.bindAllSelect();
            //选一个 checked
            self.bindZdSelect();
            //选择栏目,表格点击
            self.bindLeftItem();
        },
        bindAllSelect: function () {
            var self = this;
            $(".ympz-add-form-zd-selectall")
                .off("change")
                .on("change", function (event) {
                    if ($("input[name='QX']").is(":checked")) {
                        $(".ympz-add-form-zd-che").each(function () {
                            $(this).prop("checked", true);
                        });
                        $(".ympz-addzd-form-num").text($(".ympz-add-form-zd-che").length);
                        //allSelect
                        var target = $(event.currentTarget).closest(".ympz-addzd-form-zdsqx");
                        var index = target.attr("data-model-index");
                        self.addFieldList[index]["isAllCheck"] = "CHECKED";
                        for (var i = 0; i < self.addFieldList[index].fieldList.length; i++) {
                            self.addFieldList[index].fieldList[i]["isCheck"] = "CHECKED";
                            self.addFieldList[index].selectCount = $(".ympz-add-form-zd-che").length;
                        }
                    } else {
                        $(".ympz-add-form-zd-che").each(function () {
                            $(this).prop("checked", false);
                        });
                        $(".ympz-addzd-form-num").text(0);
                        //allUnSelect
                        var target = $(event.currentTarget).closest(".ympz-addzd-form-zdsqx");
                        var index = target.attr("data-model-index");
                        self.addFieldList[index]["isAllCheck"] = "";

                        for (var i = 0; i < self.addFieldList[index].fieldList.length; i++) {
                            self.addFieldList[index].fieldList[i]["isCheck"] = "CHECKED";
                            self.addFieldList[index].selectCount = $(".ympz-add-form-zd-che").length;
                        }
                    }
                });
        },
        bindZdSelect: function () {
            var self = this;
            $("#ympz-addzd-form-right")
                .off("change")
                .on("change", ".ympz-add-form-zd-che", function (event) {
                    //准备
                    var target = $(event.currentTarget).closest(".ympz-addzd-form-zd");
                    var findex = target.attr("data-index");
                    var mindex = target.attr("data-model-index");
                    var selectNum = $(".ympz-add-form-zd-che:checked").length;
                    self.addFieldList[mindex].selectCount = selectNum;
                    //交互
                    $(".ympz-addzd-form-num").text(selectNum);
                    //如果全部选上了点击全选
                    var allCount = $(".ympz-add-form-zd-che").length;
                    if (selectNum == allCount) {
                        $("input[name='QX']").prop("checked", true);
                        self.addFieldList[mindex]["isAllCheck"] = "CHECKED";
                    }
                    //将选中的字段加上checked属性
                    if ($(event.currentTarget).is(":checked")) {
                        self.addFieldList[mindex].fieldList[findex]["isCheck"] = "CHECKED";
                    } else {
                        self.addFieldList[mindex].fieldList[findex]["isCheck"] = "";
                    }
                });
        },
        bindLeftItem: function () {
            var self = this;
            $(".ympz-addzd-form-left-lm")
                .off("click")
                .on("click", function (event) {
                    var target = $(event.currentTarget);
                    //点击后修改样式
                    $(".ympz-addzd-form-left-lm").removeClass("ympz-addzd-form-left-lm-active");
                    target.addClass("ympz-addzd-form-left-lm-active");

                    var index = target.attr("data-index");

                    var card = ToolManager.loadCompiledPage("ympz/html/zdCard");
                    $("#ympz-addzd-form-right").html(
                        card.render({
                            field: self.addFieldList[index].fieldList,
                            selectCount: self.addFieldList[index].selectCount,
                            modelIndex: index,
                            isAllCheck: self.addFieldList[index].isAllCheck
                        }),
                        true
                    );
                    self.bindAllSelect();
                });
        },
        actionGotoAddZd: function () {
            //新增 选中的字段
            var newAddZd = olModelUtil.addSelectedNewZd(this.addFieldList);
            var card = ToolManager.loadCompiledPage("ympz/html/zdCard1");
            $(".yypz-ympz-right-zd-nr:last").after(card.render({ field: newAddZd }));
        },
        actionGotoCancleAddZd: function () {
            this.addFieldList = [];
            this.addFieldList = olModelUtil.dataModelFieldListDeal();
        },
        addZdCustom: function () {
            zdxzzdy.addCustomField(this.customModelZdList, this.selectFormType, this.selectAppName);
        },
        /** *********************right, 编辑*********************** **/
        editZd: function (event) {
            var target = $(event.currentTarget).closest(".yypz-ympz-right-zd-nr");
            var index = target.attr("data-index");
            var i = target.attr("data-mindex");
            var j = target.attr("data-findex");
            var customIndex = target.attr("data-custom-index");

            var obj = {};
            if (index) {
                //原来模型的字段
                obj.type = "1";
                obj.index = index;
            } else if (customIndex) {
                //原来模型的字段
                obj.type = "2";
                obj.customIndex = customIndex;
            } else {
                //新增模型的字段
                obj.type = "2";
                obj.xindex = i;
                obj.yindex = j;
            }
            switch (this.selectFormType) {
                case "1":
                    zdbj.editAdvanceSearch(obj, this.modelZdList, this.addFieldList, this.selectAppName, this.customModelZdList);
                    break;
                case "2":
                    zdbj.editTable(obj, this.modelZdList, this.addFieldList, this.selectAppName, this.customModelZdList);
                    break;
                case "3":
                    zdbj.editForm(obj, this.modelZdList, this.addFieldList, this.selectAppName, this.customModelZdList);
                    break;
                default:
                    break;
            }
        },

        //全屏
        enlargeWindow: function (e) {
            $(e.currentTarget).removeClass("ympz-right-enlarge");
            $(e.currentTarget).addClass("ympz-right-narrow");
            $("#wrapper").addClass("wcollapsed");
            $("#sidebar-wrapper").addClass("collapsed");
            $(".container-fluid").addClass("sspz-ympz-enlarge");
        },

        //缩小
        narrowWindow: function (e) {
            $(e.currentTarget).removeClass("ympz-right-narrow");
            $(e.currentTarget).addClass("ympz-right-enlarge");
            $("#wrapper").removeClass("wcollapsed");
            $("#sidebar-wrapper").removeClass("collapsed");
            $(".container-fluid").removeClass("sspz-ympz-enlarge");
        },

        // 分组隐藏
        groupHide: function (e) {
            var type = $(e.currentTarget).data("type");
            $("#group-show-" + type).hide();
            $("#group-hide-" + type).show();
            $("#group-type-" + type).hide();
        },

        // 分组展开
        groupShow: function (e) {
            var type = $(e.currentTarget).data("type");
            $("#group-show-" + type).show();
            $("#group-hide-" + type).hide();
            $("#group-type-" + type).show();
        }
    });
    var uploadFingerFlag = false;
    //上传操作手册
    GoldenFingerPlugins.register("appOperatingManualUploadFingerPlugin", {
        // TODO
        onClick: function (e) {
            // 如果打开了上传附件  就关闭
            if (isStyled) {
                GoldenFingerPlugins.get("pageConfigGoldenFingerPlugin").onClick();
            }

            var targets = $("body>main>article>h2");

            var position = targets.offset();

            var width = targets.outerWidth();
            var height = targets.outerHeight();

            var zIndex = 1005;

            if (uploadFingerFlag) {
                $('body [emap-role="uploadFingerModal"]').remove();
                $('body [emap-role="UploadFinger"]').remove();
                $("body").removeClass("bh-has-modal-body");
            } else {
                if (!this.valid(targets)) {
                    return;
                }
                $("body").append(
                    '<div class="jqx-window-modal" emap-role="uploadFingerModal" style="opacity: 0.3; display: block; position: absolute; top: 0px; left: 0px; width: 100vw; height: 100vh; z-index: ' +
                        (zIndex - 2) +
                        ';"></div>'
                );
                $("body").addClass("bh-has-modal-body");
                var pageName = location.hash.replace(/\/|#/g, "");
                var pagefiles = JW_UTILS.getUploadFinger(pageName);

                var temp =
                    '<div emap-role="UploadFinger" style="cursor:pointer;width: ' +
                    width +
                    "px;height:" +
                    height +
                    "px;position:fixed;top: " +
                    position.top +
                    "px;left: " +
                    position.left +
                    "px;border: 2px dashed rgb(47, 140, 240);z-index:" +
                    (zIndex - 1) +
                    ';padding: 0 80px 0 20px;background-color:#fff;display:flex;align-items:center;justify-content: flex-start"><div><i class="icon iconfont">&#xe6af;</i>点击上传用户手册</div>';

                var pageName = location.hash.replace(/\/|#/g, "");
                var pagefiles = JW_UTILS.getUploadFinger(pageName);
                if (pagefiles && pagefiles.length) {
                    temp += "<div style='display:flex'>";
                    for (var i = 0; i < pagefiles.length; i++) {
                        temp +=
                            '<div class="bh-mh-8" style="position: relative;"><a href="javascript:void(0);">' +
                            pagefiles[i].fileName +
                            "</a><i class='delete-upload-finger icon iconfont' file-token='" +
                            pagefiles[i].token +
                            "' style='color: #2196F3;' class='icon iconfont'>&#xe6d6;</i></div>";
                    }
                    temp += "</div>";
                }
                temp += "</div>";
                $("body").append(temp);
            }

            uploadFingerFlag = !uploadFingerFlag;
            $("body").off("click", '[emap-role="UploadFinger"]', this.openUploadForm);
            $("body").on("click", '[emap-role="UploadFinger"]', this.openUploadForm);

            $("body").off("click", ".delete-upload-finger", this.deleteUploadFinger);
            $("body").on("click", ".delete-upload-finger", this.deleteUploadFinger);
        },

        valid: function (targets) {
            if (!targets || !targets.length) {
                $.bhTip({ state: "warning", content: "标题不存在，该功能无法使用" });
                console.warn("标题不存在");
                return;
            }
            return true;
            // 检查元素的显示状态
            if (targets.css("display") === "none" || targets.css("visibility") === "hidden") {
                $.bhTip({ state: "warning", content: "标题不存在，该功能无法使用" });
                console.warn("标题被隐藏");
                return;
            }

            // 检查透明度
            if (parseFloat(targets.css("opacity")) === 0) {
                $.bhTip({ state: "warning", content: "标题不存在，该功能无法使用" });
                console.warn("标题透明");
                return;
            }

            // 检查是否被其他元素覆盖
            var rect = targets[0].getBoundingClientRect();
            var elementsAtPoint = document.elementsFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);

            // 如果目标元素不在该点的最上层，那么它可能被遮挡
            if (elementsAtPoint[0] !== targets[0]) {
                $.bhTip({ state: "warning", content: "标题不存在，该功能无法使用" });
                console.warn("标题被遮挡");
                return;
            }

            return true;
        },
        // /sys/jwcommon/modules/public/czscbd.do"/>
        deleteUploadFinger: function (event) {
            event.stopPropagation();

            BH_UTILS.bhDialogWarning({
                title: "提示",
                content: "是否确认删除？",
                buttons: [
                    {
                        text: "确认",
                        className: "bh-btn-primary",
                        callback: function () {
                            var token = $(event.currentTarget).attr("file-token");
                            if (token) {
                                $.jwAjax({
                                    url: "/sys/jwcommon/api/appOperatingManual/deleteMenuOperatingManual/" + token + ".do",
                                    data: {},
                                    successMsg: "",
                                    success: function () {
                                        $('body [emap-role="uploadFingerModal"]').remove();
                                        $('body [emap-role="UploadFinger"]').remove();
                                        $("body").removeClass("bh-has-modal-body");
                                        PUB_FUNC.confirmDialog("删除成功，是否需要刷新当前页面,如若需刷新页面,请耐心等待？", function () {
                                            location.reload(true);
                                        });
                                    }
                                });
                            }
                        }
                    },
                    {
                        text: "取消",
                        className: "bh-btn-primary",
                        callback: function () {}
                    }
                ]
            });
        },
        openUploadForm: function () {
            var $win = $.jwWinForm({
                pagePath: context_path + "/sys/jwcommon/modules/public.do",
                action: "czscbd",
                title: "上传用户手册",
                forceInit: true,
                width: "600px",
                height: "500px",
                okText: "保存",
                defaultValue: {},
                afterFormInit: function ($dom) {
                    $dom.find('[data-field="YHSC"]').after(
                        '<span class="bh-color-danger">注：每个菜单最多支持显示“应用级”和“菜单级”两个文档；可通过调整“是否当前应用所有菜单都可以看到”属性，点击“上传文件”来修改“应用级”和“菜单级”附件内容。</span>'
                    );
                    // var indexView = ToolManager.loadCompiledPage("ympz/html/menuIconTpl");
                    // var iconList = [
                    //     { name: "&#xe61d;" },
                    //     { name: "&#xe605;" },
                    //     { name: "&#xe606;" },
                    //     { name: "&#xe86f;" },
                    //     { name: "&#xe630;" },
                    //     { name: "&#xe673;" },
                    //     { name: "&#xe807;" },
                    //     { name: "&#xe624;" },
                    //     { name: "&#xe8c3;" },
                    //     { name: "&#xe611;" },

                    // ];
                    // $dom.find('[data-name="TB"]').append(
                    //     indexView.render({
                    //         datas: iconList
                    //     })
                    // );

                    // $dom.find('[data-name="TB"]').find('[name="TB"][value="&#xe8c3;"]').prop("checked", true);
                },
                callback: function (formValue) {
                    var match = window.location.href.match(/\/sys\/([^\/?]+)/);
                    var appName = "";
                    // 检查是否成功匹配
                    if (match) {
                        appName = match[1];
                    }
                    // var icon = $win.find('[name="TB"]:checked').val();
                    // if (!icon) {
                    //     $.bhTipWarning("请选择一个图标");
                    //     return false;
                    // }
                    var requestParams = {
                        appName: appName,
                        token: formValue.YHSC
                        // iconFileId: icon
                    };

                    if (formValue.SFDZGYYSX === 0) {
                        requestParams.menu = location.hash.replace(/\/|#/g, "");
                    }
                    $.jwAjax({
                        url: "/sys/jwcommon/api/appOperatingManual/uploadOperatingManual.do",
                        data: requestParams,
                        successMsg: "",
                        success: function () {
                            $('body [emap-role="uploadFingerModal"]').remove();
                            $('body [emap-role="UploadFinger"]').remove();
                            $("body").removeClass("bh-has-modal-body");
                            PUB_FUNC.confirmDialog("保存成功，是否需要刷新当前页面,如若需刷新页面,请耐心等待？", function () {
                                location.reload(true);
                            });
                        }
                    });
                }
            });

            setTimeout(function () {
                var $goldenfingerModal = $('[emap-role="uploadFingerModal"]');
                if ($goldenfingerModal) {
                    var zIndex = Number($goldenfingerModal.css("z-index")) + 2;
                    $(".jqx-window").css("z-index", zIndex);
                    $(".jqx-window-modal").css("z-index", zIndex - 2);
                }
            }, 200);
        }
    });
    //数据日志
    GoldenFingerPlugins.register("jwDataLogPlugin", {
        /**
         * 触发点击事件
         * */
        onClick: function () { 
            $.jwAjax({
                url: "/sys/jwcommon/datalog/open.do",
                data: {},
                successMsg: "",
                success: function (res) {
                    if(res.code==="0"){
                        $.bhTip({ content: '开启成功！需注意：数据运行日志需业务方配合输出，请确保业务代码已输出数据日志',state: 'success'});
                    }
                }
            });
        }
    });
})();
