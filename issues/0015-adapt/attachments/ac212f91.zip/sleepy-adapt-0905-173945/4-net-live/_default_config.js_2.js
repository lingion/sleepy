METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/wdkbby/*default/config.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (156 字符) --------
define(function(require, exports, module) {
	 
	var config = {
		/*
		 	APP标题
		 */
		"APP_TITLE": "我的课表"

	};

	return config;

});