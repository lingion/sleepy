METHOD: GET
URL: https://jwxt.whut.edu.cn/jwapp/sys/jwcommon/public/script/common/jsloader.js?av=1788431380193
STATUS: 200
CONTENT-TYPE: application/javascript
FRAME: 392901587C80AA0126EBB9F5711A8ED6

-------- 响应体 (8870 字符) --------
(function (window, $) {
    var _JW_INIT_CONFIG = (window._JW_INIT_CONFIG = window._JW_INIT_CONFIG || {});
    window._JW_BOOT_HELPER = window._JW_BOOT_HELPER || {
        addFrameworkInitCallback: function (fn) {
            console.warn("jwpubapp未升级，无法使用");
        }
    };
    window._JW_COMMON_CONFIG = {
        contextPath: window.contextPath,
        DEBUG: _JW_INIT_CONFIG.DEBUG || false,
        appname: appname,
        basePath: window.contextPath + "/sys/jwcommon",
        APP_VERSION: _JW_INIT_CONFIG.APP_VERSION || APP_CONFIG.APP_VERSION
    };
    //额外公共JS库
    var RES_CONFIG = {
        LOCAL_BASE_JS: [
            "/public/script/common/jw_common.js",
            "/public/script/common/jw_page.js",
            "/public/script/common/jw_utils.js",
            "/public/script/common/jw_auth.js",
            "/public/script/common/jw_translate.js",
            "/public/script/common/lib/jquery.md5.min.js",
            "/public/script/common/jw-theme-patch/jw-theme-patch.js",
            "/public/script/common/jw_security.js",
            "/public/script/common/jquery.binding.js",
            "/public/script/common/xgjsutil.js",
            "/public/script/common/pubFunctions.js",
        ],
        // 教务组件
        LOCAL_COMPONENTS_JS: [
            "/public/script/common/components/jw-audit-flows/jw-audit-flows.js",
            "/public/script/common/components/jw-auth-tab/index.js",
            "/public/script/common/components/jw-breadcrumb/jw-breadcrumb.js",
            "/public/script/common/components/jw-bhFormOutline/jw-bhFormOutline.js",
            "/public/script/common/components/jw-upload-auth/jw-upload-auth.js",
            "/public/script/common/components/jw-user-manual/jw-user-manual.js",
        ],
        LOCAL_NOMAL_JS: ["/public/script/common/lib/jquery.base64.js", "/public/script/common/lib/CryptoJS.min.js", "/public/css/icon/omoiconfont.js"],
        RES_BASE_JS: ["/bower_components/jquery-qrcode/jquery.qrcode.min.js"]
    };
    var req = require;

    var absPageBase = _JW_COMMON_CONFIG.contextPath + "/sys/jwcommon";

    function _init() {
        _config();
        // 先加载 LOCAL_BASE_JS
        _.each(RES_CONFIG["LOCAL_BASE_JS"], function (url) {
            _createScript(absPageBase + url, true, true);
        });
        // 再加载教务组件
        _.each(RES_CONFIG["LOCAL_COMPONENTS_JS"], function (url) {
            _createScript(absPageBase + url, true, true);
        });
        // 引入帆软js
        _createScript(_JW_COMMON_CONFIG.contextPath + '/sys/jwpubapp/public/script/publicPrintFR.js', true, true);
        // 防抖
        debounceRequest();
        req(
            ["./config"],
            function (config) {
                // 解决当前执行早于appcore.js，使得应用中config.js配置的SERVER_CONFIG_API无效，仍使用系统默认配置，致使获取的配置信息缺少MODULES内容。appcore.js(2144)报错，页面停止渲染
                window.APP_CONFIG = $.extend(true, {}, window.APP_CONFIG, config);
                initFn();
            },
            function (e) {
                console.error(e);
                initFn();
            }
        );
        var initFn = function () {
            // 去除引用boot，因为boot会加载ubaseView，而ubaseView会获取$('body')标签，
            // 但此时$('body')标签可能还没加载出来，就会导致页面事件绑定不生效的问题
            req(["utils", "ubaseUtils", "configUtils"], function () {
                //加载额外公共资源库
                _loadJs();
            });
        };
    }

    function _loadJs() {
        //加载时,不使用amd
        var tmp = define && define.amd;
        define && delete define.amd;
        var localPath = absPageBase;

        //再加载 RES_BASE_JS
        req(_getResourceConfig("RES_BASE_JS"), function () {
            //再加载 RES_NOMAL_JS 和 LOCAL_NOMAL_JS
            _.delay(function () {
                req(_getResourceConfig("RES_NOMAL_JS"));
            }, 200);
            var depts = [];
            _.each(RES_CONFIG["LOCAL_NOMAL_JS"], function (url) {
                depts.push(localPath + url);
            });
            req(depts, function () {
                define.amd = tmp;
            });
        });
    }

    function _getResourceConfig(key) {
        var cdn = require("utils").getConfig("RESOURCE_SERVER");
        var depts = [];
        _.each(RES_CONFIG[key], function (url) {
            depts.push(cdn + url);
        });
        return depts;
    }

    function _config() {
        var loadConfig = window._JW_CONFIG || {};
        var config = $.extend(
            {
                // jw_common.js 全局变量属性名,默认为A
                COMMON_NAME: "A",
                // jw_common.js 初始化完成后的回调
                afterCommonInit: undefined,
                // jw_page.js 全局变量属性名,默认为JWP
                COMMON_PAGE_NAME: "JWP",
                //加载此js文件的页面层级，直接放在web目录下层级默认为0,如web/index.jsp
                pageLevel: 1,
                // page.js 初始化完成后的回调
                afterPageInit: undefined
            },
            loadConfig
        );
        window._JW_CONFIG = config;

        config.getCommon = function () {
            return window[config.COMMON_NAME];
        };
        config.getPage = function () {
            return window[config.COMMON_PAGE_NAME];
        };
    }

    /**
     * 请求防抖
     */
    function debounceRequest() {
        var currentRequest = {};

        function genToken(setting) {
            var key = setting.url + "|";
            if (setting.data) {
                if ($.type(setting.data) == "string") {
                    key += setting.data;
                } else {
                    key += window[_JW_CONFIG.COMMON_NAME].toJsonStr(setting.data);
                }
            }
            return $.md5(key);
        }

        /**
         * 是否需要防抖
         * @param xhr
         */
        function debounceRequest(xhr) {
            var debounce = xhr.debounce;
            if (debounce === false) {
                return false;
            }
            if (debounce === true) {
                return true;
            }
            if (!window.APP_CONFIG) {
                // APP_CONFIG对象不存在，说明还没初始化
                return false;
            }
            // 取全局的配置
            return window.APP_CONFIG.DEBOUNCE_REQUEST === true;
        }

        $.ajaxSetup({
            beforeSend: function () {
                if (!debounceRequest(this)) {
                    return true;
                }
                var A = window[_JW_CONFIG.COMMON_NAME];
                var url = this.url;
                /*if (url.indexOf('/code/') >= 0 || url.indexOf('/emapcomponent/file/') >= 0) {
                    return true;
                }*/
                var token = genToken(this);
                if (!token) {
                    A.msg("系统异常,请稍后再试");
                    return false;
                }
                if (currentRequest[token] === 1) {
                    A.msg("正在处理,请稍后...");
                    console.warn(A.formatStr("请求防抖处理,url:{}", url));
                    return false;
                }
                currentRequest[token] = 1;
                return true;
            },
            complete: function () {
                if (!debounceRequest(this)) {
                    return;
                }
                var token = genToken(this);
                delete currentRequest[token];
            }
        });
    }

    function _createScript(url, last, force) {
        var version = _JW_COMMON_CONFIG.APP_VERSION;
        var $script = $(document).find('script[src="{src}"]'.replace("{src}", url));
        if ($script.length && !force) {
            return;
        }
        var src = url + "?av=" + version;
        document.write('<script type="text/javascript" src="' + src + '"></script>');
        /*var tag = document.createElement('script');
        tag.type = 'text/javascript';
        tag.src = url + '?av=' + version;
        var root_s = document.getElementsByTagName('body')[0] || document.getElementsByTagName('head')[0] || document;
        if (last) {
            root_s.appendChild(tag);
        } else {
            var $scriptNode = $(root_s).find('div.jw-script-insertion-point');
            if (_.isEmpty($scriptNode)) {
                $scriptNode = $('<div class="jw-script-insertion-point"></div>');
                $(root_s).prepend($scriptNode[0]);
            }
            $scriptNode.append(tag);
        }*/
    }

    _init();
})(window, jQuery);
